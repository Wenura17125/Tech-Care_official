(self.webpackChunk = self.webpackChunk || []).push([
  ["614"],
  {
    5487: function () {
      "use strict";
      window.tram = (function (e) {
        function t(e, t) {
          return new D.Bare().init(e, t);
        }
        function n(e) {
          var t = parseInt(e.slice(1), 16);
          return [(t >> 16) & 255, (t >> 8) & 255, 255 & t];
        }
        function r(e, t, n) {
          return (
            "#" + (0x1000000 | (e << 16) | (t << 8) | n).toString(16).slice(1)
          );
        }
        function i() {}
        function o(e, t, n) {
          if ((void 0 !== t && (n = t), void 0 === e)) return n;
          var r = n;
          return (
            q.test(e) || !Q.test(e)
              ? (r = parseInt(e, 10))
              : Q.test(e) && (r = 1e3 * parseFloat(e)),
            0 > r && (r = 0),
            r == r ? r : n
          );
        }
        function a(e) {
          X.debug && window && window.console.warn(e);
        }
        var u,
          c,
          s,
          l = (function (e, t, n) {
            function r(e) {
              return "object" == typeof e;
            }
            function i(e) {
              return "function" == typeof e;
            }
            function o() {}
            return function a(u, c) {
              function s() {
                var e = new l();
                return i(e.init) && e.init.apply(e, arguments), e;
              }
              function l() {}
              c === n && ((c = u), (u = Object)), (s.Bare = l);
              var f,
                d = (o[e] = u[e]),
                p = (l[e] = s[e] = new o());
              return (
                (p.constructor = s),
                (s.mixin = function (t) {
                  return (l[e] = s[e] = a(s, t)[e]), s;
                }),
                (s.open = function (e) {
                  if (
                    ((f = {}),
                    i(e) ? (f = e.call(s, p, d, s, u)) : r(e) && (f = e),
                    r(f))
                  )
                    for (var n in f) t.call(f, n) && (p[n] = f[n]);
                  return i(p.init) || (p.init = u), s;
                }),
                s.open(c)
              );
            };
          })("prototype", {}.hasOwnProperty),
          f = {
            ease: [
              "ease",
              function (e, t, n, r) {
                var i = (e /= r) * e,
                  o = i * e;
                return (
                  t +
                  n *
                    (-2.75 * o * i + 11 * i * i + -15.5 * o + 8 * i + 0.25 * e)
                );
              },
            ],
            "ease-in": [
              "ease-in",
              function (e, t, n, r) {
                var i = (e /= r) * e,
                  o = i * e;
                return t + n * (-1 * o * i + 3 * i * i + -3 * o + 2 * i);
              },
            ],
            "ease-out": [
              "ease-out",
              function (e, t, n, r) {
                var i = (e /= r) * e,
                  o = i * e;
                return (
                  t +
                  n *
                    (0.3 * o * i + -1.6 * i * i + 2.2 * o + -1.8 * i + 1.9 * e)
                );
              },
            ],
            "ease-in-out": [
              "ease-in-out",
              function (e, t, n, r) {
                var i = (e /= r) * e,
                  o = i * e;
                return t + n * (2 * o * i + -5 * i * i + 2 * o + 2 * i);
              },
            ],
            linear: [
              "linear",
              function (e, t, n, r) {
                return (n * e) / r + t;
              },
            ],
            "ease-in-quad": [
              "cubic-bezier(0.550, 0.085, 0.680, 0.530)",
              function (e, t, n, r) {
                return n * (e /= r) * e + t;
              },
            ],
            "ease-out-quad": [
              "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
              function (e, t, n, r) {
                return -n * (e /= r) * (e - 2) + t;
              },
            ],
            "ease-in-out-quad": [
              "cubic-bezier(0.455, 0.030, 0.515, 0.955)",
              function (e, t, n, r) {
                return (e /= r / 2) < 1
                  ? (n / 2) * e * e + t
                  : (-n / 2) * (--e * (e - 2) - 1) + t;
              },
            ],
            "ease-in-cubic": [
              "cubic-bezier(0.550, 0.055, 0.675, 0.190)",
              function (e, t, n, r) {
                return n * (e /= r) * e * e + t;
              },
            ],
            "ease-out-cubic": [
              "cubic-bezier(0.215, 0.610, 0.355, 1)",
              function (e, t, n, r) {
                return n * ((e = e / r - 1) * e * e + 1) + t;
              },
            ],
            "ease-in-out-cubic": [
              "cubic-bezier(0.645, 0.045, 0.355, 1)",
              function (e, t, n, r) {
                return (e /= r / 2) < 1
                  ? (n / 2) * e * e * e + t
                  : (n / 2) * ((e -= 2) * e * e + 2) + t;
              },
            ],
            "ease-in-quart": [
              "cubic-bezier(0.895, 0.030, 0.685, 0.220)",
              function (e, t, n, r) {
                return n * (e /= r) * e * e * e + t;
              },
            ],
            "ease-out-quart": [
              "cubic-bezier(0.165, 0.840, 0.440, 1)",
              function (e, t, n, r) {
                return -n * ((e = e / r - 1) * e * e * e - 1) + t;
              },
            ],
            "ease-in-out-quart": [
              "cubic-bezier(0.770, 0, 0.175, 1)",
              function (e, t, n, r) {
                return (e /= r / 2) < 1
                  ? (n / 2) * e * e * e * e + t
                  : (-n / 2) * ((e -= 2) * e * e * e - 2) + t;
              },
            ],
            "ease-in-quint": [
              "cubic-bezier(0.755, 0.050, 0.855, 0.060)",
              function (e, t, n, r) {
                return n * (e /= r) * e * e * e * e + t;
              },
            ],
            "ease-out-quint": [
              "cubic-bezier(0.230, 1, 0.320, 1)",
              function (e, t, n, r) {
                return n * ((e = e / r - 1) * e * e * e * e + 1) + t;
              },
            ],
            "ease-in-out-quint": [
              "cubic-bezier(0.860, 0, 0.070, 1)",
              function (e, t, n, r) {
                return (e /= r / 2) < 1
                  ? (n / 2) * e * e * e * e * e + t
                  : (n / 2) * ((e -= 2) * e * e * e * e + 2) + t;
              },
            ],
            "ease-in-sine": [
              "cubic-bezier(0.470, 0, 0.745, 0.715)",
              function (e, t, n, r) {
                return -n * Math.cos((e / r) * (Math.PI / 2)) + n + t;
              },
            ],
            "ease-out-sine": [
              "cubic-bezier(0.390, 0.575, 0.565, 1)",
              function (e, t, n, r) {
                return n * Math.sin((e / r) * (Math.PI / 2)) + t;
              },
            ],
            "ease-in-out-sine": [
              "cubic-bezier(0.445, 0.050, 0.550, 0.950)",
              function (e, t, n, r) {
                return (-n / 2) * (Math.cos((Math.PI * e) / r) - 1) + t;
              },
            ],
            "ease-in-expo": [
              "cubic-bezier(0.950, 0.050, 0.795, 0.035)",
              function (e, t, n, r) {
                return 0 === e ? t : n * Math.pow(2, 10 * (e / r - 1)) + t;
              },
            ],
            "ease-out-expo": [
              "cubic-bezier(0.190, 1, 0.220, 1)",
              function (e, t, n, r) {
                return e === r
                  ? t + n
                  : n * (-Math.pow(2, (-10 * e) / r) + 1) + t;
              },
            ],
            "ease-in-out-expo": [
              "cubic-bezier(1, 0, 0, 1)",
              function (e, t, n, r) {
                return 0 === e
                  ? t
                  : e === r
                  ? t + n
                  : (e /= r / 2) < 1
                  ? (n / 2) * Math.pow(2, 10 * (e - 1)) + t
                  : (n / 2) * (-Math.pow(2, -10 * --e) + 2) + t;
              },
            ],
            "ease-in-circ": [
              "cubic-bezier(0.600, 0.040, 0.980, 0.335)",
              function (e, t, n, r) {
                return -n * (Math.sqrt(1 - (e /= r) * e) - 1) + t;
              },
            ],
            "ease-out-circ": [
              "cubic-bezier(0.075, 0.820, 0.165, 1)",
              function (e, t, n, r) {
                return n * Math.sqrt(1 - (e = e / r - 1) * e) + t;
              },
            ],
            "ease-in-out-circ": [
              "cubic-bezier(0.785, 0.135, 0.150, 0.860)",
              function (e, t, n, r) {
                return (e /= r / 2) < 1
                  ? (-n / 2) * (Math.sqrt(1 - e * e) - 1) + t
                  : (n / 2) * (Math.sqrt(1 - (e -= 2) * e) + 1) + t;
              },
            ],
            "ease-in-back": [
              "cubic-bezier(0.600, -0.280, 0.735, 0.045)",
              function (e, t, n, r, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  n * (e /= r) * e * ((i + 1) * e - i) + t
                );
              },
            ],
            "ease-out-back": [
              "cubic-bezier(0.175, 0.885, 0.320, 1.275)",
              function (e, t, n, r, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  n * ((e = e / r - 1) * e * ((i + 1) * e + i) + 1) + t
                );
              },
            ],
            "ease-in-out-back": [
              "cubic-bezier(0.680, -0.550, 0.265, 1.550)",
              function (e, t, n, r, i) {
                return (
                  void 0 === i && (i = 1.70158),
                  (e /= r / 2) < 1
                    ? (n / 2) * e * e * (((i *= 1.525) + 1) * e - i) + t
                    : (n / 2) *
                        ((e -= 2) * e * (((i *= 1.525) + 1) * e + i) + 2) +
                      t
                );
              },
            ],
          },
          d = {
            "ease-in-back": "cubic-bezier(0.600, 0, 0.735, 0.045)",
            "ease-out-back": "cubic-bezier(0.175, 0.885, 0.320, 1)",
            "ease-in-out-back": "cubic-bezier(0.680, 0, 0.265, 1)",
          },
          p = window,
          h = "bkwld-tram",
          E = /[\-\.0-9]/g,
          g = /[A-Z]/,
          m = "number",
          y = /^(rgb|#)/,
          v = /(em|cm|mm|in|pt|pc|px)$/,
          _ = /(em|cm|mm|in|pt|pc|px|%)$/,
          I = /(deg|rad|turn)$/,
          b = "unitless",
          T = /(all|none) 0s ease 0s/,
          O = /^(width|height)$/,
          w = document.createElement("a"),
          A = ["Webkit", "Moz", "O", "ms"],
          C = ["-webkit-", "-moz-", "-o-", "-ms-"],
          R = function (e) {
            if (e in w.style) return { dom: e, css: e };
            var t,
              n,
              r = "",
              i = e.split("-");
            for (t = 0; t < i.length; t++)
              r += i[t].charAt(0).toUpperCase() + i[t].slice(1);
            for (t = 0; t < A.length; t++)
              if ((n = A[t] + r) in w.style) return { dom: n, css: C[t] + e };
          },
          N = (t.support = {
            bind: Function.prototype.bind,
            transform: R("transform"),
            transition: R("transition"),
            backface: R("backface-visibility"),
            timing: R("transition-timing-function"),
          });
        if (N.transition) {
          var S = N.timing.dom;
          if (((w.style[S] = f["ease-in-back"][0]), !w.style[S]))
            for (var F in d) f[F][0] = d[F];
        }
        var L = (t.frame =
            (u =
              p.requestAnimationFrame ||
              p.webkitRequestAnimationFrame ||
              p.mozRequestAnimationFrame ||
              p.oRequestAnimationFrame ||
              p.msRequestAnimationFrame) && N.bind
              ? u.bind(p)
              : function (e) {
                  p.setTimeout(e, 16);
                }),
          P = (t.now =
            (s =
              (c = p.performance) &&
              (c.now || c.webkitNow || c.msNow || c.mozNow)) && N.bind
              ? s.bind(c)
              : Date.now ||
                function () {
                  return +new Date();
                }),
          M = l(function (t) {
            function n(e, t) {
              var n = (function (e) {
                  for (var t = -1, n = e ? e.length : 0, r = []; ++t < n; ) {
                    var i = e[t];
                    i && r.push(i);
                  }
                  return r;
                })(("" + e).split(" ")),
                r = n[0];
              t = t || {};
              var i = z[r];
              if (!i) return a("Unsupported property: " + r);
              if (!t.weak || !this.props[r]) {
                var o = i[0],
                  u = this.props[r];
                return (
                  u || (u = this.props[r] = new o.Bare()),
                  u.init(this.$el, n, i, t),
                  u
                );
              }
            }
            function r(e, t, r) {
              if (e) {
                var a = typeof e;
                if (
                  (t ||
                    (this.timer && this.timer.destroy(),
                    (this.queue = []),
                    (this.active = !1)),
                  "number" == a && t)
                )
                  return (
                    (this.timer = new B({
                      duration: e,
                      context: this,
                      complete: i,
                    })),
                    void (this.active = !0)
                  );
                if ("string" == a && t) {
                  switch (e) {
                    case "hide":
                      c.call(this);
                      break;
                    case "stop":
                      u.call(this);
                      break;
                    case "redraw":
                      s.call(this);
                      break;
                    default:
                      n.call(this, e, r && r[1]);
                  }
                  return i.call(this);
                }
                if ("function" == a) return void e.call(this, this);
                if ("object" == a) {
                  var d = 0;
                  f.call(
                    this,
                    e,
                    function (e, t) {
                      e.span > d && (d = e.span), e.stop(), e.animate(t);
                    },
                    function (e) {
                      "wait" in e && (d = o(e.wait, 0));
                    }
                  ),
                    l.call(this),
                    d > 0 &&
                      ((this.timer = new B({ duration: d, context: this })),
                      (this.active = !0),
                      t && (this.timer.complete = i));
                  var p = this,
                    h = !1,
                    E = {};
                  L(function () {
                    f.call(p, e, function (e) {
                      e.active && ((h = !0), (E[e.name] = e.nextStyle));
                    }),
                      h && p.$el.css(E);
                  });
                }
              }
            }
            function i() {
              if (
                (this.timer && this.timer.destroy(),
                (this.active = !1),
                this.queue.length)
              ) {
                var e = this.queue.shift();
                r.call(this, e.options, !0, e.args);
              }
            }
            function u(e) {
              var t;
              this.timer && this.timer.destroy(),
                (this.queue = []),
                (this.active = !1),
                "string" == typeof e
                  ? ((t = {})[e] = 1)
                  : (t = "object" == typeof e && null != e ? e : this.props),
                f.call(this, t, d),
                l.call(this);
            }
            function c() {
              u.call(this), (this.el.style.display = "none");
            }
            function s() {
              this.el.offsetHeight;
            }
            function l() {
              var e,
                t,
                n = [];
              for (e in (this.upstream && n.push(this.upstream), this.props))
                (t = this.props[e]).active && n.push(t.string);
              (n = n.join(",")),
                this.style !== n &&
                  ((this.style = n), (this.el.style[N.transition.dom] = n));
            }
            function f(e, t, r) {
              var i,
                o,
                a,
                u,
                c = t !== d,
                s = {};
              for (i in e)
                (a = e[i]),
                  i in Y
                    ? (s.transform || (s.transform = {}), (s.transform[i] = a))
                    : (g.test(i) &&
                        (i = i.replace(/[A-Z]/g, function (e) {
                          return "-" + e.toLowerCase();
                        })),
                      i in z ? (s[i] = a) : (u || (u = {}), (u[i] = a)));
              for (i in s) {
                if (((a = s[i]), !(o = this.props[i]))) {
                  if (!c) continue;
                  o = n.call(this, i);
                }
                t.call(this, o, a);
              }
              r && u && r.call(this, u);
            }
            function d(e) {
              e.stop();
            }
            function p(e, t) {
              e.set(t);
            }
            function E(e) {
              this.$el.css(e);
            }
            function m(e, n) {
              t[e] = function () {
                return this.children
                  ? y.call(this, n, arguments)
                  : (this.el && n.apply(this, arguments), this);
              };
            }
            function y(e, t) {
              var n,
                r = this.children.length;
              for (n = 0; r > n; n++) e.apply(this.children[n], t);
              return this;
            }
            (t.init = function (t) {
              if (
                ((this.$el = e(t)),
                (this.el = this.$el[0]),
                (this.props = {}),
                (this.queue = []),
                (this.style = ""),
                (this.active = !1),
                X.keepInherited && !X.fallback)
              ) {
                var n = H(this.el, "transition");
                n && !T.test(n) && (this.upstream = n);
              }
              N.backface &&
                X.hideBackface &&
                W(this.el, N.backface.css, "hidden");
            }),
              m("add", n),
              m("start", r),
              m("wait", function (e) {
                (e = o(e, 0)),
                  this.active
                    ? this.queue.push({ options: e })
                    : ((this.timer = new B({
                        duration: e,
                        context: this,
                        complete: i,
                      })),
                      (this.active = !0));
              }),
              m("then", function (e) {
                return this.active
                  ? (this.queue.push({ options: e, args: arguments }),
                    void (this.timer.complete = i))
                  : a(
                      "No active transition timer. Use start() or wait() before then()."
                    );
              }),
              m("next", i),
              m("stop", u),
              m("set", function (e) {
                u.call(this, e), f.call(this, e, p, E);
              }),
              m("show", function (e) {
                "string" != typeof e && (e = "block"),
                  (this.el.style.display = e);
              }),
              m("hide", c),
              m("redraw", s),
              m("destroy", function () {
                u.call(this),
                  e.removeData(this.el, h),
                  (this.$el = this.el = null);
              });
          }),
          D = l(M, function (t) {
            function n(t, n) {
              var r = e.data(t, h) || e.data(t, h, new M.Bare());
              return r.el || r.init(t), n ? r.start(n) : r;
            }
            t.init = function (t, r) {
              var i = e(t);
              if (!i.length) return this;
              if (1 === i.length) return n(i[0], r);
              var o = [];
              return (
                i.each(function (e, t) {
                  o.push(n(t, r));
                }),
                (this.children = o),
                this
              );
            };
          }),
          k = l(function (e) {
            function t() {
              var e = this.get();
              this.update("auto");
              var t = this.get();
              return this.update(e), t;
            }
            (e.init = function (e, t, n, r) {
              (this.$el = e), (this.el = e[0]);
              var i,
                a,
                u,
                c = t[0];
              n[2] && (c = n[2]),
                $[c] && (c = $[c]),
                (this.name = c),
                (this.type = n[1]),
                (this.duration = o(t[1], this.duration, 500)),
                (this.ease =
                  ((i = t[2]),
                  (a = this.ease),
                  (u = "ease"),
                  void 0 !== a && (u = a),
                  i in f ? i : u)),
                (this.delay = o(t[3], this.delay, 0)),
                (this.span = this.duration + this.delay),
                (this.active = !1),
                (this.nextStyle = null),
                (this.auto = O.test(this.name)),
                (this.unit = r.unit || this.unit || X.defaultUnit),
                (this.angle = r.angle || this.angle || X.defaultAngle),
                X.fallback || r.fallback
                  ? (this.animate = this.fallback)
                  : ((this.animate = this.transition),
                    (this.string =
                      this.name +
                      " " +
                      this.duration +
                      "ms" +
                      ("ease" != this.ease ? " " + f[this.ease][0] : "") +
                      (this.delay ? " " + this.delay + "ms" : "")));
            }),
              (e.set = function (e) {
                (e = this.convert(e, this.type)), this.update(e), this.redraw();
              }),
              (e.transition = function (e) {
                (this.active = !0),
                  (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == this.el.style[this.name] &&
                      (this.update(this.get()), this.redraw()),
                    "auto" == e && (e = t.call(this))),
                  (this.nextStyle = e);
              }),
              (e.fallback = function (e) {
                var n =
                  this.el.style[this.name] ||
                  this.convert(this.get(), this.type);
                (e = this.convert(e, this.type)),
                  this.auto &&
                    ("auto" == n && (n = this.convert(this.get(), this.type)),
                    "auto" == e && (e = t.call(this))),
                  (this.tween = new U({
                    from: n,
                    to: e,
                    duration: this.duration,
                    delay: this.delay,
                    ease: this.ease,
                    update: this.update,
                    context: this,
                  }));
              }),
              (e.get = function () {
                return H(this.el, this.name);
              }),
              (e.update = function (e) {
                W(this.el, this.name, e);
              }),
              (e.stop = function () {
                (this.active || this.nextStyle) &&
                  ((this.active = !1),
                  (this.nextStyle = null),
                  W(this.el, this.name, this.get()));
                var e = this.tween;
                e && e.context && e.destroy();
              }),
              (e.convert = function (e, t) {
                if ("auto" == e && this.auto) return e;
                var n,
                  i,
                  o = "number" == typeof e,
                  u = "string" == typeof e;
                switch (t) {
                  case m:
                    if (o) return e;
                    if (u && "" === e.replace(E, "")) return +e;
                    i = "number(unitless)";
                    break;
                  case y:
                    if (u) {
                      if ("" === e && this.original) return this.original;
                      if (t.test(e))
                        return "#" == e.charAt(0) && 7 == e.length
                          ? e
                          : ((n = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(e))
                              ? r(n[1], n[2], n[3])
                              : e
                            ).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3");
                    }
                    i = "hex or rgb string";
                    break;
                  case v:
                    if (o) return e + this.unit;
                    if (u && t.test(e)) return e;
                    i = "number(px) or string(unit)";
                    break;
                  case _:
                    if (o) return e + this.unit;
                    if (u && t.test(e)) return e;
                    i = "number(px) or string(unit or %)";
                    break;
                  case I:
                    if (o) return e + this.angle;
                    if (u && t.test(e)) return e;
                    i = "number(deg) or string(angle)";
                    break;
                  case b:
                    if (o || (u && _.test(e))) return e;
                    i = "number(unitless) or string(unit or %)";
                }
                return (
                  a(
                    "Type warning: Expected: [" +
                      i +
                      "] Got: [" +
                      typeof e +
                      "] " +
                      e
                  ),
                  e
                );
              }),
              (e.redraw = function () {
                this.el.offsetHeight;
              });
          }),
          x = l(k, function (e, t) {
            e.init = function () {
              t.init.apply(this, arguments),
                this.original || (this.original = this.convert(this.get(), y));
            };
          }),
          G = l(k, function (e, t) {
            (e.init = function () {
              t.init.apply(this, arguments), (this.animate = this.fallback);
            }),
              (e.get = function () {
                return this.$el[this.name]();
              }),
              (e.update = function (e) {
                this.$el[this.name](e);
              });
          }),
          j = l(k, function (e, t) {
            function n(e, t) {
              var n, r, i, o, a;
              for (n in e)
                (i = (o = Y[n])[0]),
                  (r = o[1] || n),
                  (a = this.convert(e[n], i)),
                  t.call(this, r, a, i);
            }
            (e.init = function () {
              t.init.apply(this, arguments),
                this.current ||
                  ((this.current = {}),
                  Y.perspective &&
                    X.perspective &&
                    ((this.current.perspective = X.perspective),
                    W(this.el, this.name, this.style(this.current)),
                    this.redraw()));
            }),
              (e.set = function (e) {
                n.call(this, e, function (e, t) {
                  this.current[e] = t;
                }),
                  W(this.el, this.name, this.style(this.current)),
                  this.redraw();
              }),
              (e.transition = function (e) {
                var t = this.values(e);
                this.tween = new V({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                });
                var n,
                  r = {};
                for (n in this.current) r[n] = n in t ? t[n] : this.current[n];
                (this.active = !0), (this.nextStyle = this.style(r));
              }),
              (e.fallback = function (e) {
                var t = this.values(e);
                this.tween = new V({
                  current: this.current,
                  values: t,
                  duration: this.duration,
                  delay: this.delay,
                  ease: this.ease,
                  update: this.update,
                  context: this,
                });
              }),
              (e.update = function () {
                W(this.el, this.name, this.style(this.current));
              }),
              (e.style = function (e) {
                var t,
                  n = "";
                for (t in e) n += t + "(" + e[t] + ") ";
                return n;
              }),
              (e.values = function (e) {
                var t,
                  r = {};
                return (
                  n.call(this, e, function (e, n, i) {
                    (r[e] = n),
                      void 0 === this.current[e] &&
                        ((t = 0),
                        ~e.indexOf("scale") && (t = 1),
                        (this.current[e] = this.convert(t, i)));
                  }),
                  r
                );
              });
          }),
          U = l(function (t) {
            function o() {
              var e,
                t,
                n,
                r = c.length;
              if (r)
                for (L(o), t = P(), e = r; e--; ) (n = c[e]) && n.render(t);
            }
            var u = { ease: f.ease[1], from: 0, to: 1 };
            (t.init = function (e) {
              (this.duration = e.duration || 0), (this.delay = e.delay || 0);
              var t = e.ease || u.ease;
              f[t] && (t = f[t][1]),
                "function" != typeof t && (t = u.ease),
                (this.ease = t),
                (this.update = e.update || i),
                (this.complete = e.complete || i),
                (this.context = e.context || this),
                (this.name = e.name);
              var n = e.from,
                r = e.to;
              void 0 === n && (n = u.from),
                void 0 === r && (r = u.to),
                (this.unit = e.unit || ""),
                "number" == typeof n && "number" == typeof r
                  ? ((this.begin = n), (this.change = r - n))
                  : this.format(r, n),
                (this.value = this.begin + this.unit),
                (this.start = P()),
                !1 !== e.autoplay && this.play();
            }),
              (t.play = function () {
                this.active ||
                  (this.start || (this.start = P()),
                  (this.active = !0),
                  1 === c.push(this) && L(o));
              }),
              (t.stop = function () {
                var t, n;
                this.active &&
                  ((this.active = !1),
                  (n = e.inArray(this, c)) >= 0 &&
                    ((t = c.slice(n + 1)),
                    (c.length = n),
                    t.length && (c = c.concat(t))));
              }),
              (t.render = function (e) {
                var t,
                  n = e - this.start;
                if (this.delay) {
                  if (n <= this.delay) return;
                  n -= this.delay;
                }
                if (n < this.duration) {
                  var i,
                    o,
                    a = this.ease(n, 0, 1, this.duration);
                  return (
                    (t = this.startRGB
                      ? ((i = this.startRGB),
                        (o = this.endRGB),
                        r(
                          i[0] + a * (o[0] - i[0]),
                          i[1] + a * (o[1] - i[1]),
                          i[2] + a * (o[2] - i[2])
                        ))
                      : Math.round((this.begin + a * this.change) * s) / s),
                    (this.value = t + this.unit),
                    void this.update.call(this.context, this.value)
                  );
                }
                (t = this.endHex || this.begin + this.change),
                  (this.value = t + this.unit),
                  this.update.call(this.context, this.value),
                  this.complete.call(this.context),
                  this.destroy();
              }),
              (t.format = function (e, t) {
                if (((t += ""), "#" == (e += "").charAt(0)))
                  return (
                    (this.startRGB = n(t)),
                    (this.endRGB = n(e)),
                    (this.endHex = e),
                    (this.begin = 0),
                    void (this.change = 1)
                  );
                if (!this.unit) {
                  var r = t.replace(E, "");
                  r !== e.replace(E, "") &&
                    a("Units do not match [tween]: " + t + ", " + e),
                    (this.unit = r);
                }
                (t = parseFloat(t)),
                  (e = parseFloat(e)),
                  (this.begin = this.value = t),
                  (this.change = e - t);
              }),
              (t.destroy = function () {
                this.stop(),
                  (this.context = null),
                  (this.ease = this.update = this.complete = i);
              });
            var c = [],
              s = 1e3;
          }),
          B = l(U, function (e) {
            (e.init = function (e) {
              (this.duration = e.duration || 0),
                (this.complete = e.complete || i),
                (this.context = e.context),
                this.play();
            }),
              (e.render = function (e) {
                e - this.start < this.duration ||
                  (this.complete.call(this.context), this.destroy());
              });
          }),
          V = l(U, function (e, t) {
            (e.init = function (e) {
              var t, n;
              for (t in ((this.context = e.context),
              (this.update = e.update),
              (this.tweens = []),
              (this.current = e.current),
              e.values))
                (n = e.values[t]),
                  this.current[t] !== n &&
                    this.tweens.push(
                      new U({
                        name: t,
                        from: this.current[t],
                        to: n,
                        duration: e.duration,
                        delay: e.delay,
                        ease: e.ease,
                        autoplay: !1,
                      })
                    );
              this.play();
            }),
              (e.render = function (e) {
                var t,
                  n,
                  r = this.tweens.length,
                  i = !1;
                for (t = r; t--; )
                  (n = this.tweens[t]).context &&
                    (n.render(e), (this.current[n.name] = n.value), (i = !0));
                return i
                  ? void (this.update && this.update.call(this.context))
                  : this.destroy();
              }),
              (e.destroy = function () {
                if ((t.destroy.call(this), this.tweens)) {
                  var e;
                  for (e = this.tweens.length; e--; ) this.tweens[e].destroy();
                  (this.tweens = null), (this.current = null);
                }
              });
          }),
          X = (t.config = {
            debug: !1,
            defaultUnit: "px",
            defaultAngle: "deg",
            keepInherited: !1,
            hideBackface: !1,
            perspective: "",
            fallback: !N.transition,
            agentTests: [],
          });
        (t.fallback = function (e) {
          if (!N.transition) return (X.fallback = !0);
          X.agentTests.push("(" + e + ")");
          var t = RegExp(X.agentTests.join("|"), "i");
          X.fallback = t.test(navigator.userAgent);
        }),
          t.fallback("6.0.[2-5] Safari"),
          (t.tween = function (e) {
            return new U(e);
          }),
          (t.delay = function (e, t, n) {
            return new B({ complete: t, duration: e, context: n });
          }),
          (e.fn.tram = function (e) {
            return t.call(null, this, e);
          });
        var W = e.style,
          H = e.css,
          $ = { transform: N.transform && N.transform.css },
          z = {
            color: [x, y],
            background: [x, y, "background-color"],
            "outline-color": [x, y],
            "border-color": [x, y],
            "border-top-color": [x, y],
            "border-right-color": [x, y],
            "border-bottom-color": [x, y],
            "border-left-color": [x, y],
            "border-width": [k, v],
            "border-top-width": [k, v],
            "border-right-width": [k, v],
            "border-bottom-width": [k, v],
            "border-left-width": [k, v],
            "border-spacing": [k, v],
            "letter-spacing": [k, v],
            margin: [k, v],
            "margin-top": [k, v],
            "margin-right": [k, v],
            "margin-bottom": [k, v],
            "margin-left": [k, v],
            padding: [k, v],
            "padding-top": [k, v],
            "padding-right": [k, v],
            "padding-bottom": [k, v],
            "padding-left": [k, v],
            "outline-width": [k, v],
            opacity: [k, m],
            top: [k, _],
            right: [k, _],
            bottom: [k, _],
            left: [k, _],
            "font-size": [k, _],
            "text-indent": [k, _],
            "word-spacing": [k, _],
            width: [k, _],
            "min-width": [k, _],
            "max-width": [k, _],
            height: [k, _],
            "min-height": [k, _],
            "max-height": [k, _],
            "line-height": [k, b],
            "scroll-top": [G, m, "scrollTop"],
            "scroll-left": [G, m, "scrollLeft"],
          },
          Y = {};
        N.transform &&
          ((z.transform = [j]),
          (Y = {
            x: [_, "translateX"],
            y: [_, "translateY"],
            rotate: [I],
            rotateX: [I],
            rotateY: [I],
            scale: [m],
            scaleX: [m],
            scaleY: [m],
            skew: [I],
            skewX: [I],
            skewY: [I],
          })),
          N.transform &&
            N.backface &&
            ((Y.z = [_, "translateZ"]),
            (Y.rotateZ = [I]),
            (Y.scaleZ = [m]),
            (Y.perspective = [v]));
        var q = /ms/,
          Q = /s|\./;
        return (e.tram = t);
      })(window.jQuery);
    },
    5756: function (e, t, n) {
      "use strict";
      var r,
        i,
        o,
        a,
        u,
        c,
        s,
        l,
        f,
        d,
        p,
        h,
        E,
        g,
        m,
        y,
        v,
        _,
        I,
        b,
        T = window.$,
        O = n(5487) && T.tram;
      ((r = {}).VERSION = "1.6.0-Webflow"),
        (i = {}),
        (o = Array.prototype),
        (a = Object.prototype),
        (u = Function.prototype),
        o.push,
        (c = o.slice),
        o.concat,
        a.toString,
        (s = a.hasOwnProperty),
        (l = o.forEach),
        (f = o.map),
        o.reduce,
        o.reduceRight,
        (d = o.filter),
        o.every,
        (p = o.some),
        (h = o.indexOf),
        o.lastIndexOf,
        (E = Object.keys),
        u.bind,
        (g =
          r.each =
          r.forEach =
            function (e, t, n) {
              if (null == e) return e;
              if (l && e.forEach === l) e.forEach(t, n);
              else if (e.length === +e.length) {
                for (var o = 0, a = e.length; o < a; o++)
                  if (t.call(n, e[o], o, e) === i) return;
              } else
                for (var u = r.keys(e), o = 0, a = u.length; o < a; o++)
                  if (t.call(n, e[u[o]], u[o], e) === i) return;
              return e;
            }),
        (r.map = r.collect =
          function (e, t, n) {
            var r = [];
            return null == e
              ? r
              : f && e.map === f
              ? e.map(t, n)
              : (g(e, function (e, i, o) {
                  r.push(t.call(n, e, i, o));
                }),
                r);
          }),
        (r.find = r.detect =
          function (e, t, n) {
            var r;
            return (
              m(e, function (e, i, o) {
                if (t.call(n, e, i, o)) return (r = e), !0;
              }),
              r
            );
          }),
        (r.filter = r.select =
          function (e, t, n) {
            var r = [];
            return null == e
              ? r
              : d && e.filter === d
              ? e.filter(t, n)
              : (g(e, function (e, i, o) {
                  t.call(n, e, i, o) && r.push(e);
                }),
                r);
          }),
        (m =
          r.some =
          r.any =
            function (e, t, n) {
              t || (t = r.identity);
              var o = !1;
              return null == e
                ? o
                : p && e.some === p
                ? e.some(t, n)
                : (g(e, function (e, r, a) {
                    if (o || (o = t.call(n, e, r, a))) return i;
                  }),
                  !!o);
            }),
        (r.contains = r.include =
          function (e, t) {
            return (
              null != e &&
              (h && e.indexOf === h
                ? -1 != e.indexOf(t)
                : m(e, function (e) {
                    return e === t;
                  }))
            );
          }),
        (r.delay = function (e, t) {
          var n = c.call(arguments, 2);
          return setTimeout(function () {
            return e.apply(null, n);
          }, t);
        }),
        (r.defer = function (e) {
          return r.delay.apply(r, [e, 1].concat(c.call(arguments, 1)));
        }),
        (r.throttle = function (e) {
          var t, n, r;
          return function () {
            t ||
              ((t = !0),
              (n = arguments),
              (r = this),
              O.frame(function () {
                (t = !1), e.apply(r, n);
              }));
          };
        }),
        (r.debounce = function (e, t, n) {
          var i,
            o,
            a,
            u,
            c,
            s = function () {
              var l = r.now() - u;
              l < t
                ? (i = setTimeout(s, t - l))
                : ((i = null), n || ((c = e.apply(a, o)), (a = o = null)));
            };
          return function () {
            (a = this), (o = arguments), (u = r.now());
            var l = n && !i;
            return (
              i || (i = setTimeout(s, t)),
              l && ((c = e.apply(a, o)), (a = o = null)),
              c
            );
          };
        }),
        (r.defaults = function (e) {
          if (!r.isObject(e)) return e;
          for (var t = 1, n = arguments.length; t < n; t++) {
            var i = arguments[t];
            for (var o in i) void 0 === e[o] && (e[o] = i[o]);
          }
          return e;
        }),
        (r.keys = function (e) {
          if (!r.isObject(e)) return [];
          if (E) return E(e);
          var t = [];
          for (var n in e) r.has(e, n) && t.push(n);
          return t;
        }),
        (r.has = function (e, t) {
          return s.call(e, t);
        }),
        (r.isObject = function (e) {
          return e === Object(e);
        }),
        (r.now =
          Date.now ||
          function () {
            return new Date().getTime();
          }),
        (r.templateSettings = {
          evaluate: /<%([\s\S]+?)%>/g,
          interpolate: /<%=([\s\S]+?)%>/g,
          escape: /<%-([\s\S]+?)%>/g,
        }),
        (y = /(.)^/),
        (v = {
          "'": "'",
          "\\": "\\",
          "\r": "r",
          "\n": "n",
          "\u2028": "u2028",
          "\u2029": "u2029",
        }),
        (_ = /\\|'|\r|\n|\u2028|\u2029/g),
        (I = function (e) {
          return "\\" + v[e];
        }),
        (b = /^\s*(\w|\$)+\s*$/),
        (r.template = function (e, t, n) {
          !t && n && (t = n);
          var i,
            o = RegExp(
              [
                ((t = r.defaults({}, t, r.templateSettings)).escape || y)
                  .source,
                (t.interpolate || y).source,
                (t.evaluate || y).source,
              ].join("|") + "|$",
              "g"
            ),
            a = 0,
            u = "__p+='";
          e.replace(o, function (t, n, r, i, o) {
            return (
              (u += e.slice(a, o).replace(_, I)),
              (a = o + t.length),
              n
                ? (u += "'+\n((__t=(" + n + "))==null?'':_.escape(__t))+\n'")
                : r
                ? (u += "'+\n((__t=(" + r + "))==null?'':__t)+\n'")
                : i && (u += "';\n" + i + "\n__p+='"),
              t
            );
          }),
            (u += "';\n");
          var c = t.variable;
          if (c) {
            if (!b.test(c))
              throw Error("variable is not a bare identifier: " + c);
          } else (u = "with(obj||{}){\n" + u + "}\n"), (c = "obj");
          u =
            "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" +
            u +
            "return __p;\n";
          try {
            i = Function(t.variable || "obj", "_", u);
          } catch (e) {
            throw ((e.source = u), e);
          }
          var s = function (e) {
            return i.call(this, e, r);
          };
          return (s.source = "function(" + c + "){\n" + u + "}"), s;
        }),
        (e.exports = r);
    },
    9461: function (e, t, n) {
      "use strict";
      var r = n(3949);
      r.define(
        "brand",
        (e.exports = function (e) {
          var t,
            n = {},
            i = document,
            o = e("html"),
            a = e("body"),
            u = window.location,
            c = /PhantomJS/i.test(navigator.userAgent),
            s =
              "fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange";
          function l() {
            var n =
              i.fullScreen ||
              i.mozFullScreen ||
              i.webkitIsFullScreen ||
              i.msFullscreenElement ||
              !!i.webkitFullscreenElement;
            e(t).attr("style", n ? "display: none !important;" : "");
          }
          function f() {
            var e = a.children(".w-webflow-badge"),
              n = e.length && e.get(0) === t,
              i = r.env("editor");
            if (n) {
              i && e.remove();
              return;
            }
            e.length && e.remove(), i || a.append(t);
          }
          return (
            (n.ready = function () {
              var n,
                r,
                a,
                d = o.attr("data-wf-status"),
                p = o.attr("data-wf-domain") || "";
              /\.webflow\.io$/i.test(p) && u.hostname !== p && (d = !0),
                d &&
                  !c &&
                  ((t =
                    t ||
                    ((n = e('<a class="w-webflow-badge"></a>').attr(
                      "href",
                      "https://webflow.com?utm_campaign=brandjs"
                    )),
                    (r = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg"
                      )
                      .attr("alt", "")
                      .css({ marginRight: "4px", width: "26px" })),
                    (a = e("<img>")
                      .attr(
                        "src",
                        "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg"
                      )
                      .attr("alt", "Made in Webflow")),
                    n.append(r, a),
                    n[0])),
                  f(),
                  setTimeout(f, 500),
                  e(i).off(s, l).on(s, l));
            }),
            n
          );
        })
      );
    },
    322: function (e, t, n) {
      "use strict";
      var r = n(3949);
      r.define(
        "edit",
        (e.exports = function (e, t, n) {
          if (
            ((n = n || {}),
            (r.env("test") || r.env("frame")) &&
              !n.fixture &&
              !(function () {
                try {
                  return !!(window.top.__Cypress__ || window.PLAYWRIGHT_TEST);
                } catch (e) {
                  return !1;
                }
              })())
          )
            return { exit: 1 };
          var i,
            o = e(window),
            a = e(document.documentElement),
            u = document.location,
            c = "hashchange",
            s =
              n.load ||
              function () {
                var t, n, r;
                (i = !0),
                  (window.WebflowEditor = !0),
                  o.off(c, f),
                  (t = function (t) {
                    var n;
                    e.ajax({
                      url: p("https://editor-api.webflow.com/api/editor/view"),
                      data: { siteId: a.attr("data-wf-site") },
                      xhrFields: { withCredentials: !0 },
                      dataType: "json",
                      crossDomain: !0,
                      success:
                        ((n = t),
                        function (t) {
                          var r, i, o;
                          if (!t)
                            return void console.error(
                              "Could not load editor data"
                            );
                          (t.thirdPartyCookiesSupported = n),
                            (i =
                              (r = t.scriptPath).indexOf("//") >= 0
                                ? r
                                : p("https://editor-api.webflow.com" + r)),
                            (o = function () {
                              window.WebflowEditor(t);
                            }),
                            e
                              .ajax({
                                type: "GET",
                                url: i,
                                dataType: "script",
                                cache: !0,
                              })
                              .then(o, d);
                        }),
                    });
                  }),
                  ((n = window.document.createElement("iframe")).src =
                    "https://webflow.com/site/third-party-cookie-check.html"),
                  (n.style.display = "none"),
                  (n.sandbox = "allow-scripts allow-same-origin"),
                  (r = function (e) {
                    "WF_third_party_cookies_unsupported" === e.data
                      ? (h(n, r), t(!1))
                      : "WF_third_party_cookies_supported" === e.data &&
                        (h(n, r), t(!0));
                  }),
                  (n.onerror = function () {
                    h(n, r), t(!1);
                  }),
                  window.addEventListener("message", r, !1),
                  window.document.body.appendChild(n);
              },
            l = !1;
          try {
            l =
              localStorage &&
              localStorage.getItem &&
              localStorage.getItem("WebflowEditor");
          } catch (e) {}
          function f() {
            !i && /\?edit/.test(u.hash) && s();
          }
          function d(e, t, n) {
            throw (console.error("Could not load editor script: " + t), n);
          }
          function p(e) {
            return e.replace(/([^:])\/\//g, "$1/");
          }
          function h(e, t) {
            window.removeEventListener("message", t, !1), e.remove();
          }
          return (
            l
              ? s()
              : u.search
              ? (/[?&](edit)(?:[=&?]|$)/.test(u.search) ||
                  /\?edit$/.test(u.href)) &&
                s()
              : o.on(c, f).triggerHandler(c),
            {}
          );
        })
      );
    },
    2338: function (e, t, n) {
      "use strict";
      n(3949).define(
        "focus-visible",
        (e.exports = function () {
          return {
            ready: function () {
              if ("undefined" != typeof document)
                try {
                  document.querySelector(":focus-visible");
                } catch (e) {
                  !(function (e) {
                    var t = !0,
                      n = !1,
                      r = null,
                      i = {
                        text: !0,
                        search: !0,
                        url: !0,
                        tel: !0,
                        email: !0,
                        password: !0,
                        number: !0,
                        date: !0,
                        month: !0,
                        week: !0,
                        time: !0,
                        datetime: !0,
                        "datetime-local": !0,
                      };
                    function o(e) {
                      return (
                        !!e &&
                        e !== document &&
                        "HTML" !== e.nodeName &&
                        "BODY" !== e.nodeName &&
                        "classList" in e &&
                        "contains" in e.classList
                      );
                    }
                    function a(e) {
                      e.getAttribute("data-wf-focus-visible") ||
                        e.setAttribute("data-wf-focus-visible", "true");
                    }
                    function u() {
                      t = !1;
                    }
                    function c() {
                      document.addEventListener("mousemove", s),
                        document.addEventListener("mousedown", s),
                        document.addEventListener("mouseup", s),
                        document.addEventListener("pointermove", s),
                        document.addEventListener("pointerdown", s),
                        document.addEventListener("pointerup", s),
                        document.addEventListener("touchmove", s),
                        document.addEventListener("touchstart", s),
                        document.addEventListener("touchend", s);
                    }
                    function s(e) {
                      (e.target.nodeName &&
                        "html" === e.target.nodeName.toLowerCase()) ||
                        ((t = !1),
                        document.removeEventListener("mousemove", s),
                        document.removeEventListener("mousedown", s),
                        document.removeEventListener("mouseup", s),
                        document.removeEventListener("pointermove", s),
                        document.removeEventListener("pointerdown", s),
                        document.removeEventListener("pointerup", s),
                        document.removeEventListener("touchmove", s),
                        document.removeEventListener("touchstart", s),
                        document.removeEventListener("touchend", s));
                    }
                    document.addEventListener(
                      "keydown",
                      function (n) {
                        n.metaKey ||
                          n.altKey ||
                          n.ctrlKey ||
                          (o(e.activeElement) && a(e.activeElement), (t = !0));
                      },
                      !0
                    ),
                      document.addEventListener("mousedown", u, !0),
                      document.addEventListener("pointerdown", u, !0),
                      document.addEventListener("touchstart", u, !0),
                      document.addEventListener(
                        "visibilitychange",
                        function () {
                          "hidden" === document.visibilityState &&
                            (n && (t = !0), c());
                        },
                        !0
                      ),
                      c(),
                      e.addEventListener(
                        "focus",
                        function (e) {
                          if (o(e.target)) {
                            var n, r, u;
                            (t ||
                              ((r = (n = e.target).type),
                              ("INPUT" === (u = n.tagName) &&
                                i[r] &&
                                !n.readOnly) ||
                                ("TEXTAREA" === u && !n.readOnly) ||
                                n.isContentEditable ||
                                0)) &&
                              a(e.target);
                          }
                        },
                        !0
                      ),
                      e.addEventListener(
                        "blur",
                        function (e) {
                          if (
                            o(e.target) &&
                            e.target.hasAttribute("data-wf-focus-visible")
                          ) {
                            var t;
                            (n = !0),
                              window.clearTimeout(r),
                              (r = window.setTimeout(function () {
                                n = !1;
                              }, 100)),
                              (t = e.target).getAttribute(
                                "data-wf-focus-visible"
                              ) && t.removeAttribute("data-wf-focus-visible");
                          }
                        },
                        !0
                      );
                  })(document);
                }
            },
          };
        })
      );
    },
    8334: function (e, t, n) {
      "use strict";
      var r = n(3949);
      r.define(
        "focus",
        (e.exports = function () {
          var e = [],
            t = !1;
          function n(n) {
            t &&
              (n.preventDefault(),
              n.stopPropagation(),
              n.stopImmediatePropagation(),
              e.unshift(n));
          }
          function i(n) {
            var r, i;
            (i = (r = n.target).tagName),
              ((/^a$/i.test(i) && null != r.href) ||
                (/^(button|textarea)$/i.test(i) && !0 !== r.disabled) ||
                (/^input$/i.test(i) &&
                  /^(button|reset|submit|radio|checkbox)$/i.test(r.type) &&
                  !r.disabled) ||
                (!/^(button|input|textarea|select|a)$/i.test(i) &&
                  !Number.isNaN(Number.parseFloat(r.tabIndex))) ||
                /^audio$/i.test(i) ||
                (/^video$/i.test(i) && !0 === r.controls)) &&
                ((t = !0),
                setTimeout(() => {
                  for (t = !1, n.target.focus(); e.length > 0; ) {
                    var r = e.pop();
                    r.target.dispatchEvent(new MouseEvent(r.type, r));
                  }
                }, 0));
          }
          return {
            ready: function () {
              "undefined" != typeof document &&
                document.body.hasAttribute("data-wf-focus-within") &&
                r.env.safari &&
                (document.addEventListener("mousedown", i, !0),
                document.addEventListener("mouseup", n, !0),
                document.addEventListener("click", n, !0));
            },
          };
        })
      );
    },
    7199: function (e) {
      "use strict";
      var t = window.jQuery,
        n = {},
        r = [],
        i = ".w-ix",
        o = {
          reset: function (e, t) {
            t.__wf_intro = null;
          },
          intro: function (e, r) {
            r.__wf_intro ||
              ((r.__wf_intro = !0), t(r).triggerHandler(n.types.INTRO));
          },
          outro: function (e, r) {
            r.__wf_intro &&
              ((r.__wf_intro = null), t(r).triggerHandler(n.types.OUTRO));
          },
        };
      (n.triggers = {}),
        (n.types = { INTRO: "w-ix-intro" + i, OUTRO: "w-ix-outro" + i }),
        (n.init = function () {
          for (var e = r.length, i = 0; i < e; i++) {
            var a = r[i];
            a[0](0, a[1]);
          }
          (r = []), t.extend(n.triggers, o);
        }),
        (n.async = function () {
          for (var e in o) {
            var t = o[e];
            o.hasOwnProperty(e) &&
              (n.triggers[e] = function (e, n) {
                r.push([t, n]);
              });
          }
        }),
        n.async(),
        (e.exports = n);
    },
    5134: function (e, t, n) {
      "use strict";
      var r = n(7199);
      function i(e, t) {
        var n = document.createEvent("CustomEvent");
        n.initCustomEvent(t, !0, !0, null), e.dispatchEvent(n);
      }
      var o = window.jQuery,
        a = {},
        u = ".w-ix";
      (a.triggers = {}),
        (a.types = { INTRO: "w-ix-intro" + u, OUTRO: "w-ix-outro" + u }),
        o.extend(a.triggers, {
          reset: function (e, t) {
            r.triggers.reset(e, t);
          },
          intro: function (e, t) {
            r.triggers.intro(e, t), i(t, "COMPONENT_ACTIVE");
          },
          outro: function (e, t) {
            r.triggers.outro(e, t), i(t, "COMPONENT_INACTIVE");
          },
        }),
        (e.exports = a);
    },
    941: function (e, t, n) {
      "use strict";
      var r = n(3949),
        i = n(6011);
      i.setEnv(r.env),
        r.define(
          "ix2",
          (e.exports = function () {
            return i;
          })
        );
    },
    3949: function (e, t, n) {
      "use strict";
      var r,
        i,
        o = {},
        a = {},
        u = [],
        c = window.Webflow || [],
        s = window.jQuery,
        l = s(window),
        f = s(document),
        d = s.isFunction,
        p = (o._ = n(5756)),
        h = (o.tram = n(5487) && s.tram),
        E = !1,
        g = !1;
      function m(e) {
        o.env() &&
          (d(e.design) && l.on("__wf_design", e.design),
          d(e.preview) && l.on("__wf_preview", e.preview)),
          d(e.destroy) && l.on("__wf_destroy", e.destroy),
          e.ready &&
            d(e.ready) &&
            (function (e) {
              if (E) return e.ready();
              p.contains(u, e.ready) || u.push(e.ready);
            })(e);
      }
      function y(e) {
        var t;
        d(e.design) && l.off("__wf_design", e.design),
          d(e.preview) && l.off("__wf_preview", e.preview),
          d(e.destroy) && l.off("__wf_destroy", e.destroy),
          e.ready &&
            d(e.ready) &&
            ((t = e),
            (u = p.filter(u, function (e) {
              return e !== t.ready;
            })));
      }
      (h.config.hideBackface = !1),
        (h.config.keepInherited = !0),
        (o.define = function (e, t, n) {
          a[e] && y(a[e]);
          var r = (a[e] = t(s, p, n) || {});
          return m(r), r;
        }),
        (o.require = function (e) {
          return a[e];
        }),
        (o.push = function (e) {
          if (E) {
            d(e) && e();
            return;
          }
          c.push(e);
        }),
        (o.env = function (e) {
          var t = window.__wf_design,
            n = void 0 !== t;
          return e
            ? "design" === e
              ? n && t
              : "preview" === e
              ? n && !t
              : "slug" === e
              ? n && window.__wf_slug
              : "editor" === e
              ? window.WebflowEditor
              : "test" === e
              ? window.__wf_test
              : "frame" === e
              ? window !== window.top
              : void 0
            : n;
        });
      var v = navigator.userAgent.toLowerCase(),
        _ = (o.env.touch =
          "ontouchstart" in window ||
          (window.DocumentTouch && document instanceof window.DocumentTouch)),
        I = (o.env.chrome =
          /chrome/.test(v) &&
          /Google/.test(navigator.vendor) &&
          parseInt(v.match(/chrome\/(\d+)\./)[1], 10)),
        b = (o.env.ios = /(ipod|iphone|ipad)/.test(v));
      (o.env.safari = /safari/.test(v) && !I && !b),
        _ &&
          f.on("touchstart mousedown", function (e) {
            r = e.target;
          }),
        (o.validClick = _
          ? function (e) {
              return e === r || s.contains(e, r);
            }
          : function () {
              return !0;
            });
      var T = "resize.webflow orientationchange.webflow load.webflow",
        O = "scroll.webflow " + T;
      function w(e, t) {
        var n = [],
          r = {};
        return (
          (r.up = p.throttle(function (e) {
            p.each(n, function (t) {
              t(e);
            });
          })),
          e && t && e.on(t, r.up),
          (r.on = function (e) {
            "function" == typeof e && (p.contains(n, e) || n.push(e));
          }),
          (r.off = function (e) {
            if (!arguments.length) {
              n = [];
              return;
            }
            n = p.filter(n, function (t) {
              return t !== e;
            });
          }),
          r
        );
      }
      function A(e) {
        d(e) && e();
      }
      function C() {
        i && (i.reject(), l.off("load", i.resolve)),
          (i = new s.Deferred()),
          l.on("load", i.resolve);
      }
      (o.resize = w(l, T)),
        (o.scroll = w(l, O)),
        (o.redraw = w()),
        (o.location = function (e) {
          window.location = e;
        }),
        o.env() && (o.location = function () {}),
        (o.ready = function () {
          (E = !0),
            g ? ((g = !1), p.each(a, m)) : p.each(u, A),
            p.each(c, A),
            o.resize.up();
        }),
        (o.load = function (e) {
          i.then(e);
        }),
        (o.destroy = function (e) {
          (e = e || {}),
            (g = !0),
            l.triggerHandler("__wf_destroy"),
            null != e.domready && (E = e.domready),
            p.each(a, y),
            o.resize.off(),
            o.scroll.off(),
            o.redraw.off(),
            (u = []),
            (c = []),
            "pending" === i.state() && C();
        }),
        s(o.ready),
        C(),
        (e.exports = window.Webflow = o);
    },
    7624: function (e, t, n) {
      "use strict";
      var r = n(3949);
      r.define(
        "links",
        (e.exports = function (e, t) {
          var n,
            i,
            o,
            a = {},
            u = e(window),
            c = r.env(),
            s = window.location,
            l = document.createElement("a"),
            f = "w--current",
            d = /index\.(html|php)$/,
            p = /\/$/;
          function h() {
            var e = u.scrollTop(),
              n = u.height();
            t.each(i, function (t) {
              if (!t.link.attr("hreflang")) {
                var r = t.link,
                  i = t.sec,
                  o = i.offset().top,
                  a = i.outerHeight(),
                  u = 0.5 * n,
                  c = i.is(":visible") && o + a - u >= e && o + u <= e + n;
                t.active !== c && ((t.active = c), E(r, f, c));
              }
            });
          }
          function E(e, t, n) {
            var r = e.hasClass(t);
            (!n || !r) && (n || r) && (n ? e.addClass(t) : e.removeClass(t));
          }
          return (
            (a.ready =
              a.design =
              a.preview =
                function () {
                  (n = c && r.env("design")),
                    (o = r.env("slug") || s.pathname || ""),
                    r.scroll.off(h),
                    (i = []);
                  for (var t = document.links, a = 0; a < t.length; ++a)
                    !(function (t) {
                      if (!t.getAttribute("hreflang")) {
                        var r =
                          (n && t.getAttribute("href-disabled")) ||
                          t.getAttribute("href");
                        if (((l.href = r), !(r.indexOf(":") >= 0))) {
                          var a = e(t);
                          if (
                            l.hash.length > 1 &&
                            l.host + l.pathname === s.host + s.pathname
                          ) {
                            if (!/^#[a-zA-Z0-9\-\_]+$/.test(l.hash)) return;
                            var u = e(l.hash);
                            u.length && i.push({ link: a, sec: u, active: !1 });
                            return;
                          }
                          "#" !== r &&
                            "" !== r &&
                            E(
                              a,
                              f,
                              l.href === s.href ||
                                r === o ||
                                (d.test(r) && p.test(o))
                            );
                        }
                      }
                    })(t[a]);
                  i.length && (r.scroll.on(h), h());
                }),
            a
          );
        })
      );
    },
    286: function (e, t, n) {
      "use strict";
      var r = n(3949);
      r.define(
        "scroll",
        (e.exports = function (e) {
          var t = {
              WF_CLICK_EMPTY: "click.wf-empty-link",
              WF_CLICK_SCROLL: "click.wf-scroll",
            },
            n = window.location,
            i = !(function () {
              try {
                return !!window.frameElement;
              } catch (e) {
                return !0;
              }
            })()
              ? window.history
              : null,
            o = e(window),
            a = e(document),
            u = e(document.body),
            c =
              window.requestAnimationFrame ||
              window.mozRequestAnimationFrame ||
              window.webkitRequestAnimationFrame ||
              function (e) {
                window.setTimeout(e, 15);
              },
            s = r.env("editor") ? ".w-editor-body" : "body",
            l =
              "header, " +
              s +
              " > .header, " +
              s +
              " > .w-nav:not([data-no-scroll])",
            f = 'a[href="#"]',
            d = 'a[href*="#"]:not(.w-tab-link):not(' + f + ")",
            p = document.createElement("style");
          p.appendChild(
            document.createTextNode(
              '.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}'
            )
          );
          var h = /^#[a-zA-Z0-9][\w:.-]*$/;
          let E =
            "function" == typeof window.matchMedia &&
            window.matchMedia("(prefers-reduced-motion: reduce)");
          function g(e, t) {
            var n;
            switch (t) {
              case "add":
                (n = e.attr("tabindex"))
                  ? e.attr("data-wf-tabindex-swap", n)
                  : e.attr("tabindex", "-1");
                break;
              case "remove":
                (n = e.attr("data-wf-tabindex-swap"))
                  ? (e.attr("tabindex", n),
                    e.removeAttr("data-wf-tabindex-swap"))
                  : e.removeAttr("tabindex");
            }
            e.toggleClass("wf-force-outline-none", "add" === t);
          }
          function m(t) {
            var a = t.currentTarget;
            if (
              !(
                r.env("design") ||
                (window.$.mobile && /(?:^|\s)ui-link(?:$|\s)/.test(a.className))
              )
            ) {
              var s =
                h.test(a.hash) && a.host + a.pathname === n.host + n.pathname
                  ? a.hash
                  : "";
              if ("" !== s) {
                var f,
                  d = e(s);
                d.length &&
                  (t && (t.preventDefault(), t.stopPropagation()),
                  (f = s),
                  n.hash !== f &&
                    i &&
                    i.pushState &&
                    !(r.env.chrome && "file:" === n.protocol) &&
                    (i.state && i.state.hash) !== f &&
                    i.pushState({ hash: f }, "", f),
                  window.setTimeout(function () {
                    !(function (t, n) {
                      var r = o.scrollTop(),
                        i = (function (t) {
                          var n = e(l),
                            r =
                              "fixed" === n.css("position")
                                ? n.outerHeight()
                                : 0,
                            i = t.offset().top - r;
                          if ("mid" === t.data("scroll")) {
                            var a = o.height() - r,
                              u = t.outerHeight();
                            u < a && (i -= Math.round((a - u) / 2));
                          }
                          return i;
                        })(t);
                      if (r !== i) {
                        var a = (function (e, t, n) {
                            if (
                              "none" ===
                                document.body.getAttribute(
                                  "data-wf-scroll-motion"
                                ) ||
                              E.matches
                            )
                              return 0;
                            var r = 1;
                            return (
                              u.add(e).each(function (e, t) {
                                var n = parseFloat(
                                  t.getAttribute("data-scroll-time")
                                );
                                !isNaN(n) && n >= 0 && (r = n);
                              }),
                              (472.143 * Math.log(Math.abs(t - n) + 125) -
                                2e3) *
                                r
                            );
                          })(t, r, i),
                          s = Date.now(),
                          f = function () {
                            var e,
                              t,
                              o,
                              u,
                              l,
                              d = Date.now() - s;
                            window.scroll(
                              0,
                              ((e = r),
                              (t = i),
                              (o = d) > (u = a)
                                ? t
                                : e +
                                  (t - e) *
                                    ((l = o / u) < 0.5
                                      ? 4 * l * l * l
                                      : (l - 1) * (2 * l - 2) * (2 * l - 2) +
                                        1))
                            ),
                              d <= a ? c(f) : "function" == typeof n && n();
                          };
                        c(f);
                      }
                    })(d, function () {
                      g(d, "add"),
                        d.get(0).focus({ preventScroll: !0 }),
                        g(d, "remove");
                    });
                  }, 300 * !t));
              }
            }
          }
          return {
            ready: function () {
              var { WF_CLICK_EMPTY: e, WF_CLICK_SCROLL: n } = t;
              a.on(n, d, m),
                a.on(e, f, function (e) {
                  e.preventDefault();
                }),
                document.head.insertBefore(p, document.head.firstChild);
            },
          };
        })
      );
    },
    3695: function (e, t, n) {
      "use strict";
      n(3949).define(
        "touch",
        (e.exports = function (e) {
          var t = {},
            n = window.getSelection;
          function r(t) {
            var r,
              i,
              o = !1,
              a = !1,
              u = Math.min(Math.round(0.04 * window.innerWidth), 40);
            function c(e) {
              var t = e.touches;
              (t && t.length > 1) ||
                ((o = !0),
                t ? ((a = !0), (r = t[0].clientX)) : (r = e.clientX),
                (i = r));
            }
            function s(t) {
              if (o) {
                if (a && "mousemove" === t.type) {
                  t.preventDefault(), t.stopPropagation();
                  return;
                }
                var r,
                  c,
                  s,
                  l,
                  d = t.touches,
                  p = d ? d[0].clientX : t.clientX,
                  h = p - i;
                (i = p),
                  Math.abs(h) > u &&
                    n &&
                    "" === String(n()) &&
                    ((r = "swipe"),
                    (c = t),
                    (s = { direction: h > 0 ? "right" : "left" }),
                    (l = e.Event(r, { originalEvent: c })),
                    e(c.target).trigger(l, s),
                    f());
              }
            }
            function l(e) {
              if (o && ((o = !1), a && "mouseup" === e.type)) {
                e.preventDefault(), e.stopPropagation(), (a = !1);
                return;
              }
            }
            function f() {
              o = !1;
            }
            t.addEventListener("touchstart", c, !1),
              t.addEventListener("touchmove", s, !1),
              t.addEventListener("touchend", l, !1),
              t.addEventListener("touchcancel", f, !1),
              t.addEventListener("mousedown", c, !1),
              t.addEventListener("mousemove", s, !1),
              t.addEventListener("mouseup", l, !1),
              t.addEventListener("mouseout", f, !1),
              (this.destroy = function () {
                t.removeEventListener("touchstart", c, !1),
                  t.removeEventListener("touchmove", s, !1),
                  t.removeEventListener("touchend", l, !1),
                  t.removeEventListener("touchcancel", f, !1),
                  t.removeEventListener("mousedown", c, !1),
                  t.removeEventListener("mousemove", s, !1),
                  t.removeEventListener("mouseup", l, !1),
                  t.removeEventListener("mouseout", f, !1),
                  (t = null);
              });
          }
          return (
            (e.event.special.tap = {
              bindType: "click",
              delegateType: "click",
            }),
            (t.init = function (t) {
              return (t = "string" == typeof t ? e(t).get(0) : t)
                ? new r(t)
                : null;
            }),
            (t.instance = t.init(document)),
            t
          );
        })
      );
    },
    1655: function (e, t, n) {
      "use strict";
      var r = n(3949),
        i = n(5134);
      let o = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
        ESCAPE: 27,
        SPACE: 32,
        ENTER: 13,
        HOME: 36,
        END: 35,
      };
      r.define(
        "navbar",
        (e.exports = function (e, t) {
          var n,
            a,
            u,
            c,
            s = {},
            l = e.tram,
            f = e(window),
            d = e(document),
            p = t.debounce,
            h = r.env(),
            E = ".w-nav",
            g = "w--open",
            m = "w--nav-dropdown-open",
            y = "w--nav-dropdown-toggle-open",
            v = "w--nav-dropdown-list-open",
            _ = "w--nav-link-open",
            I = i.triggers,
            b = e();
          function T() {
            r.resize.off(O);
          }
          function O() {
            a.each(M);
          }
          function w(n, r) {
            var i,
              a,
              s,
              l,
              p,
              h = e(r),
              g = e.data(r, E);
            g ||
              (g = e.data(r, E, {
                open: !1,
                el: h,
                config: {},
                selectedIdx: -1,
              })),
              (g.menu = h.find(".w-nav-menu")),
              (g.links = g.menu.find(".w-nav-link")),
              (g.dropdowns = g.menu.find(".w-dropdown")),
              (g.dropdownToggle = g.menu.find(".w-dropdown-toggle")),
              (g.dropdownList = g.menu.find(".w-dropdown-list")),
              (g.button = h.find(".w-nav-button")),
              (g.container = h.find(".w-container")),
              (g.overlayContainerId = "w-nav-overlay-" + n),
              (g.outside =
                ((i = g).outside && d.off("click" + E, i.outside),
                function (t) {
                  var n = e(t.target);
                  (c && n.closest(".w-editor-bem-EditorOverlay").length) ||
                    P(i, n);
                }));
            var m = h.find(".w-nav-brand");
            m &&
              "/" === m.attr("href") &&
              null == m.attr("aria-label") &&
              m.attr("aria-label", "home"),
              g.button.attr("style", "-webkit-user-select: text;"),
              null == g.button.attr("aria-label") &&
                g.button.attr("aria-label", "menu"),
              g.button.attr("role", "button"),
              g.button.attr("tabindex", "0"),
              g.button.attr("aria-controls", g.overlayContainerId),
              g.button.attr("aria-haspopup", "menu"),
              g.button.attr("aria-expanded", "false"),
              g.el.off(E),
              g.button.off(E),
              g.menu.off(E),
              R(g),
              u
                ? (C(g),
                  g.el.on(
                    "setting" + E,
                    ((a = g),
                    function (e, n) {
                      n = n || {};
                      var r = f.width();
                      R(a),
                        !0 === n.open && G(a, !0),
                        !1 === n.open && U(a, !0),
                        a.open &&
                          t.defer(function () {
                            r !== f.width() && S(a);
                          });
                    })
                  ))
                : ((s = g).overlay ||
                    ((s.overlay = e(
                      '<div class="w-nav-overlay" data-wf-ignore />'
                    ).appendTo(s.el)),
                    s.overlay.attr("id", s.overlayContainerId),
                    (s.parent = s.menu.parent()),
                    U(s, !0)),
                  g.button.on("click" + E, F(g)),
                  g.menu.on("click" + E, "a", L(g)),
                  g.button.on(
                    "keydown" + E,
                    ((l = g),
                    function (e) {
                      switch (e.keyCode) {
                        case o.SPACE:
                        case o.ENTER:
                          return (
                            F(l)(), e.preventDefault(), e.stopPropagation()
                          );
                        case o.ESCAPE:
                          return U(l), e.preventDefault(), e.stopPropagation();
                        case o.ARROW_RIGHT:
                        case o.ARROW_DOWN:
                        case o.HOME:
                        case o.END:
                          if (!l.open)
                            return e.preventDefault(), e.stopPropagation();
                          return (
                            e.keyCode === o.END
                              ? (l.selectedIdx = l.links.length - 1)
                              : (l.selectedIdx = 0),
                            N(l),
                            e.preventDefault(),
                            e.stopPropagation()
                          );
                      }
                    })
                  ),
                  g.el.on(
                    "keydown" + E,
                    ((p = g),
                    function (e) {
                      if (p.open)
                        switch (
                          ((p.selectedIdx = p.links.index(
                            document.activeElement
                          )),
                          e.keyCode)
                        ) {
                          case o.HOME:
                          case o.END:
                            return (
                              e.keyCode === o.END
                                ? (p.selectedIdx = p.links.length - 1)
                                : (p.selectedIdx = 0),
                              N(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ESCAPE:
                            return (
                              U(p),
                              p.button.focus(),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ARROW_LEFT:
                          case o.ARROW_UP:
                            return (
                              (p.selectedIdx = Math.max(-1, p.selectedIdx - 1)),
                              N(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                          case o.ARROW_RIGHT:
                          case o.ARROW_DOWN:
                            return (
                              (p.selectedIdx = Math.min(
                                p.links.length - 1,
                                p.selectedIdx + 1
                              )),
                              N(p),
                              e.preventDefault(),
                              e.stopPropagation()
                            );
                        }
                    })
                  )),
              M(n, r);
          }
          function A(t, n) {
            var r = e.data(n, E);
            r && (C(r), e.removeData(n, E));
          }
          function C(e) {
            e.overlay && (U(e, !0), e.overlay.remove(), (e.overlay = null));
          }
          function R(e) {
            var n = {},
              r = e.config || {},
              i = (n.animation = e.el.attr("data-animation") || "default");
            (n.animOver = /^over/.test(i)),
              (n.animDirect = /left$/.test(i) ? -1 : 1),
              r.animation !== i && e.open && t.defer(S, e),
              (n.easing = e.el.attr("data-easing") || "ease"),
              (n.easing2 = e.el.attr("data-easing2") || "ease");
            var o = e.el.attr("data-duration");
            (n.duration = null != o ? Number(o) : 400),
              (n.docHeight = e.el.attr("data-doc-height")),
              (e.config = n);
          }
          function N(e) {
            if (e.links[e.selectedIdx]) {
              var t = e.links[e.selectedIdx];
              t.focus(), L(t);
            }
          }
          function S(e) {
            e.open && (U(e, !0), G(e, !0));
          }
          function F(e) {
            return p(function () {
              e.open ? U(e) : G(e);
            });
          }
          function L(t) {
            return function (n) {
              var i = e(this).attr("href");
              if (!r.validClick(n.currentTarget))
                return void n.preventDefault();
              i && 0 === i.indexOf("#") && t.open && U(t);
            };
          }
          (s.ready =
            s.design =
            s.preview =
              function () {
                (u = h && r.env("design")),
                  (c = r.env("editor")),
                  (n = e(document.body)),
                  (a = d.find(E)).length && (a.each(w), T(), r.resize.on(O));
              }),
            (s.destroy = function () {
              (b = e()), T(), a && a.length && a.each(A);
            });
          var P = p(function (e, t) {
            if (e.open) {
              var n = t.closest(".w-nav-menu");
              e.menu.is(n) || U(e);
            }
          });
          function M(t, n) {
            var r = e.data(n, E),
              i = (r.collapsed = "none" !== r.button.css("display"));
            if ((!r.open || i || u || U(r, !0), r.container.length)) {
              var o,
                a =
                  ("none" === (o = r.container.css(D)) && (o = ""),
                  function (t, n) {
                    (n = e(n)).css(D, ""), "none" === n.css(D) && n.css(D, o);
                  });
              r.links.each(a), r.dropdowns.each(a);
            }
            r.open && j(r);
          }
          var D = "max-width";
          function k(e, t) {
            t.setAttribute("data-nav-menu-open", "");
          }
          function x(e, t) {
            t.removeAttribute("data-nav-menu-open");
          }
          function G(e, t) {
            if (!e.open) {
              (e.open = !0),
                e.menu.each(k),
                e.links.addClass(_),
                e.dropdowns.addClass(m),
                e.dropdownToggle.addClass(y),
                e.dropdownList.addClass(v),
                e.button.addClass(g);
              var n = e.config;
              ("none" === n.animation ||
                !l.support.transform ||
                n.duration <= 0) &&
                (t = !0);
              var i = j(e),
                o = e.menu.outerHeight(!0),
                a = e.menu.outerWidth(!0),
                c = e.el.height(),
                s = e.el[0];
              if (
                (M(0, s),
                I.intro(0, s),
                r.redraw.up(),
                u || d.on("click" + E, e.outside),
                t)
              )
                return void p();
              var f = "transform " + n.duration + "ms " + n.easing;
              if (
                (e.overlay &&
                  ((b = e.menu.prev()), e.overlay.show().append(e.menu)),
                n.animOver)
              ) {
                l(e.menu)
                  .add(f)
                  .set({ x: n.animDirect * a, height: i })
                  .start({ x: 0 })
                  .then(p),
                  e.overlay && e.overlay.width(a);
                return;
              }
              l(e.menu)
                .add(f)
                .set({ y: -(c + o) })
                .start({ y: 0 })
                .then(p);
            }
            function p() {
              e.button.attr("aria-expanded", "true");
            }
          }
          function j(e) {
            var t = e.config,
              r = t.docHeight ? d.height() : n.height();
            return (
              t.animOver
                ? e.menu.height(r)
                : "fixed" !== e.el.css("position") &&
                  (r -= e.el.outerHeight(!0)),
              e.overlay && e.overlay.height(r),
              r
            );
          }
          function U(e, t) {
            if (e.open) {
              (e.open = !1), e.button.removeClass(g);
              var n = e.config;
              if (
                (("none" === n.animation ||
                  !l.support.transform ||
                  n.duration <= 0) &&
                  (t = !0),
                I.outro(0, e.el[0]),
                d.off("click" + E, e.outside),
                t)
              ) {
                l(e.menu).stop(), u();
                return;
              }
              var r = "transform " + n.duration + "ms " + n.easing2,
                i = e.menu.outerHeight(!0),
                o = e.menu.outerWidth(!0),
                a = e.el.height();
              if (n.animOver)
                return void l(e.menu)
                  .add(r)
                  .start({ x: o * n.animDirect })
                  .then(u);
              l(e.menu)
                .add(r)
                .start({ y: -(a + i) })
                .then(u);
            }
            function u() {
              e.menu.height(""),
                l(e.menu).set({ x: 0, y: 0 }),
                e.menu.each(x),
                e.links.removeClass(_),
                e.dropdowns.removeClass(m),
                e.dropdownToggle.removeClass(y),
                e.dropdownList.removeClass(v),
                e.overlay &&
                  e.overlay.children().length &&
                  (b.length
                    ? e.menu.insertAfter(b)
                    : e.menu.prependTo(e.parent),
                  e.overlay.attr("style", "").hide()),
                e.el.triggerHandler("w-close"),
                e.button.attr("aria-expanded", "false");
            }
          }
          return s;
        })
      );
    },
    3946: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        actionListPlaybackChanged: function () {
          return H;
        },
        animationFrameChanged: function () {
          return j;
        },
        clearRequested: function () {
          return D;
        },
        elementStateChanged: function () {
          return W;
        },
        eventListenerAdded: function () {
          return k;
        },
        eventStateChanged: function () {
          return G;
        },
        instanceAdded: function () {
          return B;
        },
        instanceRemoved: function () {
          return X;
        },
        instanceStarted: function () {
          return V;
        },
        mediaQueriesDefined: function () {
          return z;
        },
        parameterChanged: function () {
          return U;
        },
        playbackRequested: function () {
          return P;
        },
        previewRequested: function () {
          return L;
        },
        rawDataImported: function () {
          return R;
        },
        sessionInitialized: function () {
          return N;
        },
        sessionStarted: function () {
          return S;
        },
        sessionStopped: function () {
          return F;
        },
        stopRequested: function () {
          return M;
        },
        testFrameRendered: function () {
          return x;
        },
        viewportWidthChanged: function () {
          return $;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = n(7087),
        a = n(9468),
        {
          IX2_RAW_DATA_IMPORTED: u,
          IX2_SESSION_INITIALIZED: c,
          IX2_SESSION_STARTED: s,
          IX2_SESSION_STOPPED: l,
          IX2_PREVIEW_REQUESTED: f,
          IX2_PLAYBACK_REQUESTED: d,
          IX2_STOP_REQUESTED: p,
          IX2_CLEAR_REQUESTED: h,
          IX2_EVENT_LISTENER_ADDED: E,
          IX2_TEST_FRAME_RENDERED: g,
          IX2_EVENT_STATE_CHANGED: m,
          IX2_ANIMATION_FRAME_CHANGED: y,
          IX2_PARAMETER_CHANGED: v,
          IX2_INSTANCE_ADDED: _,
          IX2_INSTANCE_STARTED: I,
          IX2_INSTANCE_REMOVED: b,
          IX2_ELEMENT_STATE_CHANGED: T,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: O,
          IX2_VIEWPORT_WIDTH_CHANGED: w,
          IX2_MEDIA_QUERIES_DEFINED: A,
        } = o.IX2EngineActionTypes,
        { reifyState: C } = a.IX2VanillaUtils,
        R = (e) => ({ type: u, payload: { ...C(e) } }),
        N = ({ hasBoundaryNodes: e, reducedMotion: t }) => ({
          type: c,
          payload: { hasBoundaryNodes: e, reducedMotion: t },
        }),
        S = () => ({ type: s }),
        F = () => ({ type: l }),
        L = ({ rawData: e, defer: t }) => ({
          type: f,
          payload: { defer: t, rawData: e },
        }),
        P = ({
          actionTypeId: e = o.ActionTypeConsts.GENERAL_START_ACTION,
          actionListId: t,
          actionItemId: n,
          eventId: r,
          allowEvents: i,
          immediate: a,
          testManual: u,
          verbose: c,
          rawData: s,
        }) => ({
          type: d,
          payload: {
            actionTypeId: e,
            actionListId: t,
            actionItemId: n,
            testManual: u,
            eventId: r,
            allowEvents: i,
            immediate: a,
            verbose: c,
            rawData: s,
          },
        }),
        M = (e) => ({ type: p, payload: { actionListId: e } }),
        D = () => ({ type: h }),
        k = (e, t) => ({ type: E, payload: { target: e, listenerParams: t } }),
        x = (e = 1) => ({ type: g, payload: { step: e } }),
        G = (e, t) => ({ type: m, payload: { stateKey: e, newState: t } }),
        j = (e, t) => ({ type: y, payload: { now: e, parameters: t } }),
        U = (e, t) => ({ type: v, payload: { key: e, value: t } }),
        B = (e) => ({ type: _, payload: { ...e } }),
        V = (e, t) => ({ type: I, payload: { instanceId: e, time: t } }),
        X = (e) => ({ type: b, payload: { instanceId: e } }),
        W = (e, t, n, r) => ({
          type: T,
          payload: { elementId: e, actionTypeId: t, current: n, actionItem: r },
        }),
        H = ({ actionListId: e, isPlaying: t }) => ({
          type: O,
          payload: { actionListId: e, isPlaying: t },
        }),
        $ = ({ width: e, mediaQueries: t }) => ({
          type: w,
          payload: { width: e, mediaQueries: t },
        }),
        z = () => ({ type: A });
    },
    6011: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r,
        i = {
          actions: function () {
            return s;
          },
          destroy: function () {
            return h;
          },
          init: function () {
            return p;
          },
          setEnv: function () {
            return d;
          },
          store: function () {
            return f;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let a = n(9516),
        u = (r = n(7243)) && r.__esModule ? r : { default: r },
        c = n(1970),
        s = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = l(t);
          if (n && n.has(e)) return n.get(e);
          var r = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              a && (a.get || a.set)
                ? Object.defineProperty(r, o, a)
                : (r[o] = e[o]);
            }
          return (r.default = e), n && n.set(e, r), r;
        })(n(3946));
      function l(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (l = function (e) {
          return e ? n : t;
        })(e);
      }
      let f = (0, a.createStore)(u.default);
      function d(e) {
        e() && (0, c.observeRequests)(f);
      }
      function p(e) {
        h(), (0, c.startEngine)({ store: f, rawData: e, allowEvents: !0 });
      }
      function h() {
        (0, c.stopEngine)(f);
      }
    },
    5012: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        elementContains: function () {
          return v;
        },
        getChildElements: function () {
          return I;
        },
        getClosestElement: function () {
          return T;
        },
        getProperty: function () {
          return h;
        },
        getQuerySelector: function () {
          return g;
        },
        getRefType: function () {
          return O;
        },
        getSiblingElements: function () {
          return b;
        },
        getStyle: function () {
          return p;
        },
        getValidDocument: function () {
          return m;
        },
        isSiblingNode: function () {
          return _;
        },
        matchSelector: function () {
          return E;
        },
        queryDocument: function () {
          return y;
        },
        setStyle: function () {
          return d;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = n(9468),
        a = n(7087),
        { ELEMENT_MATCHES: u } = o.IX2BrowserSupport,
        {
          IX2_ID_DELIMITER: c,
          HTML_ELEMENT: s,
          PLAIN_OBJECT: l,
          WF_PAGE: f,
        } = a.IX2EngineConstants;
      function d(e, t, n) {
        e.style[t] = n;
      }
      function p(e, t) {
        return t.startsWith("--")
          ? window
              .getComputedStyle(document.documentElement)
              .getPropertyValue(t)
          : e.style instanceof CSSStyleDeclaration
          ? e.style[t]
          : void 0;
      }
      function h(e, t) {
        return e[t];
      }
      function E(e) {
        return (t) => t[u](e);
      }
      function g({ id: e, selector: t }) {
        if (e) {
          let t = e;
          if (-1 !== e.indexOf(c)) {
            let n = e.split(c),
              r = n[0];
            if (((t = n[1]), r !== document.documentElement.getAttribute(f)))
              return null;
          }
          return `[data-w-id="${t}"], [data-w-id^="${t}_instance"]`;
        }
        return t;
      }
      function m(e) {
        return null == e || e === document.documentElement.getAttribute(f)
          ? document
          : null;
      }
      function y(e, t) {
        return Array.prototype.slice.call(
          document.querySelectorAll(t ? e + " " + t : e)
        );
      }
      function v(e, t) {
        return e.contains(t);
      }
      function _(e, t) {
        return e !== t && e.parentNode === t.parentNode;
      }
      function I(e) {
        let t = [];
        for (let n = 0, { length: r } = e || []; n < r; n++) {
          let { children: r } = e[n],
            { length: i } = r;
          if (i) for (let e = 0; e < i; e++) t.push(r[e]);
        }
        return t;
      }
      function b(e = []) {
        let t = [],
          n = [];
        for (let r = 0, { length: i } = e; r < i; r++) {
          let { parentNode: i } = e[r];
          if (!i || !i.children || !i.children.length || -1 !== n.indexOf(i))
            continue;
          n.push(i);
          let o = i.firstElementChild;
          for (; null != o; )
            -1 === e.indexOf(o) && t.push(o), (o = o.nextElementSibling);
        }
        return t;
      }
      let T = Element.prototype.closest
        ? (e, t) => (document.documentElement.contains(e) ? e.closest(t) : null)
        : (e, t) => {
            if (!document.documentElement.contains(e)) return null;
            let n = e;
            do {
              if (n[u] && n[u](t)) return n;
              n = n.parentNode;
            } while (null != n);
            return null;
          };
      function O(e) {
        return null != e && "object" == typeof e
          ? e instanceof Element
            ? s
            : l
          : null;
      }
    },
    1970: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        observeRequests: function () {
          return K;
        },
        startActionGroup: function () {
          return eh;
        },
        startEngine: function () {
          return er;
        },
        stopActionGroup: function () {
          return ep;
        },
        stopAllActionGroups: function () {
          return ed;
        },
        stopEngine: function () {
          return ei;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = y(n(9777)),
        a = y(n(4738)),
        u = y(n(4659)),
        c = y(n(3452)),
        s = y(n(6633)),
        l = y(n(3729)),
        f = y(n(2397)),
        d = y(n(5082)),
        p = n(7087),
        h = n(9468),
        E = n(3946),
        g = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = v(t);
          if (n && n.has(e)) return n.get(e);
          var r = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              a && (a.get || a.set)
                ? Object.defineProperty(r, o, a)
                : (r[o] = e[o]);
            }
          return (r.default = e), n && n.set(e, r), r;
        })(n(5012)),
        m = y(n(8955));
      function y(e) {
        return e && e.__esModule ? e : { default: e };
      }
      function v(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (v = function (e) {
          return e ? n : t;
        })(e);
      }
      let _ = Object.keys(p.QuickEffectIds),
        I = (e) => _.includes(e),
        {
          COLON_DELIMITER: b,
          BOUNDARY_SELECTOR: T,
          HTML_ELEMENT: O,
          RENDER_GENERAL: w,
          W_MOD_IX: A,
        } = p.IX2EngineConstants,
        {
          getAffectedElements: C,
          getElementId: R,
          getDestinationValues: N,
          observeStore: S,
          getInstanceId: F,
          renderHTMLElement: L,
          clearAllStyles: P,
          getMaxDurationItemIndex: M,
          getComputedStyle: D,
          getInstanceOrigin: k,
          reduceListToGroup: x,
          shouldNamespaceEventParameter: G,
          getNamespacedParameterId: j,
          shouldAllowMediaQuery: U,
          cleanupHTMLElement: B,
          clearObjectCache: V,
          stringifyTarget: X,
          mediaQueriesEqual: W,
          shallowEqual: H,
        } = h.IX2VanillaUtils,
        {
          isPluginType: $,
          createPluginInstance: z,
          getPluginDuration: Y,
        } = h.IX2VanillaPlugins,
        q = navigator.userAgent,
        Q = q.match(/iPad/i) || q.match(/iPhone/);
      function K(e) {
        S({ store: e, select: ({ ixRequest: e }) => e.preview, onChange: Z }),
          S({
            store: e,
            select: ({ ixRequest: e }) => e.playback,
            onChange: ee,
          }),
          S({ store: e, select: ({ ixRequest: e }) => e.stop, onChange: et }),
          S({ store: e, select: ({ ixRequest: e }) => e.clear, onChange: en });
      }
      function Z({ rawData: e, defer: t }, n) {
        let r = () => {
          er({ store: n, rawData: e, allowEvents: !0 }), J();
        };
        t ? setTimeout(r, 0) : r();
      }
      function J() {
        document.dispatchEvent(new CustomEvent("IX2_PAGE_UPDATE"));
      }
      function ee(e, t) {
        let {
            actionTypeId: n,
            actionListId: r,
            actionItemId: i,
            eventId: o,
            allowEvents: a,
            immediate: u,
            testManual: c,
            verbose: s = !0,
          } = e,
          { rawData: l } = e;
        if (r && i && l && u) {
          let e = l.actionLists[r];
          e && (l = x({ actionList: e, actionItemId: i, rawData: l }));
        }
        if (
          (er({ store: t, rawData: l, allowEvents: a, testManual: c }),
          (r && n === p.ActionTypeConsts.GENERAL_START_ACTION) || I(n))
        ) {
          ep({ store: t, actionListId: r }),
            ef({ store: t, actionListId: r, eventId: o });
          let e = eh({
            store: t,
            eventId: o,
            actionListId: r,
            immediate: u,
            verbose: s,
          });
          s &&
            e &&
            t.dispatch(
              (0, E.actionListPlaybackChanged)({
                actionListId: r,
                isPlaying: !u,
              })
            );
        }
      }
      function et({ actionListId: e }, t) {
        e ? ep({ store: t, actionListId: e }) : ed({ store: t }), ei(t);
      }
      function en(e, t) {
        ei(t), P({ store: t, elementApi: g });
      }
      function er({ store: e, rawData: t, allowEvents: n, testManual: r }) {
        let { ixSession: i } = e.getState();
        if ((t && e.dispatch((0, E.rawDataImported)(t)), !i.active)) {
          (e.dispatch(
            (0, E.sessionInitialized)({
              hasBoundaryNodes: !!document.querySelector(T),
              reducedMotion:
                document.body.hasAttribute("data-wf-ix-vacation") &&
                window.matchMedia("(prefers-reduced-motion)").matches,
            })
          ),
          n) &&
            ((function (e) {
              let { ixData: t } = e.getState(),
                { eventTypeMap: n } = t;
              eu(e),
                (0, f.default)(n, (t, n) => {
                  let r = m.default[n];
                  if (!r)
                    return void console.warn(
                      `IX2 event type not configured: ${n}`
                    );
                  !(function ({ logic: e, store: t, events: n }) {
                    !(function (e) {
                      if (!Q) return;
                      let t = {},
                        n = "";
                      for (let r in e) {
                        let { eventTypeId: i, target: o } = e[r],
                          a = g.getQuerySelector(o);
                        t[a] ||
                          ((i === p.EventTypeConsts.MOUSE_CLICK ||
                            i === p.EventTypeConsts.MOUSE_SECOND_CLICK) &&
                            ((t[a] = !0),
                            (n +=
                              a +
                              "{cursor: pointer;touch-action: manipulation;}")));
                      }
                      if (n) {
                        let e = document.createElement("style");
                        (e.textContent = n), document.body.appendChild(e);
                      }
                    })(n);
                    let { types: r, handler: i } = e,
                      { ixData: c } = t.getState(),
                      { actionLists: s } = c,
                      l = ec(n, el);
                    if (!(0, u.default)(l)) return;
                    (0, f.default)(l, (e, r) => {
                      let i = n[r],
                        {
                          action: u,
                          id: l,
                          mediaQueries: f = c.mediaQueryKeys,
                        } = i,
                        { actionListId: d } = u.config;
                      W(f, c.mediaQueryKeys) ||
                        t.dispatch((0, E.mediaQueriesDefined)()),
                        u.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION &&
                          (Array.isArray(i.config)
                            ? i.config
                            : [i.config]
                          ).forEach((n) => {
                            let { continuousParameterGroupId: r } = n,
                              i = (0, a.default)(
                                s,
                                `${d}.continuousParameterGroups`,
                                []
                              ),
                              u = (0, o.default)(i, ({ id: e }) => e === r),
                              c = (n.smoothing || 0) / 100,
                              f = (n.restingState || 0) / 100;
                            u &&
                              e.forEach((e, r) => {
                                !(function ({
                                  store: e,
                                  eventStateKey: t,
                                  eventTarget: n,
                                  eventId: r,
                                  eventConfig: i,
                                  actionListId: o,
                                  parameterGroup: u,
                                  smoothing: c,
                                  restingValue: s,
                                }) {
                                  let { ixData: l, ixSession: f } =
                                      e.getState(),
                                    { events: d } = l,
                                    h = d[r],
                                    { eventTypeId: E } = h,
                                    m = {},
                                    y = {},
                                    v = [],
                                    { continuousActionGroups: _ } = u,
                                    { id: I } = u;
                                  G(E, i) && (I = j(t, I));
                                  let O =
                                    f.hasBoundaryNodes && n
                                      ? g.getClosestElement(n, T)
                                      : null;
                                  _.forEach((e) => {
                                    let { keyframe: t, actionItems: r } = e;
                                    r.forEach((e) => {
                                      let { actionTypeId: r } = e,
                                        { target: i } = e.config;
                                      if (!i) return;
                                      let o = i.boundaryMode ? O : null,
                                        a = X(i) + b + r;
                                      if (
                                        ((y[a] = (function (e = [], t, n) {
                                          let r,
                                            i = [...e];
                                          return (
                                            i.some(
                                              (e, n) =>
                                                e.keyframe === t &&
                                                ((r = n), !0)
                                            ),
                                            null == r &&
                                              ((r = i.length),
                                              i.push({
                                                keyframe: t,
                                                actionItems: [],
                                              })),
                                            i[r].actionItems.push(n),
                                            i
                                          );
                                        })(y[a], t, e)),
                                        !m[a])
                                      ) {
                                        m[a] = !0;
                                        let { config: t } = e;
                                        C({
                                          config: t,
                                          event: h,
                                          eventTarget: n,
                                          elementRoot: o,
                                          elementApi: g,
                                        }).forEach((e) => {
                                          v.push({ element: e, key: a });
                                        });
                                      }
                                    });
                                  }),
                                    v.forEach(({ element: t, key: n }) => {
                                      let i = y[n],
                                        u = (0, a.default)(
                                          i,
                                          "[0].actionItems[0]",
                                          {}
                                        ),
                                        { actionTypeId: l } = u,
                                        f = (
                                          l === p.ActionTypeConsts.PLUGIN_RIVE
                                            ? 0 ===
                                              (
                                                u.config?.target
                                                  ?.selectorGuids || []
                                              ).length
                                            : $(l)
                                        )
                                          ? z(l)?.(t, u)
                                          : null,
                                        d = N(
                                          {
                                            element: t,
                                            actionItem: u,
                                            elementApi: g,
                                          },
                                          f
                                        );
                                      eE({
                                        store: e,
                                        element: t,
                                        eventId: r,
                                        actionListId: o,
                                        actionItem: u,
                                        destination: d,
                                        continuous: !0,
                                        parameterId: I,
                                        actionGroups: i,
                                        smoothing: c,
                                        restingValue: s,
                                        pluginInstance: f,
                                      });
                                    });
                                })({
                                  store: t,
                                  eventStateKey: l + b + r,
                                  eventTarget: e,
                                  eventId: l,
                                  eventConfig: n,
                                  actionListId: d,
                                  parameterGroup: u,
                                  smoothing: c,
                                  restingValue: f,
                                });
                              });
                          }),
                        (u.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_START_ACTION ||
                          I(u.actionTypeId)) &&
                          ef({ store: t, actionListId: d, eventId: l });
                    });
                    let h = (e) => {
                        let { ixSession: r } = t.getState();
                        es(l, (o, a, u) => {
                          let s = n[a],
                            l = r.eventState[u],
                            { action: f, mediaQueries: d = c.mediaQueryKeys } =
                              s;
                          if (!U(d, r.mediaQueryKey)) return;
                          let h = (n = {}) => {
                            let r = i(
                              {
                                store: t,
                                element: o,
                                event: s,
                                eventConfig: n,
                                nativeEvent: e,
                                eventStateKey: u,
                              },
                              l
                            );
                            H(r, l) ||
                              t.dispatch((0, E.eventStateChanged)(u, r));
                          };
                          f.actionTypeId ===
                          p.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION
                            ? (Array.isArray(s.config)
                                ? s.config
                                : [s.config]
                              ).forEach(h)
                            : h();
                        });
                      },
                      m = (0, d.default)(h, 12),
                      y = ({ target: e = document, types: n, throttle: r }) => {
                        n.split(" ")
                          .filter(Boolean)
                          .forEach((n) => {
                            let i = r ? m : h;
                            e.addEventListener(n, i),
                              t.dispatch((0, E.eventListenerAdded)(e, [n, i]));
                          });
                      };
                    Array.isArray(r)
                      ? r.forEach(y)
                      : "string" == typeof r && y(e);
                  })({ logic: r, store: e, events: t });
                });
              let { ixSession: r } = e.getState();
              r.eventListeners.length &&
                (function (e) {
                  let t = () => {
                    eu(e);
                  };
                  ea.forEach((n) => {
                    window.addEventListener(n, t),
                      e.dispatch((0, E.eventListenerAdded)(window, [n, t]));
                  }),
                    t();
                })(e);
            })(e),
            (function () {
              let { documentElement: e } = document;
              -1 === e.className.indexOf(A) && (e.className += ` ${A}`);
            })(),
            e.getState().ixSession.hasDefinedMediaQueries &&
              S({
                store: e,
                select: ({ ixSession: e }) => e.mediaQueryKey,
                onChange: () => {
                  ei(e),
                    P({ store: e, elementApi: g }),
                    er({ store: e, allowEvents: !0 }),
                    J();
                },
              }));
          e.dispatch((0, E.sessionStarted)()),
            (function (e, t) {
              let n = (r) => {
                let { ixSession: i, ixParameters: o } = e.getState();
                if (i.active)
                  if ((e.dispatch((0, E.animationFrameChanged)(r, o)), t)) {
                    let t = S({
                      store: e,
                      select: ({ ixSession: e }) => e.tick,
                      onChange: (e) => {
                        n(e), t();
                      },
                    });
                  } else requestAnimationFrame(n);
              };
              n(window.performance.now());
            })(e, r);
        }
      }
      function ei(e) {
        let { ixSession: t } = e.getState();
        if (t.active) {
          let { eventListeners: n } = t;
          n.forEach(eo), V(), e.dispatch((0, E.sessionStopped)());
        }
      }
      function eo({ target: e, listenerParams: t }) {
        e.removeEventListener.apply(e, t);
      }
      let ea = ["resize", "orientationchange"];
      function eu(e) {
        let { ixSession: t, ixData: n } = e.getState(),
          r = window.innerWidth;
        if (r !== t.viewportWidth) {
          let { mediaQueries: t } = n;
          e.dispatch(
            (0, E.viewportWidthChanged)({ width: r, mediaQueries: t })
          );
        }
      }
      let ec = (e, t) => (0, c.default)((0, l.default)(e, t), s.default),
        es = (e, t) => {
          (0, f.default)(e, (e, n) => {
            e.forEach((e, r) => {
              t(e, n, n + b + r);
            });
          });
        },
        el = (e) =>
          C({
            config: { target: e.target, targets: e.targets },
            elementApi: g,
          });
      function ef({ store: e, actionListId: t, eventId: n }) {
        let { ixData: r, ixSession: i } = e.getState(),
          { actionLists: o, events: u } = r,
          c = u[n],
          s = o[t];
        if (s && s.useFirstGroupAsInitialState) {
          let o = (0, a.default)(s, "actionItemGroups[0].actionItems", []);
          if (
            !U(
              (0, a.default)(c, "mediaQueries", r.mediaQueryKeys),
              i.mediaQueryKey
            )
          )
            return;
          o.forEach((r) => {
            let { config: i, actionTypeId: o } = r,
              a = C({
                config:
                  i?.target?.useEventTarget === !0 &&
                  i?.target?.objectId == null
                    ? { target: c.target, targets: c.targets }
                    : i,
                event: c,
                elementApi: g,
              }),
              u = $(o);
            a.forEach((i) => {
              let a = u ? z(o)?.(i, r) : null;
              eE({
                destination: N({ element: i, actionItem: r, elementApi: g }, a),
                immediate: !0,
                store: e,
                element: i,
                eventId: n,
                actionItem: r,
                actionListId: t,
                pluginInstance: a,
              });
            });
          });
        }
      }
      function ed({ store: e }) {
        let { ixInstances: t } = e.getState();
        (0, f.default)(t, (t) => {
          if (!t.continuous) {
            let { actionListId: n, verbose: r } = t;
            eg(t, e),
              r &&
                e.dispatch(
                  (0, E.actionListPlaybackChanged)({
                    actionListId: n,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function ep({
        store: e,
        eventId: t,
        eventTarget: n,
        eventStateKey: r,
        actionListId: i,
      }) {
        let { ixInstances: o, ixSession: u } = e.getState(),
          c = u.hasBoundaryNodes && n ? g.getClosestElement(n, T) : null;
        (0, f.default)(o, (n) => {
          let o = (0, a.default)(n, "actionItem.config.target.boundaryMode"),
            u = !r || n.eventStateKey === r;
          if (n.actionListId === i && n.eventId === t && u) {
            if (c && o && !g.elementContains(c, n.element)) return;
            eg(n, e),
              n.verbose &&
                e.dispatch(
                  (0, E.actionListPlaybackChanged)({
                    actionListId: i,
                    isPlaying: !1,
                  })
                );
          }
        });
      }
      function eh({
        store: e,
        eventId: t,
        eventTarget: n,
        eventStateKey: r,
        actionListId: i,
        groupIndex: o = 0,
        immediate: u,
        verbose: c,
      }) {
        let { ixData: s, ixSession: l } = e.getState(),
          { events: f } = s,
          d = f[t] || {},
          { mediaQueries: p = s.mediaQueryKeys } = d,
          { actionItemGroups: h, useFirstGroupAsInitialState: E } = (0,
          a.default)(s, `actionLists.${i}`, {});
        if (!h || !h.length) return !1;
        o >= h.length && (0, a.default)(d, "config.loop") && (o = 0),
          0 === o && E && o++;
        let m =
            (0 === o || (1 === o && E)) && I(d.action?.actionTypeId)
              ? d.config.delay
              : void 0,
          y = (0, a.default)(h, [o, "actionItems"], []);
        if (!y.length || !U(p, l.mediaQueryKey)) return !1;
        let v = l.hasBoundaryNodes && n ? g.getClosestElement(n, T) : null,
          _ = M(y),
          b = !1;
        return (
          y.forEach((a, s) => {
            let { config: l, actionTypeId: f } = a,
              p = $(f),
              { target: h } = l;
            h &&
              C({
                config: l,
                event: d,
                eventTarget: n,
                elementRoot: h.boundaryMode ? v : null,
                elementApi: g,
              }).forEach((l, d) => {
                let h = p ? z(f)?.(l, a) : null,
                  E = p ? Y(f)(l, a) : null;
                b = !0;
                let y = D({ element: l, actionItem: a }),
                  v = N({ element: l, actionItem: a, elementApi: g }, h);
                eE({
                  store: e,
                  element: l,
                  actionItem: a,
                  eventId: t,
                  eventTarget: n,
                  eventStateKey: r,
                  actionListId: i,
                  groupIndex: o,
                  isCarrier: _ === s && 0 === d,
                  computedStyle: y,
                  destination: v,
                  immediate: u,
                  verbose: c,
                  pluginInstance: h,
                  pluginDuration: E,
                  instanceDelay: m,
                });
              });
          }),
          b
        );
      }
      function eE(e) {
        let t,
          { store: n, computedStyle: r, ...i } = e,
          {
            element: o,
            actionItem: a,
            immediate: u,
            pluginInstance: c,
            continuous: s,
            restingValue: l,
            eventId: f,
          } = i,
          d = F(),
          { ixElements: h, ixSession: m, ixData: y } = n.getState(),
          v = R(h, o),
          { refState: _ } = h[v] || {},
          I = g.getRefType(o),
          b = m.reducedMotion && p.ReducedMotionTypes[a.actionTypeId];
        if (b && s)
          switch (y.events[f]?.eventTypeId) {
            case p.EventTypeConsts.MOUSE_MOVE:
            case p.EventTypeConsts.MOUSE_MOVE_IN_VIEWPORT:
              t = l;
              break;
            default:
              t = 0.5;
          }
        let T = k(o, _, r, a, g, c);
        if (
          (n.dispatch(
            (0, E.instanceAdded)({
              instanceId: d,
              elementId: v,
              origin: T,
              refType: I,
              skipMotion: b,
              skipToValue: t,
              ...i,
            })
          ),
          em(document.body, "ix2-animation-started", d),
          u)
        )
          return void (function (e, t) {
            let { ixParameters: n } = e.getState();
            e.dispatch((0, E.instanceStarted)(t, 0)),
              e.dispatch((0, E.animationFrameChanged)(performance.now(), n));
            let { ixInstances: r } = e.getState();
            ey(r[t], e);
          })(n, d);
        S({ store: n, select: ({ ixInstances: e }) => e[d], onChange: ey }),
          s || n.dispatch((0, E.instanceStarted)(d, m.tick));
      }
      function eg(e, t) {
        em(document.body, "ix2-animation-stopping", {
          instanceId: e.id,
          state: t.getState(),
        });
        let { elementId: n, actionItem: r } = e,
          { ixElements: i } = t.getState(),
          { ref: o, refType: a } = i[n] || {};
        a === O && B(o, r, g), t.dispatch((0, E.instanceRemoved)(e.id));
      }
      function em(e, t, n) {
        let r = document.createEvent("CustomEvent");
        r.initCustomEvent(t, !0, !0, n), e.dispatchEvent(r);
      }
      function ey(e, t) {
        let {
            active: n,
            continuous: r,
            complete: i,
            elementId: o,
            actionItem: a,
            actionTypeId: u,
            renderType: c,
            current: s,
            groupIndex: l,
            eventId: f,
            eventTarget: d,
            eventStateKey: p,
            actionListId: h,
            isCarrier: m,
            styleProp: y,
            verbose: v,
            pluginInstance: _,
          } = e,
          { ixData: I, ixSession: b } = t.getState(),
          { events: T } = I,
          { mediaQueries: A = I.mediaQueryKeys } = T && T[f] ? T[f] : {};
        if (U(A, b.mediaQueryKey) && (r || n || i)) {
          if (s || (c === w && i)) {
            t.dispatch((0, E.elementStateChanged)(o, u, s, a));
            let { ixElements: e } = t.getState(),
              { ref: n, refType: r, refState: i } = e[o] || {},
              l = i && i[u];
            (r === O || $(u)) && L(n, i, l, f, a, y, g, c, _);
          }
          if (i) {
            if (m) {
              let e = eh({
                store: t,
                eventId: f,
                eventTarget: d,
                eventStateKey: p,
                actionListId: h,
                groupIndex: l + 1,
                verbose: v,
              });
              v &&
                !e &&
                t.dispatch(
                  (0, E.actionListPlaybackChanged)({
                    actionListId: h,
                    isPlaying: !1,
                  })
                );
            }
            eg(e, t);
          }
        }
      }
    },
    8955: function (e, t, n) {
      "use strict";
      let r;
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return ep;
          },
        });
      let i = f(n(5801)),
        o = f(n(4738)),
        a = f(n(3789)),
        u = n(7087),
        c = n(1970),
        s = n(3946),
        l = n(9468);
      function f(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          MOUSE_CLICK: d,
          MOUSE_SECOND_CLICK: p,
          MOUSE_DOWN: h,
          MOUSE_UP: E,
          MOUSE_OVER: g,
          MOUSE_OUT: m,
          DROPDOWN_CLOSE: y,
          DROPDOWN_OPEN: v,
          SLIDER_ACTIVE: _,
          SLIDER_INACTIVE: I,
          TAB_ACTIVE: b,
          TAB_INACTIVE: T,
          NAVBAR_CLOSE: O,
          NAVBAR_OPEN: w,
          MOUSE_MOVE: A,
          PAGE_SCROLL_DOWN: C,
          SCROLL_INTO_VIEW: R,
          SCROLL_OUT_OF_VIEW: N,
          PAGE_SCROLL_UP: S,
          SCROLLING_IN_VIEW: F,
          PAGE_FINISH: L,
          ECOMMERCE_CART_CLOSE: P,
          ECOMMERCE_CART_OPEN: M,
          PAGE_START: D,
          PAGE_SCROLL: k,
        } = u.EventTypeConsts,
        x = "COMPONENT_ACTIVE",
        G = "COMPONENT_INACTIVE",
        { COLON_DELIMITER: j } = u.IX2EngineConstants,
        { getNamespacedParameterId: U } = l.IX2VanillaUtils,
        B = (e) => (t) => !!("object" == typeof t && e(t)) || t,
        V = B(({ element: e, nativeEvent: t }) => e === t.target),
        X = B(({ element: e, nativeEvent: t }) => e.contains(t.target)),
        W = (0, i.default)([V, X]),
        H = (e, t) => {
          if (t) {
            let { ixData: n } = e.getState(),
              { events: r } = n,
              i = r[t];
            if (i && !ee[i.eventTypeId]) return i;
          }
          return null;
        },
        $ = ({ store: e, event: t }) => {
          let { action: n } = t,
            { autoStopEventId: r } = n.config;
          return !!H(e, r);
        },
        z = ({ store: e, event: t, element: n, eventStateKey: r }, i) => {
          let { action: a, id: u } = t,
            { actionListId: s, autoStopEventId: l } = a.config,
            f = H(e, l);
          return (
            f &&
              (0, c.stopActionGroup)({
                store: e,
                eventId: l,
                eventTarget: n,
                eventStateKey: l + j + r.split(j)[1],
                actionListId: (0, o.default)(f, "action.config.actionListId"),
              }),
            (0, c.stopActionGroup)({
              store: e,
              eventId: u,
              eventTarget: n,
              eventStateKey: r,
              actionListId: s,
            }),
            (0, c.startActionGroup)({
              store: e,
              eventId: u,
              eventTarget: n,
              eventStateKey: r,
              actionListId: s,
            }),
            i
          );
        },
        Y = (e, t) => (n, r) => !0 === e(n, r) ? t(n, r) : r,
        q = { handler: Y(W, z) },
        Q = { ...q, types: [x, G].join(" ") },
        K = [
          { target: window, types: "resize orientationchange", throttle: !0 },
          {
            target: document,
            types: "scroll wheel readystatechange IX2_PAGE_UPDATE",
            throttle: !0,
          },
        ],
        Z = "mouseover mouseout",
        J = { types: K },
        ee = { PAGE_START: D, PAGE_FINISH: L },
        et = (() => {
          let e = void 0 !== window.pageXOffset,
            t =
              "CSS1Compat" === document.compatMode
                ? document.documentElement
                : document.body;
          return () => ({
            scrollLeft: e ? window.pageXOffset : t.scrollLeft,
            scrollTop: e ? window.pageYOffset : t.scrollTop,
            stiffScrollTop: (0, a.default)(
              e ? window.pageYOffset : t.scrollTop,
              0,
              t.scrollHeight - window.innerHeight
            ),
            scrollWidth: t.scrollWidth,
            scrollHeight: t.scrollHeight,
            clientWidth: t.clientWidth,
            clientHeight: t.clientHeight,
            innerWidth: window.innerWidth,
            innerHeight: window.innerHeight,
          });
        })(),
        en = (e, t) =>
          !(
            e.left > t.right ||
            e.right < t.left ||
            e.top > t.bottom ||
            e.bottom < t.top
          ),
        er = ({ element: e, nativeEvent: t }) => {
          let { type: n, target: r, relatedTarget: i } = t,
            o = e.contains(r);
          if ("mouseover" === n && o) return !0;
          let a = e.contains(i);
          return "mouseout" === n && !!o && !!a;
        },
        ei = (e) => {
          let {
              element: t,
              event: { config: n },
            } = e,
            { clientWidth: r, clientHeight: i } = et(),
            o = n.scrollOffsetValue,
            a = "PX" === n.scrollOffsetUnit ? o : (i * (o || 0)) / 100;
          return en(t.getBoundingClientRect(), {
            left: 0,
            top: a,
            right: r,
            bottom: i - a,
          });
        },
        eo = (e) => (t, n) => {
          let { type: r } = t.nativeEvent,
            i = -1 !== [x, G].indexOf(r) ? r === x : n.isActive,
            o = { ...n, isActive: i };
          return ((!n || o.isActive !== n.isActive) && e(t, o)) || o;
        },
        ea = (e) => (t, n) => {
          let r = { elementHovered: er(t) };
          return (
            ((n ? r.elementHovered !== n.elementHovered : r.elementHovered) &&
              e(t, r)) ||
            r
          );
        },
        eu =
          (e) =>
          (t, n = {}) => {
            let r,
              i,
              { stiffScrollTop: o, scrollHeight: a, innerHeight: u } = et(),
              {
                event: { config: c, eventTypeId: s },
              } = t,
              { scrollOffsetValue: l, scrollOffsetUnit: f } = c,
              d = a - u,
              p = Number((o / d).toFixed(2));
            if (n && n.percentTop === p) return n;
            let h = ("PX" === f ? l : (u * (l || 0)) / 100) / d,
              E = 0;
            n &&
              ((r = p > n.percentTop),
              (E = (i = n.scrollingDown !== r) ? p : n.anchorTop));
            let g = s === C ? p >= E + h : p <= E - h,
              m = {
                ...n,
                percentTop: p,
                inBounds: g,
                anchorTop: E,
                scrollingDown: r,
              };
            return (n && g && (i || m.inBounds !== n.inBounds) && e(t, m)) || m;
          },
        ec = (e, t) =>
          e.left > t.left &&
          e.left < t.right &&
          e.top > t.top &&
          e.top < t.bottom,
        es =
          (e) =>
          (t, n = { clickCount: 0 }) => {
            let r = { clickCount: (n.clickCount % 2) + 1 };
            return (r.clickCount !== n.clickCount && e(t, r)) || r;
          },
        el = (e = !0) => ({
          ...Q,
          handler: Y(
            e ? W : V,
            eo((e, t) => (t.isActive ? q.handler(e, t) : t))
          ),
        }),
        ef = (e = !0) => ({
          ...Q,
          handler: Y(
            e ? W : V,
            eo((e, t) => (t.isActive ? t : q.handler(e, t)))
          ),
        }),
        ed = {
          ...J,
          handler:
            ((r = (e, t) => {
              let { elementVisible: n } = t,
                { event: r, store: i } = e,
                { ixData: o } = i.getState(),
                { events: a } = o;
              return !a[r.action.config.autoStopEventId] && t.triggered
                ? t
                : (r.eventTypeId === R) === n
                ? (z(e), { ...t, triggered: !0 })
                : t;
            }),
            (e, t) => {
              let n = { ...t, elementVisible: ei(e) };
              return (
                ((t
                  ? n.elementVisible !== t.elementVisible
                  : n.elementVisible) &&
                  r(e, n)) ||
                n
              );
            }),
        },
        ep = {
          [_]: el(),
          [I]: ef(),
          [v]: el(),
          [y]: ef(),
          [w]: el(!1),
          [O]: ef(!1),
          [b]: el(),
          [T]: ef(),
          [M]: { types: "ecommerce-cart-open", handler: Y(W, z) },
          [P]: { types: "ecommerce-cart-close", handler: Y(W, z) },
          [d]: {
            types: "click",
            handler: Y(
              W,
              es((e, { clickCount: t }) => {
                $(e) ? 1 === t && z(e) : z(e);
              })
            ),
          },
          [p]: {
            types: "click",
            handler: Y(
              W,
              es((e, { clickCount: t }) => {
                2 === t && z(e);
              })
            ),
          },
          [h]: { ...q, types: "mousedown" },
          [E]: { ...q, types: "mouseup" },
          [g]: {
            types: Z,
            handler: Y(
              W,
              ea((e, t) => {
                t.elementHovered && z(e);
              })
            ),
          },
          [m]: {
            types: Z,
            handler: Y(
              W,
              ea((e, t) => {
                t.elementHovered || z(e);
              })
            ),
          },
          [A]: {
            types: "mousemove mouseout scroll",
            handler: (
              {
                store: e,
                element: t,
                eventConfig: n,
                nativeEvent: r,
                eventStateKey: i,
              },
              o = { clientX: 0, clientY: 0, pageX: 0, pageY: 0 }
            ) => {
              let {
                  basedOn: a,
                  selectedAxis: c,
                  continuousParameterGroupId: l,
                  reverse: f,
                  restingState: d = 0,
                } = n,
                {
                  clientX: p = o.clientX,
                  clientY: h = o.clientY,
                  pageX: E = o.pageX,
                  pageY: g = o.pageY,
                } = r,
                m = "X_AXIS" === c,
                y = "mouseout" === r.type,
                v = d / 100,
                _ = l,
                I = !1;
              switch (a) {
                case u.EventBasedOn.VIEWPORT:
                  v = m
                    ? Math.min(p, window.innerWidth) / window.innerWidth
                    : Math.min(h, window.innerHeight) / window.innerHeight;
                  break;
                case u.EventBasedOn.PAGE: {
                  let {
                    scrollLeft: e,
                    scrollTop: t,
                    scrollWidth: n,
                    scrollHeight: r,
                  } = et();
                  v = m ? Math.min(e + E, n) / n : Math.min(t + g, r) / r;
                  break;
                }
                case u.EventBasedOn.ELEMENT:
                default: {
                  _ = U(i, l);
                  let e = 0 === r.type.indexOf("mouse");
                  if (e && !0 !== W({ element: t, nativeEvent: r })) break;
                  let n = t.getBoundingClientRect(),
                    { left: o, top: a, width: u, height: c } = n;
                  if (!e && !ec({ left: p, top: h }, n)) break;
                  (I = !0), (v = m ? (p - o) / u : (h - a) / c);
                }
              }
              return (
                y && (v > 0.95 || v < 0.05) && (v = Math.round(v)),
                (a !== u.EventBasedOn.ELEMENT || I || I !== o.elementHovered) &&
                  ((v = f ? 1 - v : v),
                  e.dispatch((0, s.parameterChanged)(_, v))),
                {
                  elementHovered: I,
                  clientX: p,
                  clientY: h,
                  pageX: E,
                  pageY: g,
                }
              );
            },
          },
          [k]: {
            types: K,
            handler: ({ store: e, eventConfig: t }) => {
              let { continuousParameterGroupId: n, reverse: r } = t,
                { scrollTop: i, scrollHeight: o, clientHeight: a } = et(),
                u = i / (o - a);
              (u = r ? 1 - u : u), e.dispatch((0, s.parameterChanged)(n, u));
            },
          },
          [F]: {
            types: K,
            handler: (
              { element: e, store: t, eventConfig: n, eventStateKey: r },
              i = { scrollPercent: 0 }
            ) => {
              let {
                  scrollLeft: o,
                  scrollTop: a,
                  scrollWidth: c,
                  scrollHeight: l,
                  clientHeight: f,
                } = et(),
                {
                  basedOn: d,
                  selectedAxis: p,
                  continuousParameterGroupId: h,
                  startsEntering: E,
                  startsExiting: g,
                  addEndOffset: m,
                  addStartOffset: y,
                  addOffsetValue: v = 0,
                  endOffsetValue: _ = 0,
                } = n;
              if (d === u.EventBasedOn.VIEWPORT) {
                let e = "X_AXIS" === p ? o / c : a / l;
                return (
                  e !== i.scrollPercent &&
                    t.dispatch((0, s.parameterChanged)(h, e)),
                  { scrollPercent: e }
                );
              }
              {
                let n = U(r, h),
                  o = e.getBoundingClientRect(),
                  a = (y ? v : 0) / 100,
                  u = (m ? _ : 0) / 100;
                (a = E ? a : 1 - a), (u = g ? u : 1 - u);
                let c = o.top + Math.min(o.height * a, f),
                  d = Math.min(f + (o.top + o.height * u - c), l),
                  p = Math.min(Math.max(0, f - c), d) / d;
                return (
                  p !== i.scrollPercent &&
                    t.dispatch((0, s.parameterChanged)(n, p)),
                  { scrollPercent: p }
                );
              }
            },
          },
          [R]: ed,
          [N]: ed,
          [C]: {
            ...J,
            handler: eu((e, t) => {
              t.scrollingDown && z(e);
            }),
          },
          [S]: {
            ...J,
            handler: eu((e, t) => {
              t.scrollingDown || z(e);
            }),
          },
          [L]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: Y(V, (e, t) => {
              let n = { finished: "complete" === document.readyState };
              return n.finished && !(t && t.finshed) && z(e), n;
            }),
          },
          [D]: {
            types: "readystatechange IX2_PAGE_UPDATE",
            handler: Y(V, (e, t) => (t || z(e), { started: !0 })),
          },
        };
    },
    4609: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixData", {
          enumerable: !0,
          get: function () {
            return i;
          },
        });
      let { IX2_RAW_DATA_IMPORTED: r } = n(7087).IX2EngineActionTypes,
        i = (e = Object.freeze({}), t) =>
          t.type === r ? t.payload.ixData || Object.freeze({}) : e;
    },
    7718: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixInstances", {
          enumerable: !0,
          get: function () {
            return I;
          },
        });
      let r = n(7087),
        i = n(9468),
        o = n(1185),
        {
          IX2_RAW_DATA_IMPORTED: a,
          IX2_SESSION_STOPPED: u,
          IX2_INSTANCE_ADDED: c,
          IX2_INSTANCE_STARTED: s,
          IX2_INSTANCE_REMOVED: l,
          IX2_ANIMATION_FRAME_CHANGED: f,
        } = r.IX2EngineActionTypes,
        {
          optimizeFloat: d,
          applyEasing: p,
          createBezierEasing: h,
        } = i.IX2EasingUtils,
        { RENDER_GENERAL: E } = r.IX2EngineConstants,
        {
          getItemConfigByKey: g,
          getRenderType: m,
          getStyleProp: y,
        } = i.IX2VanillaUtils,
        v = (e, t) => {
          let n,
            r,
            i,
            a,
            {
              position: u,
              parameterId: c,
              actionGroups: s,
              destinationKeys: l,
              smoothing: f,
              restingValue: h,
              actionTypeId: E,
              customEasingFn: m,
              skipMotion: y,
              skipToValue: v,
            } = e,
            { parameters: _ } = t.payload,
            I = Math.max(1 - f, 0.01),
            b = _[c];
          null == b && ((I = 1), (b = h));
          let T = d((Math.max(b, 0) || 0) - u),
            O = y ? v : d(u + T * I),
            w = 100 * O;
          if (O === u && e.current) return e;
          for (let e = 0, { length: t } = s; e < t; e++) {
            let { keyframe: t, actionItems: o } = s[e];
            if ((0 === e && (n = o[0]), w >= t)) {
              n = o[0];
              let u = s[e + 1],
                c = u && w !== t;
              (r = c ? u.actionItems[0] : null),
                c && ((i = t / 100), (a = (u.keyframe - t) / 100));
            }
          }
          let A = {};
          if (n && !r)
            for (let e = 0, { length: t } = l; e < t; e++) {
              let t = l[e];
              A[t] = g(E, t, n.config);
            }
          else if (n && r && void 0 !== i && void 0 !== a) {
            let e = (O - i) / a,
              t = p(n.config.easing, e, m);
            for (let e = 0, { length: i } = l; e < i; e++) {
              let i = l[e],
                o = g(E, i, n.config),
                a = (g(E, i, r.config) - o) * t + o;
              A[i] = a;
            }
          }
          return (0, o.merge)(e, { position: O, current: A });
        },
        _ = (e, t) => {
          let {
              active: n,
              origin: r,
              start: i,
              immediate: a,
              renderType: u,
              verbose: c,
              actionItem: s,
              destination: l,
              destinationKeys: f,
              pluginDuration: h,
              instanceDelay: g,
              customEasingFn: m,
              skipMotion: y,
            } = e,
            v = s.config.easing,
            { duration: _, delay: I } = s.config;
          null != h && (_ = h),
            (I = null != g ? g : I),
            u === E ? (_ = 0) : (a || y) && (_ = I = 0);
          let { now: b } = t.payload;
          if (n && r) {
            let t = b - (i + I);
            if (c) {
              let t = _ + I,
                n = d(Math.min(Math.max(0, (b - i) / t), 1));
              e = (0, o.set)(e, "verboseTimeElapsed", t * n);
            }
            if (t < 0) return e;
            let n = d(Math.min(Math.max(0, t / _), 1)),
              a = p(v, n, m),
              u = {},
              s = null;
            return (
              f.length &&
                (s = f.reduce((e, t) => {
                  let n = l[t],
                    i = parseFloat(r[t]) || 0,
                    o = parseFloat(n) - i;
                  return (e[t] = o * a + i), e;
                }, {})),
              (u.current = s),
              (u.position = n),
              1 === n && ((u.active = !1), (u.complete = !0)),
              (0, o.merge)(e, u)
            );
          }
          return e;
        },
        I = (e = Object.freeze({}), t) => {
          switch (t.type) {
            case a:
              return t.payload.ixInstances || Object.freeze({});
            case u:
              return Object.freeze({});
            case c: {
              let {
                  instanceId: n,
                  elementId: r,
                  actionItem: i,
                  eventId: a,
                  eventTarget: u,
                  eventStateKey: c,
                  actionListId: s,
                  groupIndex: l,
                  isCarrier: f,
                  origin: d,
                  destination: p,
                  immediate: E,
                  verbose: g,
                  continuous: v,
                  parameterId: _,
                  actionGroups: I,
                  smoothing: b,
                  restingValue: T,
                  pluginInstance: O,
                  pluginDuration: w,
                  instanceDelay: A,
                  skipMotion: C,
                  skipToValue: R,
                } = t.payload,
                { actionTypeId: N } = i,
                S = m(N),
                F = y(S, N),
                L = Object.keys(p).filter(
                  (e) => null != p[e] && "string" != typeof p[e]
                ),
                { easing: P } = i.config;
              return (0, o.set)(e, n, {
                id: n,
                elementId: r,
                active: !1,
                position: 0,
                start: 0,
                origin: d,
                destination: p,
                destinationKeys: L,
                immediate: E,
                verbose: g,
                current: null,
                actionItem: i,
                actionTypeId: N,
                eventId: a,
                eventTarget: u,
                eventStateKey: c,
                actionListId: s,
                groupIndex: l,
                renderType: S,
                isCarrier: f,
                styleProp: F,
                continuous: v,
                parameterId: _,
                actionGroups: I,
                smoothing: b,
                restingValue: T,
                pluginInstance: O,
                pluginDuration: w,
                instanceDelay: A,
                skipMotion: C,
                skipToValue: R,
                customEasingFn:
                  Array.isArray(P) && 4 === P.length ? h(P) : void 0,
              });
            }
            case s: {
              let { instanceId: n, time: r } = t.payload;
              return (0, o.mergeIn)(e, [n], {
                active: !0,
                complete: !1,
                start: r,
              });
            }
            case l: {
              let { instanceId: n } = t.payload;
              if (!e[n]) return e;
              let r = {},
                i = Object.keys(e),
                { length: o } = i;
              for (let t = 0; t < o; t++) {
                let o = i[t];
                o !== n && (r[o] = e[o]);
              }
              return r;
            }
            case f: {
              let n = e,
                r = Object.keys(e),
                { length: i } = r;
              for (let a = 0; a < i; a++) {
                let i = r[a],
                  u = e[i],
                  c = u.continuous ? v : _;
                n = (0, o.set)(n, i, c(u, t));
              }
              return n;
            }
            default:
              return e;
          }
        };
    },
    1540: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixParameters", {
          enumerable: !0,
          get: function () {
            return a;
          },
        });
      let {
          IX2_RAW_DATA_IMPORTED: r,
          IX2_SESSION_STOPPED: i,
          IX2_PARAMETER_CHANGED: o,
        } = n(7087).IX2EngineActionTypes,
        a = (e = {}, t) => {
          switch (t.type) {
            case r:
              return t.payload.ixParameters || {};
            case i:
              return {};
            case o: {
              let { key: n, value: r } = t.payload;
              return (e[n] = r), e;
            }
            default:
              return e;
          }
        };
    },
    7243: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return f;
          },
        });
      let r = n(9516),
        i = n(4609),
        o = n(628),
        a = n(5862),
        u = n(9468),
        c = n(7718),
        s = n(1540),
        { ixElements: l } = u.IX2ElementsReducer,
        f = (0, r.combineReducers)({
          ixData: i.ixData,
          ixRequest: o.ixRequest,
          ixSession: a.ixSession,
          ixElements: l,
          ixInstances: c.ixInstances,
          ixParameters: s.ixParameters,
        });
    },
    628: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixRequest", {
          enumerable: !0,
          get: function () {
            return f;
          },
        });
      let r = n(7087),
        i = n(1185),
        {
          IX2_PREVIEW_REQUESTED: o,
          IX2_PLAYBACK_REQUESTED: a,
          IX2_STOP_REQUESTED: u,
          IX2_CLEAR_REQUESTED: c,
        } = r.IX2EngineActionTypes,
        s = { preview: {}, playback: {}, stop: {}, clear: {} },
        l = Object.create(null, {
          [o]: { value: "preview" },
          [a]: { value: "playback" },
          [u]: { value: "stop" },
          [c]: { value: "clear" },
        }),
        f = (e = s, t) => {
          if (t.type in l) {
            let n = [l[t.type]];
            return (0, i.setIn)(e, [n], { ...t.payload });
          }
          return e;
        };
    },
    5862: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ixSession", {
          enumerable: !0,
          get: function () {
            return g;
          },
        });
      let r = n(7087),
        i = n(1185),
        {
          IX2_SESSION_INITIALIZED: o,
          IX2_SESSION_STARTED: a,
          IX2_TEST_FRAME_RENDERED: u,
          IX2_SESSION_STOPPED: c,
          IX2_EVENT_LISTENER_ADDED: s,
          IX2_EVENT_STATE_CHANGED: l,
          IX2_ANIMATION_FRAME_CHANGED: f,
          IX2_ACTION_LIST_PLAYBACK_CHANGED: d,
          IX2_VIEWPORT_WIDTH_CHANGED: p,
          IX2_MEDIA_QUERIES_DEFINED: h,
        } = r.IX2EngineActionTypes,
        E = {
          active: !1,
          tick: 0,
          eventListeners: [],
          eventState: {},
          playbackState: {},
          viewportWidth: 0,
          mediaQueryKey: null,
          hasBoundaryNodes: !1,
          hasDefinedMediaQueries: !1,
          reducedMotion: !1,
        },
        g = (e = E, t) => {
          switch (t.type) {
            case o: {
              let { hasBoundaryNodes: n, reducedMotion: r } = t.payload;
              return (0, i.merge)(e, { hasBoundaryNodes: n, reducedMotion: r });
            }
            case a:
              return (0, i.set)(e, "active", !0);
            case u: {
              let {
                payload: { step: n = 20 },
              } = t;
              return (0, i.set)(e, "tick", e.tick + n);
            }
            case c:
              return E;
            case f: {
              let {
                payload: { now: n },
              } = t;
              return (0, i.set)(e, "tick", n);
            }
            case s: {
              let n = (0, i.addLast)(e.eventListeners, t.payload);
              return (0, i.set)(e, "eventListeners", n);
            }
            case l: {
              let { stateKey: n, newState: r } = t.payload;
              return (0, i.setIn)(e, ["eventState", n], r);
            }
            case d: {
              let { actionListId: n, isPlaying: r } = t.payload;
              return (0, i.setIn)(e, ["playbackState", n], r);
            }
            case p: {
              let { width: n, mediaQueries: r } = t.payload,
                o = r.length,
                a = null;
              for (let e = 0; e < o; e++) {
                let { key: t, min: i, max: o } = r[e];
                if (n >= i && n <= o) {
                  a = t;
                  break;
                }
              }
              return (0, i.merge)(e, { viewportWidth: n, mediaQueryKey: a });
            }
            case h:
              return (0, i.set)(e, "hasDefinedMediaQueries", !0);
            default:
              return e;
          }
        };
    },
    7377: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return l;
        },
        createPluginInstance: function () {
          return c;
        },
        getPluginConfig: function () {
          return i;
        },
        getPluginDestination: function () {
          return u;
        },
        getPluginDuration: function () {
          return o;
        },
        getPluginOrigin: function () {
          return a;
        },
        renderPlugin: function () {
          return s;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = (e) => e.value,
        o = (e, t) => {
          if ("auto" !== t.config.duration) return null;
          let n = parseFloat(e.getAttribute("data-duration"));
          return n > 0
            ? 1e3 * n
            : 1e3 * parseFloat(e.getAttribute("data-default-duration"));
        },
        a = (e) => e || { value: 0 },
        u = (e) => ({ value: e.value }),
        c = (e) => {
          let t = window.Webflow.require("lottie");
          if (!t) return null;
          let n = t.createInstance(e);
          return n.stop(), n.setSubframe(!0), n;
        },
        s = (e, t, n) => {
          if (!e) return;
          let r = t[n.actionTypeId].value / 100;
          e.goToFrame(e.frames * r);
        },
        l = (e) => {
          let t = window.Webflow.require("lottie");
          t && t.createInstance(e).stop();
        };
    },
    2570: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return h;
        },
        createPluginInstance: function () {
          return d;
        },
        getPluginConfig: function () {
          return c;
        },
        getPluginDestination: function () {
          return f;
        },
        getPluginDuration: function () {
          return s;
        },
        getPluginOrigin: function () {
          return l;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = "--wf-rive-fit",
        o = "--wf-rive-alignment",
        a = (e) => document.querySelector(`[data-w-id="${e}"]`),
        u = () => window.Webflow.require("rive"),
        c = (e, t) => e.value.inputs[t],
        s = () => null,
        l = (e, t) => {
          if (e) return e;
          let n = {},
            { inputs: r = {} } = t.config.value;
          for (let e in r) null == r[e] && (n[e] = 0);
          return n;
        },
        f = (e) => e.value.inputs ?? {},
        d = (e, t) => {
          if ((t.config?.target?.selectorGuids || []).length > 0) return e;
          let n = t?.config?.target?.pluginElement;
          return n ? a(n) : null;
        },
        p = (e, { PLUGIN_RIVE: t }, n) => {
          let r = u();
          if (!r) return;
          let a = r.getInstance(e),
            c = r.rive.StateMachineInputType,
            { name: s, inputs: l = {} } = n.config.value || {};
          function f(e) {
            if (e.loaded) n();
            else {
              let t = () => {
                n(), e?.off("load", t);
              };
              e?.on("load", t);
            }
            function n() {
              let n = e.stateMachineInputs(s);
              if (null != n) {
                if ((e.isPlaying || e.play(s, !1), i in l || o in l)) {
                  let t = e.layout,
                    n = l[i] ?? t.fit,
                    r = l[o] ?? t.alignment;
                  (n !== t.fit || r !== t.alignment) &&
                    (e.layout = t.copyWith({ fit: n, alignment: r }));
                }
                for (let e in l) {
                  if (e === i || e === o) continue;
                  let r = n.find((t) => t.name === e);
                  if (null != r)
                    switch (r.type) {
                      case c.Boolean:
                        null != l[e] && (r.value = !!l[e]);
                        break;
                      case c.Number: {
                        let n = t[e];
                        null != n && (r.value = n);
                        break;
                      }
                      case c.Trigger:
                        l[e] && r.fire();
                    }
                }
              }
            }
          }
          a?.rive ? f(a.rive) : r.setLoadHandler(e, f);
        },
        h = (e, t) => null;
    },
    2866: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        clearPlugin: function () {
          return h;
        },
        createPluginInstance: function () {
          return d;
        },
        getPluginConfig: function () {
          return u;
        },
        getPluginDestination: function () {
          return f;
        },
        getPluginDuration: function () {
          return c;
        },
        getPluginOrigin: function () {
          return l;
        },
        renderPlugin: function () {
          return p;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = (e) => document.querySelector(`[data-w-id="${e}"]`),
        o = () => window.Webflow.require("spline"),
        a = (e, t) => e.filter((e) => !t.includes(e)),
        u = (e, t) => e.value[t],
        c = () => null,
        s = Object.freeze({
          positionX: 0,
          positionY: 0,
          positionZ: 0,
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0,
          scaleX: 1,
          scaleY: 1,
          scaleZ: 1,
        }),
        l = (e, t) => {
          let n = Object.keys(t.config.value);
          if (e) {
            let t = a(n, Object.keys(e));
            return t.length ? t.reduce((e, t) => ((e[t] = s[t]), e), e) : e;
          }
          return n.reduce((e, t) => ((e[t] = s[t]), e), {});
        },
        f = (e) => e.value,
        d = (e, t) => {
          let n = t?.config?.target?.pluginElement;
          return n ? i(n) : null;
        },
        p = (e, t, n) => {
          let r = o();
          if (!r) return;
          let i = r.getInstance(e),
            a = n.config.target.objectId,
            u = (e) => {
              if (!e) throw Error("Invalid spline app passed to renderSpline");
              let n = a && e.findObjectById(a);
              if (!n) return;
              let { PLUGIN_SPLINE: r } = t;
              null != r.positionX && (n.position.x = r.positionX),
                null != r.positionY && (n.position.y = r.positionY),
                null != r.positionZ && (n.position.z = r.positionZ),
                null != r.rotationX && (n.rotation.x = r.rotationX),
                null != r.rotationY && (n.rotation.y = r.rotationY),
                null != r.rotationZ && (n.rotation.z = r.rotationZ),
                null != r.scaleX && (n.scale.x = r.scaleX),
                null != r.scaleY && (n.scale.y = r.scaleY),
                null != r.scaleZ && (n.scale.z = r.scaleZ);
            };
          i ? u(i.spline) : r.setLoadHandler(e, u);
        },
        h = () => null;
    },
    1407: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        clearPlugin: function () {
          return p;
        },
        createPluginInstance: function () {
          return l;
        },
        getPluginConfig: function () {
          return a;
        },
        getPluginDestination: function () {
          return s;
        },
        getPluginDuration: function () {
          return u;
        },
        getPluginOrigin: function () {
          return c;
        },
        renderPlugin: function () {
          return d;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = n(380),
        a = (e, t) => e.value[t],
        u = () => null,
        c = (e, t) => {
          if (e) return e;
          let n = t.config.value,
            r = t.config.target.objectId,
            i = getComputedStyle(document.documentElement).getPropertyValue(r);
          return null != n.size
            ? { size: parseInt(i, 10) }
            : "%" === n.unit || "-" === n.unit
            ? { size: parseFloat(i) }
            : null != n.red && null != n.green && null != n.blue
            ? (0, o.normalizeColor)(i)
            : void 0;
        },
        s = (e) => e.value,
        l = () => null,
        f = {
          color: {
            match: ({ red: e, green: t, blue: n, alpha: r }) =>
              [e, t, n, r].every((e) => null != e),
            getValue: ({ red: e, green: t, blue: n, alpha: r }) =>
              `rgba(${e}, ${t}, ${n}, ${r})`,
          },
          size: {
            match: ({ size: e }) => null != e,
            getValue: ({ size: e }, t) => ("-" === t ? e : `${e}${t}`),
          },
        },
        d = (e, t, n) => {
          let {
              target: { objectId: r },
              value: { unit: i },
            } = n.config,
            o = t.PLUGIN_VARIABLE,
            a = Object.values(f).find((e) => e.match(o, i));
          a && document.documentElement.style.setProperty(r, a.getValue(o, i));
        },
        p = (e, t) => {
          let n = t.config.target.objectId;
          document.documentElement.style.removeProperty(n);
        };
    },
    3690: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "pluginMethodMap", {
          enumerable: !0,
          get: function () {
            return l;
          },
        });
      let r = n(7087),
        i = s(n(7377)),
        o = s(n(2866)),
        a = s(n(2570)),
        u = s(n(1407));
      function c(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (c = function (e) {
          return e ? n : t;
        })(e);
      }
      function s(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = c(t);
        if (n && n.has(e)) return n.get(e);
        var r = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            a && (a.get || a.set)
              ? Object.defineProperty(r, o, a)
              : (r[o] = e[o]);
          }
        return (r.default = e), n && n.set(e, r), r;
      }
      let l = new Map([
        [r.ActionTypeConsts.PLUGIN_LOTTIE, { ...i }],
        [r.ActionTypeConsts.PLUGIN_SPLINE, { ...o }],
        [r.ActionTypeConsts.PLUGIN_RIVE, { ...a }],
        [r.ActionTypeConsts.PLUGIN_VARIABLE, { ...u }],
      ]);
    },
    8023: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        IX2_ACTION_LIST_PLAYBACK_CHANGED: function () {
          return _;
        },
        IX2_ANIMATION_FRAME_CHANGED: function () {
          return h;
        },
        IX2_CLEAR_REQUESTED: function () {
          return f;
        },
        IX2_ELEMENT_STATE_CHANGED: function () {
          return v;
        },
        IX2_EVENT_LISTENER_ADDED: function () {
          return d;
        },
        IX2_EVENT_STATE_CHANGED: function () {
          return p;
        },
        IX2_INSTANCE_ADDED: function () {
          return g;
        },
        IX2_INSTANCE_REMOVED: function () {
          return y;
        },
        IX2_INSTANCE_STARTED: function () {
          return m;
        },
        IX2_MEDIA_QUERIES_DEFINED: function () {
          return b;
        },
        IX2_PARAMETER_CHANGED: function () {
          return E;
        },
        IX2_PLAYBACK_REQUESTED: function () {
          return s;
        },
        IX2_PREVIEW_REQUESTED: function () {
          return c;
        },
        IX2_RAW_DATA_IMPORTED: function () {
          return i;
        },
        IX2_SESSION_INITIALIZED: function () {
          return o;
        },
        IX2_SESSION_STARTED: function () {
          return a;
        },
        IX2_SESSION_STOPPED: function () {
          return u;
        },
        IX2_STOP_REQUESTED: function () {
          return l;
        },
        IX2_TEST_FRAME_RENDERED: function () {
          return T;
        },
        IX2_VIEWPORT_WIDTH_CHANGED: function () {
          return I;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = "IX2_RAW_DATA_IMPORTED",
        o = "IX2_SESSION_INITIALIZED",
        a = "IX2_SESSION_STARTED",
        u = "IX2_SESSION_STOPPED",
        c = "IX2_PREVIEW_REQUESTED",
        s = "IX2_PLAYBACK_REQUESTED",
        l = "IX2_STOP_REQUESTED",
        f = "IX2_CLEAR_REQUESTED",
        d = "IX2_EVENT_LISTENER_ADDED",
        p = "IX2_EVENT_STATE_CHANGED",
        h = "IX2_ANIMATION_FRAME_CHANGED",
        E = "IX2_PARAMETER_CHANGED",
        g = "IX2_INSTANCE_ADDED",
        m = "IX2_INSTANCE_STARTED",
        y = "IX2_INSTANCE_REMOVED",
        v = "IX2_ELEMENT_STATE_CHANGED",
        _ = "IX2_ACTION_LIST_PLAYBACK_CHANGED",
        I = "IX2_VIEWPORT_WIDTH_CHANGED",
        b = "IX2_MEDIA_QUERIES_DEFINED",
        T = "IX2_TEST_FRAME_RENDERED";
    },
    2686: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        ABSTRACT_NODE: function () {
          return et;
        },
        AUTO: function () {
          return W;
        },
        BACKGROUND: function () {
          return G;
        },
        BACKGROUND_COLOR: function () {
          return x;
        },
        BAR_DELIMITER: function () {
          return z;
        },
        BORDER_COLOR: function () {
          return j;
        },
        BOUNDARY_SELECTOR: function () {
          return c;
        },
        CHILDREN: function () {
          return Y;
        },
        COLON_DELIMITER: function () {
          return $;
        },
        COLOR: function () {
          return U;
        },
        COMMA_DELIMITER: function () {
          return H;
        },
        CONFIG_UNIT: function () {
          return g;
        },
        CONFIG_VALUE: function () {
          return d;
        },
        CONFIG_X_UNIT: function () {
          return p;
        },
        CONFIG_X_VALUE: function () {
          return s;
        },
        CONFIG_Y_UNIT: function () {
          return h;
        },
        CONFIG_Y_VALUE: function () {
          return l;
        },
        CONFIG_Z_UNIT: function () {
          return E;
        },
        CONFIG_Z_VALUE: function () {
          return f;
        },
        DISPLAY: function () {
          return B;
        },
        FILTER: function () {
          return P;
        },
        FLEX: function () {
          return V;
        },
        FONT_VARIATION_SETTINGS: function () {
          return M;
        },
        HEIGHT: function () {
          return k;
        },
        HTML_ELEMENT: function () {
          return J;
        },
        IMMEDIATE_CHILDREN: function () {
          return q;
        },
        IX2_ID_DELIMITER: function () {
          return i;
        },
        OPACITY: function () {
          return L;
        },
        PARENT: function () {
          return K;
        },
        PLAIN_OBJECT: function () {
          return ee;
        },
        PRESERVE_3D: function () {
          return Z;
        },
        RENDER_GENERAL: function () {
          return er;
        },
        RENDER_PLUGIN: function () {
          return eo;
        },
        RENDER_STYLE: function () {
          return ei;
        },
        RENDER_TRANSFORM: function () {
          return en;
        },
        ROTATE_X: function () {
          return A;
        },
        ROTATE_Y: function () {
          return C;
        },
        ROTATE_Z: function () {
          return R;
        },
        SCALE_3D: function () {
          return w;
        },
        SCALE_X: function () {
          return b;
        },
        SCALE_Y: function () {
          return T;
        },
        SCALE_Z: function () {
          return O;
        },
        SIBLINGS: function () {
          return Q;
        },
        SKEW: function () {
          return N;
        },
        SKEW_X: function () {
          return S;
        },
        SKEW_Y: function () {
          return F;
        },
        TRANSFORM: function () {
          return m;
        },
        TRANSLATE_3D: function () {
          return I;
        },
        TRANSLATE_X: function () {
          return y;
        },
        TRANSLATE_Y: function () {
          return v;
        },
        TRANSLATE_Z: function () {
          return _;
        },
        WF_PAGE: function () {
          return o;
        },
        WIDTH: function () {
          return D;
        },
        WILL_CHANGE: function () {
          return X;
        },
        W_MOD_IX: function () {
          return u;
        },
        W_MOD_JS: function () {
          return a;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = "|",
        o = "data-wf-page",
        a = "w-mod-js",
        u = "w-mod-ix",
        c = ".w-dyn-item",
        s = "xValue",
        l = "yValue",
        f = "zValue",
        d = "value",
        p = "xUnit",
        h = "yUnit",
        E = "zUnit",
        g = "unit",
        m = "transform",
        y = "translateX",
        v = "translateY",
        _ = "translateZ",
        I = "translate3d",
        b = "scaleX",
        T = "scaleY",
        O = "scaleZ",
        w = "scale3d",
        A = "rotateX",
        C = "rotateY",
        R = "rotateZ",
        N = "skew",
        S = "skewX",
        F = "skewY",
        L = "opacity",
        P = "filter",
        M = "font-variation-settings",
        D = "width",
        k = "height",
        x = "backgroundColor",
        G = "background",
        j = "borderColor",
        U = "color",
        B = "display",
        V = "flex",
        X = "willChange",
        W = "AUTO",
        H = ",",
        $ = ":",
        z = "|",
        Y = "CHILDREN",
        q = "IMMEDIATE_CHILDREN",
        Q = "SIBLINGS",
        K = "PARENT",
        Z = "preserve-3d",
        J = "HTML_ELEMENT",
        ee = "PLAIN_OBJECT",
        et = "ABSTRACT_NODE",
        en = "RENDER_TRANSFORM",
        er = "RENDER_GENERAL",
        ei = "RENDER_STYLE",
        eo = "RENDER_PLUGIN";
    },
    262: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        ActionAppliesTo: function () {
          return o;
        },
        ActionTypeConsts: function () {
          return i;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = {
          TRANSFORM_MOVE: "TRANSFORM_MOVE",
          TRANSFORM_SCALE: "TRANSFORM_SCALE",
          TRANSFORM_ROTATE: "TRANSFORM_ROTATE",
          TRANSFORM_SKEW: "TRANSFORM_SKEW",
          STYLE_OPACITY: "STYLE_OPACITY",
          STYLE_SIZE: "STYLE_SIZE",
          STYLE_FILTER: "STYLE_FILTER",
          STYLE_FONT_VARIATION: "STYLE_FONT_VARIATION",
          STYLE_BACKGROUND_COLOR: "STYLE_BACKGROUND_COLOR",
          STYLE_BORDER: "STYLE_BORDER",
          STYLE_TEXT_COLOR: "STYLE_TEXT_COLOR",
          OBJECT_VALUE: "OBJECT_VALUE",
          PLUGIN_LOTTIE: "PLUGIN_LOTTIE",
          PLUGIN_SPLINE: "PLUGIN_SPLINE",
          PLUGIN_RIVE: "PLUGIN_RIVE",
          PLUGIN_VARIABLE: "PLUGIN_VARIABLE",
          GENERAL_DISPLAY: "GENERAL_DISPLAY",
          GENERAL_START_ACTION: "GENERAL_START_ACTION",
          GENERAL_CONTINUOUS_ACTION: "GENERAL_CONTINUOUS_ACTION",
          GENERAL_COMBO_CLASS: "GENERAL_COMBO_CLASS",
          GENERAL_STOP_ACTION: "GENERAL_STOP_ACTION",
          GENERAL_LOOP: "GENERAL_LOOP",
          STYLE_BOX_SHADOW: "STYLE_BOX_SHADOW",
        },
        o = {
          ELEMENT: "ELEMENT",
          ELEMENT_CLASS: "ELEMENT_CLASS",
          TRIGGER_ELEMENT: "TRIGGER_ELEMENT",
        };
    },
    7087: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        ActionTypeConsts: function () {
          return a.ActionTypeConsts;
        },
        IX2EngineActionTypes: function () {
          return u;
        },
        IX2EngineConstants: function () {
          return c;
        },
        QuickEffectIds: function () {
          return o.QuickEffectIds;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = s(n(1833), t),
        a = s(n(262), t);
      s(n(8704), t), s(n(3213), t);
      let u = f(n(8023)),
        c = f(n(2686));
      function s(e, t) {
        return (
          Object.keys(e).forEach(function (n) {
            "default" === n ||
              Object.prototype.hasOwnProperty.call(t, n) ||
              Object.defineProperty(t, n, {
                enumerable: !0,
                get: function () {
                  return e[n];
                },
              });
          }),
          e
        );
      }
      function l(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (l = function (e) {
          return e ? n : t;
        })(e);
      }
      function f(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = l(t);
        if (n && n.has(e)) return n.get(e);
        var r = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            a && (a.get || a.set)
              ? Object.defineProperty(r, o, a)
              : (r[o] = e[o]);
          }
        return (r.default = e), n && n.set(e, r), r;
      }
    },
    3213: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "ReducedMotionTypes", {
          enumerable: !0,
          get: function () {
            return l;
          },
        });
      let {
          TRANSFORM_MOVE: r,
          TRANSFORM_SCALE: i,
          TRANSFORM_ROTATE: o,
          TRANSFORM_SKEW: a,
          STYLE_SIZE: u,
          STYLE_FILTER: c,
          STYLE_FONT_VARIATION: s,
        } = n(262).ActionTypeConsts,
        l = { [r]: !0, [i]: !0, [o]: !0, [a]: !0, [u]: !0, [c]: !0, [s]: !0 };
    },
    1833: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var n = {
        EventAppliesTo: function () {
          return o;
        },
        EventBasedOn: function () {
          return a;
        },
        EventContinuousMouseAxes: function () {
          return u;
        },
        EventLimitAffectedElements: function () {
          return c;
        },
        EventTypeConsts: function () {
          return i;
        },
        QuickEffectDirectionConsts: function () {
          return l;
        },
        QuickEffectIds: function () {
          return s;
        },
      };
      for (var r in n)
        Object.defineProperty(t, r, { enumerable: !0, get: n[r] });
      let i = {
          NAVBAR_OPEN: "NAVBAR_OPEN",
          NAVBAR_CLOSE: "NAVBAR_CLOSE",
          TAB_ACTIVE: "TAB_ACTIVE",
          TAB_INACTIVE: "TAB_INACTIVE",
          SLIDER_ACTIVE: "SLIDER_ACTIVE",
          SLIDER_INACTIVE: "SLIDER_INACTIVE",
          DROPDOWN_OPEN: "DROPDOWN_OPEN",
          DROPDOWN_CLOSE: "DROPDOWN_CLOSE",
          MOUSE_CLICK: "MOUSE_CLICK",
          MOUSE_SECOND_CLICK: "MOUSE_SECOND_CLICK",
          MOUSE_DOWN: "MOUSE_DOWN",
          MOUSE_UP: "MOUSE_UP",
          MOUSE_OVER: "MOUSE_OVER",
          MOUSE_OUT: "MOUSE_OUT",
          MOUSE_MOVE: "MOUSE_MOVE",
          MOUSE_MOVE_IN_VIEWPORT: "MOUSE_MOVE_IN_VIEWPORT",
          SCROLL_INTO_VIEW: "SCROLL_INTO_VIEW",
          SCROLL_OUT_OF_VIEW: "SCROLL_OUT_OF_VIEW",
          SCROLLING_IN_VIEW: "SCROLLING_IN_VIEW",
          ECOMMERCE_CART_OPEN: "ECOMMERCE_CART_OPEN",
          ECOMMERCE_CART_CLOSE: "ECOMMERCE_CART_CLOSE",
          PAGE_START: "PAGE_START",
          PAGE_FINISH: "PAGE_FINISH",
          PAGE_SCROLL_UP: "PAGE_SCROLL_UP",
          PAGE_SCROLL_DOWN: "PAGE_SCROLL_DOWN",
          PAGE_SCROLL: "PAGE_SCROLL",
        },
        o = { ELEMENT: "ELEMENT", CLASS: "CLASS", PAGE: "PAGE" },
        a = { ELEMENT: "ELEMENT", VIEWPORT: "VIEWPORT" },
        u = { X_AXIS: "X_AXIS", Y_AXIS: "Y_AXIS" },
        c = {
          CHILDREN: "CHILDREN",
          SIBLINGS: "SIBLINGS",
          IMMEDIATE_CHILDREN: "IMMEDIATE_CHILDREN",
        },
        s = {
          FADE_EFFECT: "FADE_EFFECT",
          SLIDE_EFFECT: "SLIDE_EFFECT",
          GROW_EFFECT: "GROW_EFFECT",
          SHRINK_EFFECT: "SHRINK_EFFECT",
          SPIN_EFFECT: "SPIN_EFFECT",
          FLY_EFFECT: "FLY_EFFECT",
          POP_EFFECT: "POP_EFFECT",
          FLIP_EFFECT: "FLIP_EFFECT",
          JIGGLE_EFFECT: "JIGGLE_EFFECT",
          PULSE_EFFECT: "PULSE_EFFECT",
          DROP_EFFECT: "DROP_EFFECT",
          BLINK_EFFECT: "BLINK_EFFECT",
          BOUNCE_EFFECT: "BOUNCE_EFFECT",
          FLIP_LEFT_TO_RIGHT_EFFECT: "FLIP_LEFT_TO_RIGHT_EFFECT",
          FLIP_RIGHT_TO_LEFT_EFFECT: "FLIP_RIGHT_TO_LEFT_EFFECT",
          RUBBER_BAND_EFFECT: "RUBBER_BAND_EFFECT",
          JELLO_EFFECT: "JELLO_EFFECT",
          GROW_BIG_EFFECT: "GROW_BIG_EFFECT",
          SHRINK_BIG_EFFECT: "SHRINK_BIG_EFFECT",
          PLUGIN_LOTTIE_EFFECT: "PLUGIN_LOTTIE_EFFECT",
        },
        l = {
          LEFT: "LEFT",
          RIGHT: "RIGHT",
          BOTTOM: "BOTTOM",
          TOP: "TOP",
          BOTTOM_LEFT: "BOTTOM_LEFT",
          BOTTOM_RIGHT: "BOTTOM_RIGHT",
          TOP_RIGHT: "TOP_RIGHT",
          TOP_LEFT: "TOP_LEFT",
          CLOCKWISE: "CLOCKWISE",
          COUNTER_CLOCKWISE: "COUNTER_CLOCKWISE",
        };
    },
    8704: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "InteractionTypeConsts", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      let n = {
        MOUSE_CLICK_INTERACTION: "MOUSE_CLICK_INTERACTION",
        MOUSE_HOVER_INTERACTION: "MOUSE_HOVER_INTERACTION",
        MOUSE_MOVE_INTERACTION: "MOUSE_MOVE_INTERACTION",
        SCROLL_INTO_VIEW_INTERACTION: "SCROLL_INTO_VIEW_INTERACTION",
        SCROLLING_IN_VIEW_INTERACTION: "SCROLLING_IN_VIEW_INTERACTION",
        MOUSE_MOVE_IN_VIEWPORT_INTERACTION:
          "MOUSE_MOVE_IN_VIEWPORT_INTERACTION",
        PAGE_IS_SCROLLING_INTERACTION: "PAGE_IS_SCROLLING_INTERACTION",
        PAGE_LOAD_INTERACTION: "PAGE_LOAD_INTERACTION",
        PAGE_SCROLLED_INTERACTION: "PAGE_SCROLLED_INTERACTION",
        NAVBAR_INTERACTION: "NAVBAR_INTERACTION",
        DROPDOWN_INTERACTION: "DROPDOWN_INTERACTION",
        ECOMMERCE_CART_INTERACTION: "ECOMMERCE_CART_INTERACTION",
        TAB_INTERACTION: "TAB_INTERACTION",
        SLIDER_INTERACTION: "SLIDER_INTERACTION",
      };
    },
    380: function (e, t) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "normalizeColor", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      let n = {
        aliceblue: "#F0F8FF",
        antiquewhite: "#FAEBD7",
        aqua: "#00FFFF",
        aquamarine: "#7FFFD4",
        azure: "#F0FFFF",
        beige: "#F5F5DC",
        bisque: "#FFE4C4",
        black: "#000000",
        blanchedalmond: "#FFEBCD",
        blue: "#0000FF",
        blueviolet: "#8A2BE2",
        brown: "#A52A2A",
        burlywood: "#DEB887",
        cadetblue: "#5F9EA0",
        chartreuse: "#7FFF00",
        chocolate: "#D2691E",
        coral: "#FF7F50",
        cornflowerblue: "#6495ED",
        cornsilk: "#FFF8DC",
        crimson: "#DC143C",
        cyan: "#00FFFF",
        darkblue: "#00008B",
        darkcyan: "#008B8B",
        darkgoldenrod: "#B8860B",
        darkgray: "#A9A9A9",
        darkgreen: "#006400",
        darkgrey: "#A9A9A9",
        darkkhaki: "#BDB76B",
        darkmagenta: "#8B008B",
        darkolivegreen: "#556B2F",
        darkorange: "#FF8C00",
        darkorchid: "#9932CC",
        darkred: "#8B0000",
        darksalmon: "#E9967A",
        darkseagreen: "#8FBC8F",
        darkslateblue: "#483D8B",
        darkslategray: "#2F4F4F",
        darkslategrey: "#2F4F4F",
        darkturquoise: "#00CED1",
        darkviolet: "#9400D3",
        deeppink: "#FF1493",
        deepskyblue: "#00BFFF",
        dimgray: "#696969",
        dimgrey: "#696969",
        dodgerblue: "#1E90FF",
        firebrick: "#B22222",
        floralwhite: "#FFFAF0",
        forestgreen: "#228B22",
        fuchsia: "#FF00FF",
        gainsboro: "#DCDCDC",
        ghostwhite: "#F8F8FF",
        gold: "#FFD700",
        goldenrod: "#DAA520",
        gray: "#808080",
        green: "#008000",
        greenyellow: "#ADFF2F",
        grey: "#808080",
        honeydew: "#F0FFF0",
        hotpink: "#FF69B4",
        indianred: "#CD5C5C",
        indigo: "#4B0082",
        ivory: "#FFFFF0",
        khaki: "#F0E68C",
        lavender: "#E6E6FA",
        lavenderblush: "#FFF0F5",
        lawngreen: "#7CFC00",
        lemonchiffon: "#FFFACD",
        lightblue: "#ADD8E6",
        lightcoral: "#F08080",
        lightcyan: "#E0FFFF",
        lightgoldenrodyellow: "#FAFAD2",
        lightgray: "#D3D3D3",
        lightgreen: "#90EE90",
        lightgrey: "#D3D3D3",
        lightpink: "#FFB6C1",
        lightsalmon: "#FFA07A",
        lightseagreen: "#20B2AA",
        lightskyblue: "#87CEFA",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        lightsteelblue: "#B0C4DE",
        lightyellow: "#FFFFE0",
        lime: "#00FF00",
        limegreen: "#32CD32",
        linen: "#FAF0E6",
        magenta: "#FF00FF",
        maroon: "#800000",
        mediumaquamarine: "#66CDAA",
        mediumblue: "#0000CD",
        mediumorchid: "#BA55D3",
        mediumpurple: "#9370DB",
        mediumseagreen: "#3CB371",
        mediumslateblue: "#7B68EE",
        mediumspringgreen: "#00FA9A",
        mediumturquoise: "#48D1CC",
        mediumvioletred: "#C71585",
        midnightblue: "#191970",
        mintcream: "#F5FFFA",
        mistyrose: "#FFE4E1",
        moccasin: "#FFE4B5",
        navajowhite: "#FFDEAD",
        navy: "#000080",
        oldlace: "#FDF5E6",
        olive: "#808000",
        olivedrab: "#6B8E23",
        orange: "#FFA500",
        orangered: "#FF4500",
        orchid: "#DA70D6",
        palegoldenrod: "#EEE8AA",
        palegreen: "#98FB98",
        paleturquoise: "#AFEEEE",
        palevioletred: "#DB7093",
        papayawhip: "#FFEFD5",
        peachpuff: "#FFDAB9",
        peru: "#CD853F",
        pink: "#FFC0CB",
        plum: "#DDA0DD",
        powderblue: "#B0E0E6",
        purple: "#800080",
        rebeccapurple: "#663399",
        red: "#FF0000",
        rosybrown: "#BC8F8F",
        royalblue: "#4169E1",
        saddlebrown: "#8B4513",
        salmon: "#FA8072",
        sandybrown: "#F4A460",
        seagreen: "#2E8B57",
        seashell: "#FFF5EE",
        sienna: "#A0522D",
        silver: "#C0C0C0",
        skyblue: "#87CEEB",
        slateblue: "#6A5ACD",
        slategray: "#708090",
        slategrey: "#708090",
        snow: "#FFFAFA",
        springgreen: "#00FF7F",
        steelblue: "#4682B4",
        tan: "#D2B48C",
        teal: "#008080",
        thistle: "#D8BFD8",
        tomato: "#FF6347",
        turquoise: "#40E0D0",
        violet: "#EE82EE",
        wheat: "#F5DEB3",
        white: "#FFFFFF",
        whitesmoke: "#F5F5F5",
        yellow: "#FFFF00",
        yellowgreen: "#9ACD32",
      };
      function r(e) {
        let t,
          r,
          i,
          o = 1,
          a = e.replace(/\s/g, "").toLowerCase(),
          u = ("string" == typeof n[a] ? n[a].toLowerCase() : null) || a;
        if (u.startsWith("#")) {
          let e = u.substring(1);
          3 === e.length || 4 === e.length
            ? ((t = parseInt(e[0] + e[0], 16)),
              (r = parseInt(e[1] + e[1], 16)),
              (i = parseInt(e[2] + e[2], 16)),
              4 === e.length && (o = parseInt(e[3] + e[3], 16) / 255))
            : (6 === e.length || 8 === e.length) &&
              ((t = parseInt(e.substring(0, 2), 16)),
              (r = parseInt(e.substring(2, 4), 16)),
              (i = parseInt(e.substring(4, 6), 16)),
              8 === e.length && (o = parseInt(e.substring(6, 8), 16) / 255));
        } else if (u.startsWith("rgba")) {
          let e = u.match(/rgba\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (r = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10)),
            (o = parseFloat(e[3]));
        } else if (u.startsWith("rgb")) {
          let e = u.match(/rgb\(([^)]+)\)/)[1].split(",");
          (t = parseInt(e[0], 10)),
            (r = parseInt(e[1], 10)),
            (i = parseInt(e[2], 10));
        } else if (u.startsWith("hsla")) {
          let e,
            n,
            a,
            c = u.match(/hsla\(([^)]+)\)/)[1].split(","),
            s = parseFloat(c[0]),
            l = parseFloat(c[1].replace("%", "")) / 100,
            f = parseFloat(c[2].replace("%", "")) / 100;
          o = parseFloat(c[3]);
          let d = (1 - Math.abs(2 * f - 1)) * l,
            p = d * (1 - Math.abs(((s / 60) % 2) - 1)),
            h = f - d / 2;
          s >= 0 && s < 60
            ? ((e = d), (n = p), (a = 0))
            : s >= 60 && s < 120
            ? ((e = p), (n = d), (a = 0))
            : s >= 120 && s < 180
            ? ((e = 0), (n = d), (a = p))
            : s >= 180 && s < 240
            ? ((e = 0), (n = p), (a = d))
            : s >= 240 && s < 300
            ? ((e = p), (n = 0), (a = d))
            : ((e = d), (n = 0), (a = p)),
            (t = Math.round((e + h) * 255)),
            (r = Math.round((n + h) * 255)),
            (i = Math.round((a + h) * 255));
        } else if (u.startsWith("hsl")) {
          let e,
            n,
            o,
            a = u.match(/hsl\(([^)]+)\)/)[1].split(","),
            c = parseFloat(a[0]),
            s = parseFloat(a[1].replace("%", "")) / 100,
            l = parseFloat(a[2].replace("%", "")) / 100,
            f = (1 - Math.abs(2 * l - 1)) * s,
            d = f * (1 - Math.abs(((c / 60) % 2) - 1)),
            p = l - f / 2;
          c >= 0 && c < 60
            ? ((e = f), (n = d), (o = 0))
            : c >= 60 && c < 120
            ? ((e = d), (n = f), (o = 0))
            : c >= 120 && c < 180
            ? ((e = 0), (n = f), (o = d))
            : c >= 180 && c < 240
            ? ((e = 0), (n = d), (o = f))
            : c >= 240 && c < 300
            ? ((e = d), (n = 0), (o = f))
            : ((e = f), (n = 0), (o = d)),
            (t = Math.round((e + p) * 255)),
            (r = Math.round((n + p) * 255)),
            (i = Math.round((o + p) * 255));
        }
        if (Number.isNaN(t) || Number.isNaN(r) || Number.isNaN(i))
          throw Error(
            `Invalid color in [ix2/shared/utils/normalizeColor.js] '${e}'`
          );
        return { red: t, green: r, blue: i, alpha: o };
      }
    },
    9468: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        IX2BrowserSupport: function () {
          return o;
        },
        IX2EasingUtils: function () {
          return u;
        },
        IX2Easings: function () {
          return a;
        },
        IX2ElementsReducer: function () {
          return c;
        },
        IX2VanillaPlugins: function () {
          return s;
        },
        IX2VanillaUtils: function () {
          return l;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = d(n(2662)),
        a = d(n(8686)),
        u = d(n(3767)),
        c = d(n(5861)),
        s = d(n(1799)),
        l = d(n(4124));
      function f(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (f = function (e) {
          return e ? n : t;
        })(e);
      }
      function d(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || ("object" != typeof e && "function" != typeof e))
          return { default: e };
        var n = f(t);
        if (n && n.has(e)) return n.get(e);
        var r = { __proto__: null },
          i = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var o in e)
          if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
            var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
            a && (a.get || a.set)
              ? Object.defineProperty(r, o, a)
              : (r[o] = e[o]);
          }
        return (r.default = e), n && n.set(e, r), r;
      }
    },
    2662: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r,
        i = {
          ELEMENT_MATCHES: function () {
            return s;
          },
          FLEX_PREFIXED: function () {
            return l;
          },
          IS_BROWSER_ENV: function () {
            return u;
          },
          TRANSFORM_PREFIXED: function () {
            return f;
          },
          TRANSFORM_STYLE_PREFIXED: function () {
            return p;
          },
          withBrowser: function () {
            return c;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let a = (r = n(9777)) && r.__esModule ? r : { default: r },
        u = "undefined" != typeof window,
        c = (e, t) => (u ? e() : t),
        s = c(() =>
          (0, a.default)(
            [
              "matches",
              "matchesSelector",
              "mozMatchesSelector",
              "msMatchesSelector",
              "oMatchesSelector",
              "webkitMatchesSelector",
            ],
            (e) => e in Element.prototype
          )
        ),
        l = c(() => {
          let e = document.createElement("i"),
            t = [
              "flex",
              "-webkit-flex",
              "-ms-flexbox",
              "-moz-box",
              "-webkit-box",
            ];
          try {
            let { length: n } = t;
            for (let r = 0; r < n; r++) {
              let n = t[r];
              if (((e.style.display = n), e.style.display === n)) return n;
            }
            return "";
          } catch (e) {
            return "";
          }
        }, "flex"),
        f = c(() => {
          let e = document.createElement("i");
          if (null == e.style.transform) {
            let t = ["Webkit", "Moz", "ms"],
              { length: n } = t;
            for (let r = 0; r < n; r++) {
              let n = t[r] + "Transform";
              if (void 0 !== e.style[n]) return n;
            }
          }
          return "transform";
        }, "transform"),
        d = f.split("transform")[0],
        p = d ? d + "TransformStyle" : "transformStyle";
    },
    3767: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r,
        i = {
          applyEasing: function () {
            return f;
          },
          createBezierEasing: function () {
            return l;
          },
          optimizeFloat: function () {
            return s;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let a = (function (e, t) {
          if (e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = c(t);
          if (n && n.has(e)) return n.get(e);
          var r = { __proto__: null },
            i = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var o in e)
            if ("default" !== o && Object.prototype.hasOwnProperty.call(e, o)) {
              var a = i ? Object.getOwnPropertyDescriptor(e, o) : null;
              a && (a.get || a.set)
                ? Object.defineProperty(r, o, a)
                : (r[o] = e[o]);
            }
          return (r.default = e), n && n.set(e, r), r;
        })(n(8686)),
        u = (r = n(1361)) && r.__esModule ? r : { default: r };
      function c(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(),
          n = new WeakMap();
        return (c = function (e) {
          return e ? n : t;
        })(e);
      }
      function s(e, t = 5, n = 10) {
        let r = Math.pow(n, t),
          i = Number(Math.round(e * r) / r);
        return Math.abs(i) > 1e-4 ? i : 0;
      }
      function l(e) {
        return (0, u.default)(...e);
      }
      function f(e, t, n) {
        return 0 === t
          ? 0
          : 1 === t
          ? 1
          : n
          ? s(t > 0 ? n(t) : t)
          : s(t > 0 && e && a[e] ? a[e](t) : t);
      }
    },
    8686: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r,
        i = {
          bounce: function () {
            return V;
          },
          bouncePast: function () {
            return X;
          },
          ease: function () {
            return u;
          },
          easeIn: function () {
            return c;
          },
          easeInOut: function () {
            return l;
          },
          easeOut: function () {
            return s;
          },
          inBack: function () {
            return P;
          },
          inCirc: function () {
            return N;
          },
          inCubic: function () {
            return h;
          },
          inElastic: function () {
            return k;
          },
          inExpo: function () {
            return A;
          },
          inOutBack: function () {
            return D;
          },
          inOutCirc: function () {
            return F;
          },
          inOutCubic: function () {
            return g;
          },
          inOutElastic: function () {
            return G;
          },
          inOutExpo: function () {
            return R;
          },
          inOutQuad: function () {
            return p;
          },
          inOutQuart: function () {
            return v;
          },
          inOutQuint: function () {
            return b;
          },
          inOutSine: function () {
            return w;
          },
          inQuad: function () {
            return f;
          },
          inQuart: function () {
            return m;
          },
          inQuint: function () {
            return _;
          },
          inSine: function () {
            return T;
          },
          outBack: function () {
            return M;
          },
          outBounce: function () {
            return L;
          },
          outCirc: function () {
            return S;
          },
          outCubic: function () {
            return E;
          },
          outElastic: function () {
            return x;
          },
          outExpo: function () {
            return C;
          },
          outQuad: function () {
            return d;
          },
          outQuart: function () {
            return y;
          },
          outQuint: function () {
            return I;
          },
          outSine: function () {
            return O;
          },
          swingFrom: function () {
            return U;
          },
          swingFromTo: function () {
            return j;
          },
          swingTo: function () {
            return B;
          },
        };
      for (var o in i)
        Object.defineProperty(t, o, { enumerable: !0, get: i[o] });
      let a = (r = n(1361)) && r.__esModule ? r : { default: r },
        u = (0, a.default)(0.25, 0.1, 0.25, 1),
        c = (0, a.default)(0.42, 0, 1, 1),
        s = (0, a.default)(0, 0, 0.58, 1),
        l = (0, a.default)(0.42, 0, 0.58, 1);
      function f(e) {
        return Math.pow(e, 2);
      }
      function d(e) {
        return -(Math.pow(e - 1, 2) - 1);
      }
      function p(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 2)
          : -0.5 * ((e -= 2) * e - 2);
      }
      function h(e) {
        return Math.pow(e, 3);
      }
      function E(e) {
        return Math.pow(e - 1, 3) + 1;
      }
      function g(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 3)
          : 0.5 * (Math.pow(e - 2, 3) + 2);
      }
      function m(e) {
        return Math.pow(e, 4);
      }
      function y(e) {
        return -(Math.pow(e - 1, 4) - 1);
      }
      function v(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 4)
          : -0.5 * ((e -= 2) * Math.pow(e, 3) - 2);
      }
      function _(e) {
        return Math.pow(e, 5);
      }
      function I(e) {
        return Math.pow(e - 1, 5) + 1;
      }
      function b(e) {
        return (e /= 0.5) < 1
          ? 0.5 * Math.pow(e, 5)
          : 0.5 * (Math.pow(e - 2, 5) + 2);
      }
      function T(e) {
        return -Math.cos((Math.PI / 2) * e) + 1;
      }
      function O(e) {
        return Math.sin((Math.PI / 2) * e);
      }
      function w(e) {
        return -0.5 * (Math.cos(Math.PI * e) - 1);
      }
      function A(e) {
        return 0 === e ? 0 : Math.pow(2, 10 * (e - 1));
      }
      function C(e) {
        return 1 === e ? 1 : -Math.pow(2, -10 * e) + 1;
      }
      function R(e) {
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (e /= 0.5) < 1
          ? 0.5 * Math.pow(2, 10 * (e - 1))
          : 0.5 * (-Math.pow(2, -10 * --e) + 2);
      }
      function N(e) {
        return -(Math.sqrt(1 - e * e) - 1);
      }
      function S(e) {
        return Math.sqrt(1 - Math.pow(e - 1, 2));
      }
      function F(e) {
        return (e /= 0.5) < 1
          ? -0.5 * (Math.sqrt(1 - e * e) - 1)
          : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1);
      }
      function L(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function P(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function M(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function D(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function k(e) {
        let t = 1.70158,
          n = 0,
          r = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (n || (n = 0.3),
            r < 1
              ? ((r = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / r)),
            -(
              r *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n)
            ));
      }
      function x(e) {
        let t = 1.70158,
          n = 0,
          r = 1;
        return 0 === e
          ? 0
          : 1 === e
          ? 1
          : (n || (n = 0.3),
            r < 1
              ? ((r = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / r)),
            r * Math.pow(2, -10 * e) * Math.sin((2 * Math.PI * (e - t)) / n) +
              1);
      }
      function G(e) {
        let t = 1.70158,
          n = 0,
          r = 1;
        return 0 === e
          ? 0
          : 2 == (e /= 0.5)
          ? 1
          : (n || (n = 0.3 * 1.5),
            r < 1
              ? ((r = 1), (t = n / 4))
              : (t = (n / (2 * Math.PI)) * Math.asin(1 / r)),
            e < 1)
          ? -0.5 *
            (r *
              Math.pow(2, 10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n))
          : r *
              Math.pow(2, -10 * (e -= 1)) *
              Math.sin((2 * Math.PI * (e - t)) / n) *
              0.5 +
            1;
      }
      function j(e) {
        let t = 1.70158;
        return (e /= 0.5) < 1
          ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t))
          : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
      }
      function U(e) {
        return e * e * (2.70158 * e - 1.70158);
      }
      function B(e) {
        return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
      }
      function V(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
          : e < 2.5 / 2.75
          ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
          : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
      }
      function X(e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
          ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + 0.75)
          : e < 2.5 / 2.75
          ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + 0.9375)
          : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + 0.984375);
      }
    },
    1799: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        clearPlugin: function () {
          return E;
        },
        createPluginInstance: function () {
          return p;
        },
        getPluginConfig: function () {
          return s;
        },
        getPluginDestination: function () {
          return d;
        },
        getPluginDuration: function () {
          return f;
        },
        getPluginOrigin: function () {
          return l;
        },
        isPluginType: function () {
          return u;
        },
        renderPlugin: function () {
          return h;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = n(2662),
        a = n(3690);
      function u(e) {
        return a.pluginMethodMap.has(e);
      }
      let c = (e) => (t) => {
          if (!o.IS_BROWSER_ENV) return () => null;
          let n = a.pluginMethodMap.get(t);
          if (!n) throw Error(`IX2 no plugin configured for: ${t}`);
          let r = n[e];
          if (!r) throw Error(`IX2 invalid plugin method: ${e}`);
          return r;
        },
        s = c("getPluginConfig"),
        l = c("getPluginOrigin"),
        f = c("getPluginDuration"),
        d = c("getPluginDestination"),
        p = c("createPluginInstance"),
        h = c("renderPlugin"),
        E = c("clearPlugin");
    },
    4124: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        cleanupHTMLElement: function () {
          return eH;
        },
        clearAllStyles: function () {
          return eV;
        },
        clearObjectCache: function () {
          return ef;
        },
        getActionListProgress: function () {
          return eq;
        },
        getAffectedElements: function () {
          return e_;
        },
        getComputedStyle: function () {
          return eI;
        },
        getDestinationValues: function () {
          return eN;
        },
        getElementId: function () {
          return eE;
        },
        getInstanceId: function () {
          return ep;
        },
        getInstanceOrigin: function () {
          return ew;
        },
        getItemConfigByKey: function () {
          return eR;
        },
        getMaxDurationItemIndex: function () {
          return eY;
        },
        getNamespacedParameterId: function () {
          return eZ;
        },
        getRenderType: function () {
          return eS;
        },
        getStyleProp: function () {
          return eF;
        },
        mediaQueriesEqual: function () {
          return e0;
        },
        observeStore: function () {
          return ey;
        },
        reduceListToGroup: function () {
          return eQ;
        },
        reifyState: function () {
          return eg;
        },
        renderHTMLElement: function () {
          return eL;
        },
        shallowEqual: function () {
          return l.default;
        },
        shouldAllowMediaQuery: function () {
          return eJ;
        },
        shouldNamespaceEventParameter: function () {
          return eK;
        },
        stringifyTarget: function () {
          return e1;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = E(n(4075)),
        a = E(n(1455)),
        u = E(n(5720)),
        c = n(1185),
        s = n(7087),
        l = E(n(7164)),
        f = n(3767),
        d = n(380),
        p = n(1799),
        h = n(2662);
      function E(e) {
        return e && e.__esModule ? e : { default: e };
      }
      let {
          BACKGROUND: g,
          TRANSFORM: m,
          TRANSLATE_3D: y,
          SCALE_3D: v,
          ROTATE_X: _,
          ROTATE_Y: I,
          ROTATE_Z: b,
          SKEW: T,
          PRESERVE_3D: O,
          FLEX: w,
          OPACITY: A,
          FILTER: C,
          FONT_VARIATION_SETTINGS: R,
          WIDTH: N,
          HEIGHT: S,
          BACKGROUND_COLOR: F,
          BORDER_COLOR: L,
          COLOR: P,
          CHILDREN: M,
          IMMEDIATE_CHILDREN: D,
          SIBLINGS: k,
          PARENT: x,
          DISPLAY: G,
          WILL_CHANGE: j,
          AUTO: U,
          COMMA_DELIMITER: B,
          COLON_DELIMITER: V,
          BAR_DELIMITER: X,
          RENDER_TRANSFORM: W,
          RENDER_GENERAL: H,
          RENDER_STYLE: $,
          RENDER_PLUGIN: z,
        } = s.IX2EngineConstants,
        {
          TRANSFORM_MOVE: Y,
          TRANSFORM_SCALE: q,
          TRANSFORM_ROTATE: Q,
          TRANSFORM_SKEW: K,
          STYLE_OPACITY: Z,
          STYLE_FILTER: J,
          STYLE_FONT_VARIATION: ee,
          STYLE_SIZE: et,
          STYLE_BACKGROUND_COLOR: en,
          STYLE_BORDER: er,
          STYLE_TEXT_COLOR: ei,
          GENERAL_DISPLAY: eo,
          OBJECT_VALUE: ea,
        } = s.ActionTypeConsts,
        eu = (e) => e.trim(),
        ec = Object.freeze({ [en]: F, [er]: L, [ei]: P }),
        es = Object.freeze({
          [h.TRANSFORM_PREFIXED]: m,
          [F]: g,
          [A]: A,
          [C]: C,
          [N]: N,
          [S]: S,
          [R]: R,
        }),
        el = new Map();
      function ef() {
        el.clear();
      }
      let ed = 1;
      function ep() {
        return "i" + ed++;
      }
      let eh = 1;
      function eE(e, t) {
        for (let n in e) {
          let r = e[n];
          if (r && r.ref === t) return r.id;
        }
        return "e" + eh++;
      }
      function eg({ events: e, actionLists: t, site: n } = {}) {
        let r = (0, a.default)(
            e,
            (e, t) => {
              let { eventTypeId: n } = t;
              return e[n] || (e[n] = {}), (e[n][t.id] = t), e;
            },
            {}
          ),
          i = n && n.mediaQueries,
          o = [];
        return (
          i
            ? (o = i.map((e) => e.key))
            : ((i = []), console.warn("IX2 missing mediaQueries in site data")),
          {
            ixData: {
              events: e,
              actionLists: t,
              eventTypeMap: r,
              mediaQueries: i,
              mediaQueryKeys: o,
            },
          }
        );
      }
      let em = (e, t) => e === t;
      function ey({ store: e, select: t, onChange: n, comparator: r = em }) {
        let { getState: i, subscribe: o } = e,
          a = o(function () {
            let o = t(i());
            if (null == o) return void a();
            r(o, u) || n((u = o), e);
          }),
          u = t(i());
        return a;
      }
      function ev(e) {
        let t = typeof e;
        if ("string" === t) return { id: e };
        if (null != e && "object" === t) {
          let {
            id: t,
            objectId: n,
            selector: r,
            selectorGuids: i,
            appliesTo: o,
            useEventTarget: a,
          } = e;
          return {
            id: t,
            objectId: n,
            selector: r,
            selectorGuids: i,
            appliesTo: o,
            useEventTarget: a,
          };
        }
        return {};
      }
      function e_({
        config: e,
        event: t,
        eventTarget: n,
        elementRoot: r,
        elementApi: i,
      }) {
        let o, a, u;
        if (!i) throw Error("IX2 missing elementApi");
        let { targets: c } = e;
        if (Array.isArray(c) && c.length > 0)
          return c.reduce(
            (e, o) =>
              e.concat(
                e_({
                  config: { target: o },
                  event: t,
                  eventTarget: n,
                  elementRoot: r,
                  elementApi: i,
                })
              ),
            []
          );
        let {
            getValidDocument: l,
            getQuerySelector: f,
            queryDocument: d,
            getChildElements: p,
            getSiblingElements: E,
            matchSelector: g,
            elementContains: m,
            isSiblingNode: y,
          } = i,
          { target: v } = e;
        if (!v) return [];
        let {
          id: _,
          objectId: I,
          selector: b,
          selectorGuids: T,
          appliesTo: O,
          useEventTarget: w,
        } = ev(v);
        if (I) return [el.has(I) ? el.get(I) : el.set(I, {}).get(I)];
        if (O === s.EventAppliesTo.PAGE) {
          let e = l(_);
          return e ? [e] : [];
        }
        let A = (t?.action?.config?.affectedElements ?? {})[_ || b] || {},
          C = !!(A.id || A.selector),
          R = t && f(ev(t.target));
        if (
          (C
            ? ((o = A.limitAffectedElements), (a = R), (u = f(A)))
            : (a = u = f({ id: _, selector: b, selectorGuids: T })),
          t && w)
        ) {
          let e = n && (u || !0 === w) ? [n] : d(R);
          if (u) {
            if (w === x) return d(u).filter((t) => e.some((e) => m(t, e)));
            if (w === M) return d(u).filter((t) => e.some((e) => m(e, t)));
            if (w === k) return d(u).filter((t) => e.some((e) => y(e, t)));
          }
          return e;
        }
        return null == a || null == u
          ? []
          : h.IS_BROWSER_ENV && r
          ? d(u).filter((e) => r.contains(e))
          : o === M
          ? d(a, u)
          : o === D
          ? p(d(a)).filter(g(u))
          : o === k
          ? E(d(a)).filter(g(u))
          : d(u);
      }
      function eI({ element: e, actionItem: t }) {
        if (!h.IS_BROWSER_ENV) return {};
        let { actionTypeId: n } = t;
        switch (n) {
          case et:
          case en:
          case er:
          case ei:
          case eo:
            return window.getComputedStyle(e);
          default:
            return {};
        }
      }
      let eb = /px/,
        eT = (e, t) =>
          t.reduce(
            (e, t) => (null == e[t.type] && (e[t.type] = eM[t.type]), e),
            e || {}
          ),
        eO = (e, t) =>
          t.reduce(
            (e, t) => (
              null == e[t.type] &&
                (e[t.type] = eD[t.type] || t.defaultValue || 0),
              e
            ),
            e || {}
          );
      function ew(e, t = {}, n = {}, r, i) {
        let { getStyle: a } = i,
          { actionTypeId: u } = r;
        if ((0, p.isPluginType)(u)) return (0, p.getPluginOrigin)(u)(t[u], r);
        switch (r.actionTypeId) {
          case Y:
          case q:
          case Q:
          case K:
            return t[r.actionTypeId] || eP[r.actionTypeId];
          case J:
            return eT(t[r.actionTypeId], r.config.filters);
          case ee:
            return eO(t[r.actionTypeId], r.config.fontVariations);
          case Z:
            return { value: (0, o.default)(parseFloat(a(e, A)), 1) };
          case et: {
            let t,
              i = a(e, N),
              u = a(e, S);
            return {
              widthValue:
                r.config.widthUnit === U
                  ? eb.test(i)
                    ? parseFloat(i)
                    : parseFloat(n.width)
                  : (0, o.default)(parseFloat(i), parseFloat(n.width)),
              heightValue:
                r.config.heightUnit === U
                  ? eb.test(u)
                    ? parseFloat(u)
                    : parseFloat(n.height)
                  : (0, o.default)(parseFloat(u), parseFloat(n.height)),
            };
          }
          case en:
          case er:
          case ei:
            return (function ({
              element: e,
              actionTypeId: t,
              computedStyle: n,
              getStyle: r,
            }) {
              let i = ec[t],
                a = r(e, i),
                u = (function (e, t) {
                  let n = e.exec(t);
                  return n ? n[1] : "";
                })(ej, eG.test(a) ? a : n[i]).split(B);
              return {
                rValue: (0, o.default)(parseInt(u[0], 10), 255),
                gValue: (0, o.default)(parseInt(u[1], 10), 255),
                bValue: (0, o.default)(parseInt(u[2], 10), 255),
                aValue: (0, o.default)(parseFloat(u[3]), 1),
              };
            })({
              element: e,
              actionTypeId: r.actionTypeId,
              computedStyle: n,
              getStyle: a,
            });
          case eo:
            return { value: (0, o.default)(a(e, G), n.display) };
          case ea:
            return t[r.actionTypeId] || { value: 0 };
          default:
            return;
        }
      }
      let eA = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eC = (e, t) => (t && (e[t.type] = t.value || 0), e),
        eR = (e, t, n) => {
          if ((0, p.isPluginType)(e)) return (0, p.getPluginConfig)(e)(n, t);
          switch (e) {
            case J: {
              let e = (0, u.default)(n.filters, ({ type: e }) => e === t);
              return e ? e.value : 0;
            }
            case ee: {
              let e = (0, u.default)(
                n.fontVariations,
                ({ type: e }) => e === t
              );
              return e ? e.value : 0;
            }
            default:
              return n[t];
          }
        };
      function eN({ element: e, actionItem: t, elementApi: n }) {
        if ((0, p.isPluginType)(t.actionTypeId))
          return (0, p.getPluginDestination)(t.actionTypeId)(t.config);
        switch (t.actionTypeId) {
          case Y:
          case q:
          case Q:
          case K: {
            let { xValue: e, yValue: n, zValue: r } = t.config;
            return { xValue: e, yValue: n, zValue: r };
          }
          case et: {
            let { getStyle: r, setStyle: i, getProperty: o } = n,
              { widthUnit: a, heightUnit: u } = t.config,
              { widthValue: c, heightValue: s } = t.config;
            if (!h.IS_BROWSER_ENV) return { widthValue: c, heightValue: s };
            if (a === U) {
              let t = r(e, N);
              i(e, N, ""), (c = o(e, "offsetWidth")), i(e, N, t);
            }
            if (u === U) {
              let t = r(e, S);
              i(e, S, ""), (s = o(e, "offsetHeight")), i(e, S, t);
            }
            return { widthValue: c, heightValue: s };
          }
          case en:
          case er:
          case ei: {
            let {
              rValue: r,
              gValue: i,
              bValue: o,
              aValue: a,
              globalSwatchId: u,
            } = t.config;
            if (u && u.startsWith("--")) {
              let { getStyle: t } = n,
                r = t(e, u),
                i = (0, d.normalizeColor)(r);
              return {
                rValue: i.red,
                gValue: i.green,
                bValue: i.blue,
                aValue: i.alpha,
              };
            }
            return { rValue: r, gValue: i, bValue: o, aValue: a };
          }
          case J:
            return t.config.filters.reduce(eA, {});
          case ee:
            return t.config.fontVariations.reduce(eC, {});
          default: {
            let { value: e } = t.config;
            return { value: e };
          }
        }
      }
      function eS(e) {
        return /^TRANSFORM_/.test(e)
          ? W
          : /^STYLE_/.test(e)
          ? $
          : /^GENERAL_/.test(e)
          ? H
          : /^PLUGIN_/.test(e)
          ? z
          : void 0;
      }
      function eF(e, t) {
        return e === $ ? t.replace("STYLE_", "").toLowerCase() : null;
      }
      function eL(e, t, n, r, i, o, u, c, s) {
        switch (c) {
          case W:
            var l = e,
              f = t,
              d = n,
              E = i,
              g = u;
            let m = ex
                .map((e) => {
                  let t = eP[e],
                    {
                      xValue: n = t.xValue,
                      yValue: r = t.yValue,
                      zValue: i = t.zValue,
                      xUnit: o = "",
                      yUnit: a = "",
                      zUnit: u = "",
                    } = f[e] || {};
                  switch (e) {
                    case Y:
                      return `${y}(${n}${o}, ${r}${a}, ${i}${u})`;
                    case q:
                      return `${v}(${n}${o}, ${r}${a}, ${i}${u})`;
                    case Q:
                      return `${_}(${n}${o}) ${I}(${r}${a}) ${b}(${i}${u})`;
                    case K:
                      return `${T}(${n}${o}, ${r}${a})`;
                    default:
                      return "";
                  }
                })
                .join(" "),
              { setStyle: A } = g;
            eU(l, h.TRANSFORM_PREFIXED, g),
              A(l, h.TRANSFORM_PREFIXED, m),
              (function (
                { actionTypeId: e },
                { xValue: t, yValue: n, zValue: r }
              ) {
                return (
                  (e === Y && void 0 !== r) ||
                  (e === q && void 0 !== r) ||
                  (e === Q && (void 0 !== t || void 0 !== n))
                );
              })(E, d) && A(l, h.TRANSFORM_STYLE_PREFIXED, O);
            return;
          case $:
            return (function (e, t, n, r, i, o) {
              let { setStyle: u } = o;
              switch (r.actionTypeId) {
                case et: {
                  let { widthUnit: t = "", heightUnit: i = "" } = r.config,
                    { widthValue: a, heightValue: c } = n;
                  void 0 !== a &&
                    (t === U && (t = "px"), eU(e, N, o), u(e, N, a + t)),
                    void 0 !== c &&
                      (i === U && (i = "px"), eU(e, S, o), u(e, S, c + i));
                  break;
                }
                case J:
                  var c = r.config;
                  let s = (0, a.default)(
                      n,
                      (e, t, n) => `${e} ${n}(${t}${ek(n, c)})`,
                      ""
                    ),
                    { setStyle: l } = o;
                  eU(e, C, o), l(e, C, s);
                  break;
                case ee:
                  r.config;
                  let f = (0, a.default)(
                      n,
                      (e, t, n) => (e.push(`"${n}" ${t}`), e),
                      []
                    ).join(", "),
                    { setStyle: d } = o;
                  eU(e, R, o), d(e, R, f);
                  break;
                case en:
                case er:
                case ei: {
                  let t = ec[r.actionTypeId],
                    i = Math.round(n.rValue),
                    a = Math.round(n.gValue),
                    c = Math.round(n.bValue),
                    s = n.aValue;
                  eU(e, t, o),
                    u(
                      e,
                      t,
                      s >= 1
                        ? `rgb(${i},${a},${c})`
                        : `rgba(${i},${a},${c},${s})`
                    );
                  break;
                }
                default: {
                  let { unit: t = "" } = r.config;
                  eU(e, i, o), u(e, i, n.value + t);
                }
              }
            })(e, 0, n, i, o, u);
          case H:
            var F = e,
              L = i,
              P = u;
            let { setStyle: M } = P;
            if (L.actionTypeId === eo) {
              let { value: e } = L.config;
              M(F, G, e === w && h.IS_BROWSER_ENV ? h.FLEX_PREFIXED : e);
            }
            return;
          case z: {
            let { actionTypeId: e } = i;
            if ((0, p.isPluginType)(e)) return (0, p.renderPlugin)(e)(s, t, i);
          }
        }
      }
      let eP = {
          [Y]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [q]: Object.freeze({ xValue: 1, yValue: 1, zValue: 1 }),
          [Q]: Object.freeze({ xValue: 0, yValue: 0, zValue: 0 }),
          [K]: Object.freeze({ xValue: 0, yValue: 0 }),
        },
        eM = Object.freeze({
          blur: 0,
          "hue-rotate": 0,
          invert: 0,
          grayscale: 0,
          saturate: 100,
          sepia: 0,
          contrast: 100,
          brightness: 100,
        }),
        eD = Object.freeze({ wght: 0, opsz: 0, wdth: 0, slnt: 0 }),
        ek = (e, t) => {
          let n = (0, u.default)(t.filters, ({ type: t }) => t === e);
          if (n && n.unit) return n.unit;
          switch (e) {
            case "blur":
              return "px";
            case "hue-rotate":
              return "deg";
            default:
              return "%";
          }
        },
        ex = Object.keys(eP),
        eG = /^rgb/,
        ej = RegExp("rgba?\\(([^)]+)\\)");
      function eU(e, t, n) {
        if (!h.IS_BROWSER_ENV) return;
        let r = es[t];
        if (!r) return;
        let { getStyle: i, setStyle: o } = n,
          a = i(e, j);
        if (!a) return void o(e, j, r);
        let u = a.split(B).map(eu);
        -1 === u.indexOf(r) && o(e, j, u.concat(r).join(B));
      }
      function eB(e, t, n) {
        if (!h.IS_BROWSER_ENV) return;
        let r = es[t];
        if (!r) return;
        let { getStyle: i, setStyle: o } = n,
          a = i(e, j);
        a &&
          -1 !== a.indexOf(r) &&
          o(
            e,
            j,
            a
              .split(B)
              .map(eu)
              .filter((e) => e !== r)
              .join(B)
          );
      }
      function eV({ store: e, elementApi: t }) {
        let { ixData: n } = e.getState(),
          { events: r = {}, actionLists: i = {} } = n;
        Object.keys(r).forEach((e) => {
          let n = r[e],
            { config: o } = n.action,
            { actionListId: a } = o,
            u = i[a];
          u && eX({ actionList: u, event: n, elementApi: t });
        }),
          Object.keys(i).forEach((e) => {
            eX({ actionList: i[e], elementApi: t });
          });
      }
      function eX({ actionList: e = {}, event: t, elementApi: n }) {
        let { actionItemGroups: r, continuousParameterGroups: i } = e;
        r &&
          r.forEach((e) => {
            eW({ actionGroup: e, event: t, elementApi: n });
          }),
          i &&
            i.forEach((e) => {
              let { continuousActionGroups: r } = e;
              r.forEach((e) => {
                eW({ actionGroup: e, event: t, elementApi: n });
              });
            });
      }
      function eW({ actionGroup: e, event: t, elementApi: n }) {
        let { actionItems: r } = e;
        r.forEach((e) => {
          let r,
            { actionTypeId: i, config: o } = e;
          (r = (0, p.isPluginType)(i)
            ? (t) => (0, p.clearPlugin)(i)(t, e)
            : e$({ effect: ez, actionTypeId: i, elementApi: n })),
            e_({ config: o, event: t, elementApi: n }).forEach(r);
        });
      }
      function eH(e, t, n) {
        let { setStyle: r, getStyle: i } = n,
          { actionTypeId: o } = t;
        if (o === et) {
          let { config: n } = t;
          n.widthUnit === U && r(e, N, ""), n.heightUnit === U && r(e, S, "");
        }
        i(e, j) && e$({ effect: eB, actionTypeId: o, elementApi: n })(e);
      }
      let e$ =
        ({ effect: e, actionTypeId: t, elementApi: n }) =>
        (r) => {
          switch (t) {
            case Y:
            case q:
            case Q:
            case K:
              e(r, h.TRANSFORM_PREFIXED, n);
              break;
            case J:
              e(r, C, n);
              break;
            case ee:
              e(r, R, n);
              break;
            case Z:
              e(r, A, n);
              break;
            case et:
              e(r, N, n), e(r, S, n);
              break;
            case en:
            case er:
            case ei:
              e(r, ec[t], n);
              break;
            case eo:
              e(r, G, n);
          }
        };
      function ez(e, t, n) {
        let { setStyle: r } = n;
        eB(e, t, n),
          r(e, t, ""),
          t === h.TRANSFORM_PREFIXED && r(e, h.TRANSFORM_STYLE_PREFIXED, "");
      }
      function eY(e) {
        let t = 0,
          n = 0;
        return (
          e.forEach((e, r) => {
            let { config: i } = e,
              o = i.delay + i.duration;
            o >= t && ((t = o), (n = r));
          }),
          n
        );
      }
      function eq(e, t) {
        let { actionItemGroups: n, useFirstGroupAsInitialState: r } = e,
          { actionItem: i, verboseTimeElapsed: o = 0 } = t,
          a = 0,
          u = 0;
        return (
          n.forEach((e, t) => {
            if (r && 0 === t) return;
            let { actionItems: n } = e,
              c = n[eY(n)],
              { config: s, actionTypeId: l } = c;
            i.id === c.id && (u = a + o);
            let f = eS(l) === H ? 0 : s.duration;
            a += s.delay + f;
          }),
          a > 0 ? (0, f.optimizeFloat)(u / a) : 0
        );
      }
      function eQ({ actionList: e, actionItemId: t, rawData: n }) {
        let { actionItemGroups: r, continuousParameterGroups: i } = e,
          o = [],
          a = (e) => (
            o.push((0, c.mergeIn)(e, ["config"], { delay: 0, duration: 0 })),
            e.id === t
          );
        return (
          r && r.some(({ actionItems: e }) => e.some(a)),
          i &&
            i.some((e) => {
              let { continuousActionGroups: t } = e;
              return t.some(({ actionItems: e }) => e.some(a));
            }),
          (0, c.setIn)(n, ["actionLists"], {
            [e.id]: { id: e.id, actionItemGroups: [{ actionItems: o }] },
          })
        );
      }
      function eK(e, { basedOn: t }) {
        return (
          (e === s.EventTypeConsts.SCROLLING_IN_VIEW &&
            (t === s.EventBasedOn.ELEMENT || null == t)) ||
          (e === s.EventTypeConsts.MOUSE_MOVE && t === s.EventBasedOn.ELEMENT)
        );
      }
      function eZ(e, t) {
        return e + V + t;
      }
      function eJ(e, t) {
        return null == t || -1 !== e.indexOf(t);
      }
      function e0(e, t) {
        return (0, l.default)(e && e.sort(), t && t.sort());
      }
      function e1(e) {
        if ("string" == typeof e) return e;
        if (e.pluginElement && e.objectId)
          return e.pluginElement + X + e.objectId;
        if (e.objectId) return e.objectId;
        let { id: t = "", selector: n = "", useEventTarget: r = "" } = e;
        return t + X + n + X + r;
      }
    },
    7164: function (e, t) {
      "use strict";
      function n(e, t) {
        return e === t
          ? 0 !== e || 0 !== t || 1 / e == 1 / t
          : e != e && t != t;
      }
      Object.defineProperty(t, "__esModule", { value: !0 }),
        Object.defineProperty(t, "default", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      let r = function (e, t) {
        if (n(e, t)) return !0;
        if (
          "object" != typeof e ||
          null === e ||
          "object" != typeof t ||
          null === t
        )
          return !1;
        let r = Object.keys(e),
          i = Object.keys(t);
        if (r.length !== i.length) return !1;
        for (let i = 0; i < r.length; i++)
          if (!Object.hasOwn(t, r[i]) || !n(e[r[i]], t[r[i]])) return !1;
        return !0;
      };
    },
    5861: function (e, t, n) {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: !0 });
      var r = {
        createElementState: function () {
          return T;
        },
        ixElements: function () {
          return b;
        },
        mergeActionState: function () {
          return O;
        },
      };
      for (var i in r)
        Object.defineProperty(t, i, { enumerable: !0, get: r[i] });
      let o = n(1185),
        a = n(7087),
        {
          HTML_ELEMENT: u,
          PLAIN_OBJECT: c,
          ABSTRACT_NODE: s,
          CONFIG_X_VALUE: l,
          CONFIG_Y_VALUE: f,
          CONFIG_Z_VALUE: d,
          CONFIG_VALUE: p,
          CONFIG_X_UNIT: h,
          CONFIG_Y_UNIT: E,
          CONFIG_Z_UNIT: g,
          CONFIG_UNIT: m,
        } = a.IX2EngineConstants,
        {
          IX2_SESSION_STOPPED: y,
          IX2_INSTANCE_ADDED: v,
          IX2_ELEMENT_STATE_CHANGED: _,
        } = a.IX2EngineActionTypes,
        I = {},
        b = (e = I, t = {}) => {
          switch (t.type) {
            case y:
              return I;
            case v: {
              let {
                  elementId: n,
                  element: r,
                  origin: i,
                  actionItem: a,
                  refType: u,
                } = t.payload,
                { actionTypeId: c } = a,
                s = e;
              return (
                (0, o.getIn)(s, [n, r]) !== r && (s = T(s, r, u, n, a)),
                O(s, n, c, i, a)
              );
            }
            case _: {
              let {
                elementId: n,
                actionTypeId: r,
                current: i,
                actionItem: o,
              } = t.payload;
              return O(e, n, r, i, o);
            }
            default:
              return e;
          }
        };
      function T(e, t, n, r, i) {
        let a =
          n === c ? (0, o.getIn)(i, ["config", "target", "objectId"]) : null;
        return (0, o.mergeIn)(e, [r], { id: r, ref: t, refId: a, refType: n });
      }
      function O(e, t, n, r, i) {
        let a = (function (e) {
          let { config: t } = e;
          return w.reduce((e, n) => {
            let r = n[0],
              i = n[1],
              o = t[r],
              a = t[i];
            return null != o && null != a && (e[i] = a), e;
          }, {});
        })(i);
        return (0, o.mergeIn)(e, [t, "refState", n], r, a);
      }
      let w = [
        [l, h],
        [f, E],
        [d, g],
        [p, m],
      ];
    },
    5092: function () {
      Webflow.require("ix2").init({
        events: {
          e: {
            id: "e",
            name: "",
            animationType: "preset",
            eventTypeId: "NAVBAR_OPEN",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-407",
              },
            },
            mediaQueries: ["medium", "small", "tiny"],
            target: {
              id: "98608e0c-343f-7a3f-20f7-4f8228dba2a9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "98608e0c-343f-7a3f-20f7-4f8228dba2a9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x17aa2bde60b,
          },
          "e-2": {
            id: "e-2",
            name: "",
            animationType: "preset",
            eventTypeId: "NAVBAR_CLOSE",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-3",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-590",
              },
            },
            mediaQueries: ["medium", "small", "tiny"],
            target: {
              id: "98608e0c-343f-7a3f-20f7-4f8228dba2a9",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "98608e0c-343f-7a3f-20f7-4f8228dba2a9",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x17aa2bde60b,
          },
          "e-3": {
            id: "e-3",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OVER",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-2",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-4",
              },
            },
            mediaQueries: ["main"],
            target: {
              id: "98608e0c-343f-7a3f-20f7-4f8228dba2af",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "98608e0c-343f-7a3f-20f7-4f8228dba2af",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19735de6818,
          },
          "e-4": {
            id: "e-4",
            name: "",
            animationType: "custom",
            eventTypeId: "MOUSE_OUT",
            action: {
              id: "",
              actionTypeId: "GENERAL_START_ACTION",
              config: {
                delay: 0,
                easing: "",
                duration: 0,
                actionListId: "a-4",
                affectedElements: {},
                playInReverse: !1,
                autoStopEventId: "e-3",
              },
            },
            mediaQueries: ["main"],
            target: {
              id: "98608e0c-343f-7a3f-20f7-4f8228dba2af",
              appliesTo: "ELEMENT",
              styleBlockIds: [],
            },
            targets: [
              {
                id: "98608e0c-343f-7a3f-20f7-4f8228dba2af",
                appliesTo: "ELEMENT",
                styleBlockIds: [],
              },
            ],
            config: {
              loop: !1,
              playInReverse: !1,
              scrollOffsetValue: null,
              scrollOffsetUnit: null,
              delay: null,
              direction: null,
              effectIn: null,
            },
            createdOn: 0x19735de6818,
          },
        },
        actionLists: {
          a: {
            id: "a",
            title: "Navbar menu - Mobile [Close]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-middle",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233d"],
                      },
                      widthValue: 0,
                      widthUnit: "px",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                  {
                    id: "a-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-bottom",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233f"],
                      },
                      yValue: -7.25,
                      xUnit: "PX",
                      yUnit: "px",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-n-3",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-top",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233c"],
                      },
                      yValue: 7.25,
                      xUnit: "PX",
                      yUnit: "px",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-n-4",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 600,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-top",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233c"],
                      },
                      zValue: -45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-n-5",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 600,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-bottom",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233f"],
                      },
                      zValue: 45,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x17a9f3042c6,
          },
          "a-3": {
            id: "a-3",
            title: "Navbar menu - Mobile [Open]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-3-n",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 600,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-bottom",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233f"],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "px",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-3-n-2",
                    actionTypeId: "TRANSFORM_MOVE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 600,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-top",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233c"],
                      },
                      yValue: 0,
                      xUnit: "PX",
                      yUnit: "px",
                      zUnit: "PX",
                    },
                  },
                  {
                    id: "a-3-n-3",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-bottom",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233f"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-3-n-4",
                    actionTypeId: "TRANSFORM_ROTATE",
                    config: {
                      delay: 0,
                      easing: "inOutQuint",
                      duration: 400,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-top",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233c"],
                      },
                      zValue: 0,
                      xUnit: "DEG",
                      yUnit: "DEG",
                      zUnit: "deg",
                    },
                  },
                  {
                    id: "a-3-n-5",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 400,
                      easing: "inOutQuint",
                      duration: 200,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".menu-icon1_line-middle",
                        selectorGuids: ["93dbd7d4-438a-bc45-5a55-1fc67f5a233d"],
                      },
                      widthValue: 1,
                      widthUnit: "rem",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x17a9f363110,
          },
          "a-2": {
            id: "a-2",
            title: "Navbar menu - Desktop [Open]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-2-n",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: "",
                      duration: 500,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".navbar_menu.is-page-height-tablet",
                        selectorGuids: [
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2331",
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2340",
                        ],
                      },
                      widthValue: 0,
                      widthUnit: "px",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
              {
                actionItems: [
                  {
                    id: "a-2-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: [0.645, 0.045, 0.355, 1],
                      duration: 750,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".navbar_menu.is-page-height-tablet",
                        selectorGuids: [
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2331",
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2340",
                        ],
                      },
                      widthUnit: "AUTO",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !0,
            createdOn: 0x17a9f363110,
          },
          "a-4": {
            id: "a-4",
            title: "Navbar menu - Desktop [Close]",
            actionItemGroups: [
              {
                actionItems: [
                  {
                    id: "a-4-n-2",
                    actionTypeId: "STYLE_SIZE",
                    config: {
                      delay: 0,
                      easing: [0.645, 0.045, 0.355, 1],
                      duration: 750,
                      target: {
                        useEventTarget: "CHILDREN",
                        selector: ".navbar_menu.is-page-height-tablet",
                        selectorGuids: [
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2331",
                          "93dbd7d4-438a-bc45-5a55-1fc67f5a2340",
                        ],
                      },
                      widthValue: 0,
                      widthUnit: "px",
                      heightUnit: "PX",
                      locked: !1,
                    },
                  },
                ],
              },
            ],
            useFirstGroupAsInitialState: !1,
            createdOn: 0x17a9f363110,
          },
        },
        site: {
          mediaQueries: [
            { key: "main", min: 992, max: 1e4 },
            { key: "medium", min: 768, max: 991 },
            { key: "small", min: 480, max: 767 },
            { key: "tiny", min: 0, max: 479 },
          ],
        },
      });
    },
  },
]);
