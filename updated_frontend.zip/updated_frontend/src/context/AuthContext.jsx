import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

/**
 * AuthProvider for wrapping the app.
 * This is a mock provider without any database/auth backend.
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // null = guest / not logged in

  const login = (userData) => {
    // userData can be { id, name, role }
    setUser(userData);
  };

  const logout = () => {
    setUser(null);
  };

  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Custom hook to use auth
 * Throws error if used outside AuthProvider
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
