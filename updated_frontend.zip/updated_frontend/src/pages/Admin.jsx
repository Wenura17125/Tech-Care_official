import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  Users,
  Wrench,
  Calendar,
  Star,
  Settings,
  LayoutDashboard,
  LogOut,
  Bell,
  Plus,
  RefreshCw,
  DollarSign,
  CheckCircle,
  XCircle,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "../hooks/use-toast";
import { useAuth } from "../context/AuthContext";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const Admin = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);

  const [users, setUsers] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [appointments, setAppointments] = useState([]);

  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    role: "user",
  });

  /* ---------------- FETCH DATA ---------------- */

  const fetchUsers = async () => {
    const res = await axios.get(`${API_URL}/api/users`);
    setUsers(res.data);
  };

  const fetchTechnicians = async () => {
    const res = await axios.get(`${API_URL}/api/technicians`);
    setTechnicians(res.data);
  };

  const fetchAppointments = async () => {
    const res = await axios.get(`${API_URL}/api/appointments`);
    setAppointments(res.data);
  };

  const fetchAll = useCallback(async () => {
    try {
      setLoading(true);
      await Promise.all([
        fetchUsers(),
        fetchTechnicians(),
        fetchAppointments(),
      ]);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load admin data",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, []);

  /* ---------------- USER CRUD ---------------- */

  const createUser = async () => {
    await axios.post(`${API_URL}/api/auth/register`, formData);
    toast({ title: "User created" });
    setShowModal(false);
    fetchUsers();
  };

  const deleteUser = async (id) => {
    if (!confirm("Delete this user?")) return;
    await axios.delete(`${API_URL}/api/users/${id}`);
    fetchUsers();
  };

  /* ---------------- STATS ---------------- */

  const stats = {
    users: users.length,
    technicians: technicians.length,
    appointments: appointments.length,
    completed: appointments.filter(a => a.status === "completed").length,
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <RefreshCw className="animate-spin h-10 w-10" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* HEADER */}
      <div className="border-b p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <LayoutDashboard /> Admin Panel
        </h1>
        <div className="flex gap-2">
          <Button variant="ghost">
            <Bell />
          </Button>
          <Button variant="destructive" onClick={logout}>
            <LogOut className="mr-2 h-4 w-4" /> Logout
          </Button>
        </div>
      </div>

      {/* TABS */}
      <div className="p-6 flex gap-2 border-b">
        {["dashboard", "users", "technicians", "appointments"].map(tab => (
          <Button
            key={tab}
            variant={activeTab === tab ? "default" : "ghost"}
            onClick={() => setActiveTab(tab)}
          >
            {tab.toUpperCase()}
          </Button>
        ))}
      </div>

      {/* DASHBOARD */}
      {activeTab === "dashboard" && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 p-6">
          <StatCard title="Users" value={stats.users} icon={<Users />} />
          <StatCard title="Technicians" value={stats.technicians} icon={<Wrench />} />
          <StatCard title="Appointments" value={stats.appointments} icon={<Calendar />} />
          <StatCard title="Completed" value={stats.completed} icon={<CheckCircle />} />
        </div>
      )}

      {/* USERS */}
      {activeTab === "users" && (
        <div className="p-6 space-y-4">
          <Button onClick={() => setShowModal(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add User
          </Button>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map(u => (
                <TableRow key={u._id}>
                  <TableCell>{u.name}</TableCell>
                  <TableCell>{u.email}</TableCell>
                  <TableCell>
                    <Badge>{u.role}</Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteUser(u._id)}
                    >
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* TECHNICIANS */}
      {activeTab === "technicians" && (
        <div className="p-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Rating</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {technicians.map(t => (
                <TableRow key={t._id}>
                  <TableCell>{t.name}</TableCell>
                  <TableCell>{t.email}</TableCell>
                  <TableCell>{t.rating || 0}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* APPOINTMENTS */}
      {activeTab === "appointments" && (
        <div className="p-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Technician</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Price</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {appointments.map(a => (
                <TableRow key={a._id}>
                  <TableCell>{a.customerName}</TableCell>
                  <TableCell>{a.technicianName}</TableCell>
                  <TableCell>
                    <Badge>{a.status}</Badge>
                  </TableCell>
                  <TableCell>Rs. {a.price || 0}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* MODAL */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create User</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Label>Name</Label>
            <Input onChange={e => setFormData({ ...formData, name: e.target.value })} />
            <Label>Email</Label>
            <Input onChange={e => setFormData({ ...formData, email: e.target.value })} />
            <Label>Password</Label>
            <Input type="password" onChange={e => setFormData({ ...formData, password: e.target.value })} />
            <Button onClick={createUser}>Create</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const StatCard = ({ title, value, icon }) => (
  <Card>
    <CardHeader className="flex flex-row justify-between">
      <CardTitle>{title}</CardTitle>
      {icon}
    </CardHeader>
    <CardContent>
      <p className="text-2xl font-bold">{value}</p>
    </CardContent>
  </Card>
);

export default Admin;
