import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import CurrencyDisplay from '../components/CurrencyDisplay';
import SEO from '../components/SEO';
import { Button } from '../components/ui/button';
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import {
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from '../components/ui/tabs';
import { Briefcase, DollarSign } from 'lucide-react';

/* ---------------- MOCK DATA ---------------- */

const MOCK_JOBS = [
    {
        _id: 'job1',
        device: { brand: 'Samsung', model: 'Galaxy A32' },
        customer: { name: 'Nimal', location: 'Colombo' },
        issue: { description: 'Screen not working' },
        estimatedCost: 8500,
    },
    {
        _id: 'job2',
        device: { brand: 'Apple', model: 'iPhone 11' },
        customer: { name: 'Kamal', location: 'Kandy' },
        issue: { description: 'Battery drains fast' },
        estimatedCost: 12000,
    },
];

const MOCK_USER = {
    id: 'tech1',
    role: 'technician',
    name: 'Demo Technician',
};

/* ---------------- COMPONENT ---------------- */

const Bidding = () => {
    const navigate = useNavigate();

    const [activeTab, setActiveTab] = useState('available');
    const [availableJobs] = useState(MOCK_JOBS);
    const [myBids, setMyBids] = useState([]);

    const [selectedJob, setSelectedJob] = useState(null);
    const [bidAmount, setBidAmount] = useState('');
    const [bidMessage, setBidMessage] = useState('');
    const [estimatedDuration, setEstimatedDuration] = useState('');
    const [showBidModal, setShowBidModal] = useState(false);

    /* --------- AUTH CHECK (FRONTEND ONLY) --------- */
    if (!MOCK_USER || MOCK_USER.role !== 'technician') {
        navigate('/login');
        return null;
    }

    /* ---------------- SUBMIT BID ---------------- */
    const handleSubmitBid = (e) => {
        e.preventDefault();

        const newBid = {
            _id: Date.now().toString(),
            booking: selectedJob,
            amount: Number(bidAmount),
            estimatedDuration: Number(estimatedDuration),
            message: bidMessage,
            status: 'pending',
            createdAt: new Date().toISOString(),
        };

        setMyBids((prev) => [newBid, ...prev]);

        setShowBidModal(false);
        setBidAmount('');
        setBidMessage('');
        setEstimatedDuration('');
        setActiveTab('myBids');
    };

    return (
        <div className="container mx-auto px-4 py-8">
            <SEO
                title="Job Bidding - TechCare"
                description="Frontend-only technician bidding system"
            />

            <h1 className="text-3xl font-bold mb-2">Job Bidding Center</h1>
            <p className="text-muted-foreground mb-6">
                Browse available jobs and submit bids (Demo Mode)
            </p>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                    <TabsTrigger value="available">
                        Available Jobs ({availableJobs.length})
                    </TabsTrigger>
                    <TabsTrigger value="myBids">
                        My Bids ({myBids.length})
                    </TabsTrigger>
                </TabsList>

                {/* -------- AVAILABLE JOBS -------- */}
                <TabsContent value="available" className="mt-6">
                    {availableJobs.length === 0 ? (
                        <Card>
                            <CardContent className="py-12 text-center">
                                <Briefcase className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                                No jobs available
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="grid md:grid-cols-2 gap-6">
                            {availableJobs.map((job) => (
                                <Card key={job._id}>
                                    <CardHeader>
                                        <CardTitle>
                                            {job.device.brand} {job.device.model}
                                        </CardTitle>
                                        <CardDescription>
                                            {job.customer.name} • {job.customer.location}
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <p>{job.issue.description}</p>

                                        <div className="flex justify-between items-center">
                                            <div className="flex items-center gap-2">
                                                <DollarSign className="h-4 w-4" />
                                                <CurrencyDisplay
                                                    amount={job.estimatedCost}
                                                    decimals={0}
                                                />
                                            </div>
                                            <Button
                                                onClick={() => {
                                                    setSelectedJob(job);
                                                    setBidAmount(job.estimatedCost);
                                                    setShowBidModal(true);
                                                }}
                                            >
                                                Submit Bid
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </TabsContent>

                {/* -------- MY BIDS -------- */}
                <TabsContent value="myBids" className="mt-6">
                    {myBids.length === 0 ? (
                        <Card>
                            <CardContent className="py-12 text-center">
                                <Briefcase className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                                No bids submitted yet
                            </CardContent>
                        </Card>
                    ) : (
                        <div className="space-y-4">
                            {myBids.map((bid) => (
                                <Card key={bid._id}>
                                    <CardHeader className="flex flex-row justify-between">
                                        <div>
                                            <CardTitle>
                                                {bid.booking.device.brand}{' '}
                                                {bid.booking.device.model}
                                            </CardTitle>
                                            <CardDescription>
                                                Customer: {bid.booking.customer.name}
                                            </CardDescription>
                                        </div>
                                        <Badge>{bid.status}</Badge>
                                    </CardHeader>
                                    <CardContent className="grid grid-cols-3 gap-4">
                                        <div>
                                            <p className="text-sm text-muted-foreground">
                                                Amount
                                            </p>
                                            <CurrencyDisplay
                                                amount={bid.amount}
                                                decimals={0}
                                            />
                                        </div>
                                        <div>
                                            <p className="text-sm text-muted-foreground">
                                                Duration
                                            </p>
                                            {bid.estimatedDuration}h
                                        </div>
                                        <div>
                                            <p className="text-sm text-muted-foreground">
                                                Date
                                            </p>
                                            {new Date(
                                                bid.createdAt
                                            ).toLocaleDateString()}
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    )}
                </TabsContent>
            </Tabs>

            {/* -------- BID MODAL -------- */}
            {showBidModal && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                    <Card className="w-full max-w-md">
                        <CardHeader>
                            <CardTitle>Submit Bid</CardTitle>
                            <CardDescription>
                                {selectedJob.device.brand}{' '}
                                {selectedJob.device.model}
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form
                                onSubmit={handleSubmitBid}
                                className="space-y-4"
                            >
                                <input
                                    type="number"
                                    required
                                    placeholder="Bid Amount (LKR)"
                                    value={bidAmount}
                                    onChange={(e) =>
                                        setBidAmount(e.target.value)
                                    }
                                    className="w-full border px-3 py-2 rounded"
                                />

                                <input
                                    type="number"
                                    required
                                    placeholder="Estimated Duration (hours)"
                                    value={estimatedDuration}
                                    onChange={(e) =>
                                        setEstimatedDuration(e.target.value)
                                    }
                                    className="w-full border px-3 py-2 rounded"
                                />

                                <textarea
                                    placeholder="Message (optional)"
                                    value={bidMessage}
                                    onChange={(e) =>
                                        setBidMessage(e.target.value)
                                    }
                                    className="w-full border px-3 py-2 rounded"
                                />

                                <div className="flex gap-2">
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() =>
                                            setShowBidModal(false)
                                        }
                                    >
                                        Cancel
                                    </Button>
                                    <Button type="submit">
                                        Submit Bid
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
};

export default Bidding;
