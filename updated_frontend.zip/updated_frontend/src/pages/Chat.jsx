import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Send, User, Phone } from 'lucide-react';

/* ---------------- MOCK DATA ---------------- */
const MOCK_USER = { id: 'tech1', name: 'Demo Technician' };
const MOCK_RECIPIENT = { id: 'cust1', name: 'Demo Customer', phone: '0771234567' };
const MOCK_MESSAGES = [
    { sender_id: 'cust1', content: 'Hello, can you fix my phone?', created_at: new Date().toISOString() },
    { sender_id: 'tech1', content: 'Yes, I can. When can I start?', created_at: new Date().toISOString() },
];

/* ---------------- COMPONENT ---------------- */
export default function Chat() {
    const { bookingId } = useParams();
    const [messages, setMessages] = useState(MOCK_MESSAGES);
    const [newMessage, setNewMessage] = useState('');
    const [recipient] = useState(MOCK_RECIPIENT);
    const scrollRef = useRef(null);

    /* ---------------- AUTO SCROLL ---------------- */
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    /* ---------------- SEND MESSAGE ---------------- */
    const handleSendMessage = (e) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        const messageData = {
            sender_id: MOCK_USER.id,
            content: newMessage.trim(),
            created_at: new Date().toISOString(),
        };

        setMessages((prev) => [...prev, messageData]);
        setNewMessage('');
    };

    return (
        <div className="container max-w-4xl mx-auto py-8 px-4 h-[calc(100vh-120px)] flex flex-col">
            <Card className="flex-1 flex flex-col overflow-hidden">
                <CardHeader className="border-b bg-muted/30">
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <User className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                                <CardTitle className="text-lg">{recipient.name}</CardTitle>
                                <p className="text-xs text-muted-foreground">Booking #{bookingId?.slice(0, 8) || 'demo'}</p>
                            </div>
                        </div>
                        {recipient?.phone && (
                            <Button variant="ghost" size="icon" asChild>
                                <a href={`tel:${recipient.phone}`}>
                                    <Phone className="h-4 w-4" />
                                </a>
                            </Button>
                        )}
                    </div>
                </CardHeader>
                
                <CardContent 
                    ref={scrollRef}
                    className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/5"
                >
                    {messages.length === 0 ? (
                        <div className="text-center py-20 text-muted-foreground italic">
                            No messages yet. Start the conversation!
                        </div>
                    ) : (
                        messages.map((msg, index) => {
                            const isOwn = msg.sender_id === MOCK_USER.id;
                            return (
                                <div 
                                    key={index}
                                    className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div className={`max-w-[80%] p-3 rounded-2xl ${
                                        isOwn 
                                            ? 'bg-primary text-primary-foreground rounded-tr-none' 
                                            : 'bg-muted rounded-tl-none'
                                    }`}>
                                        <p className="text-sm">{msg.content}</p>
                                        <p className={`text-[10px] mt-1 opacity-70 ${isOwn ? 'text-right' : 'text-left'}`}>
                                            {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </p>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </CardContent>

                <CardFooter className="border-t p-4 bg-background">
                    <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                        <Input 
                            placeholder="Type your message..."
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            className="flex-1"
                        />
                        <Button type="submit" size="icon" disabled={!newMessage.trim()}>
                            <Send className="h-4 w-4" />
                        </Button>
                    </form>
                </CardFooter>
            </Card>
        </div>
    );
}
