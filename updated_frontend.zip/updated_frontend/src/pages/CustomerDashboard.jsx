import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Calendar, Activity, History, Heart, ArrowRight, Star } from 'lucide-react';
import CurrencyDisplay from '../components/CurrencyDisplay';
import SEO from '../components/SEO';
import { formatDistanceToNow } from 'date-fns';

/* ---------------- MOCK DATA ---------------- */
const MOCK_CUSTOMER = {
    name: 'John Doe',
    email: 'john@example.com',
    profileImage: '',
};

const MOCK_STATS = {
    totalBookings: 12,
    activeBookings: 3,
    totalSpent: 45000,
};

const MOCK_ACTIVE_BOOKINGS = [
    { _id: '1', device: { brand: 'iPhone', model: '13 Pro' }, issue: { description: 'Screen broken' }, technician: { name: 'Tech Mike' }, status: 'confirmed', scheduledDate: new Date(), estimatedCost: 15000 },
    { _id: '2', device: { brand: 'Samsung', model: 'S21' }, issue: { description: 'Battery issue' }, technician: { name: 'Tech Anna' }, status: 'pending', scheduledDate: new Date(), estimatedCost: 12000 },
];

const MOCK_RECENT_BOOKINGS = [
    { _id: '3', device: { brand: 'iPhone', model: '12' }, issue: { type: 'Battery' }, status: 'completed', scheduledDate: new Date(), estimatedCost: 8000, updatedAt: new Date() },
    { _id: '4', device: { brand: 'Samsung', model: 'Note 20' }, issue: { type: 'Screen' }, status: 'cancelled', scheduledDate: new Date(), estimatedCost: 10000, updatedAt: new Date() },
];

const MOCK_FAVORITES = [
    { _id: 'f1', name: 'Tech Mike', profileImage: '', rating: 4.8, reviewCount: 15 },
    { _id: 'f2', name: 'Tech Anna', profileImage: '', rating: 4.5, reviewCount: 12 },
];

/* ---------------- COMPONENT ---------------- */
function CustomerDashboard() {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('overview');
    const [customer] = useState(MOCK_CUSTOMER);
    const [stats] = useState(MOCK_STATS);
    const [activeBookings] = useState(MOCK_ACTIVE_BOOKINGS);
    const [recentBookings] = useState(MOCK_RECENT_BOOKINGS);
    const [favorites] = useState(MOCK_FAVORITES);

    const getStatusBadgeVariant = (status) => {
        switch (status) {
            case 'confirmed': return 'default';
            case 'pending': return 'secondary';
            case 'completed': return 'outline';
            case 'cancelled': return 'destructive';
            default: return 'secondary';
        }
    };

    const formatDate = (dateString) => {
        try { return new Date(dateString).toLocaleDateString(); } catch { return dateString; }
    };

    return (
        <div className="min-h-screen bg-black text-white font-['Inter']">
            <SEO
                title="Customer Dashboard - Demo"
                description="Manage your device repairs, track bookings, and view your service history."
            />

            {/* Header */}
            <div className="relative border-b border-zinc-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                        <div className="flex items-center gap-5">
                            <Avatar className="h-20 w-20 sm:h-24 sm:w-24 border-4 border-zinc-700 ring-4 ring-zinc-800">
                                <AvatarImage src={customer.profileImage} alt={customer.name} />
                                <AvatarFallback className="bg-zinc-800 text-white text-2xl sm:text-3xl font-bold">
                                    {customer.name ? customer.name.split(' ').map(n => n[0]).join('') : 'U'}
                                </AvatarFallback>
                            </Avatar>
                            <div>
                                <Badge className="mb-2 bg-zinc-800 text-zinc-300 border-zinc-700">Customer</Badge>
                                <h1 className="text-3xl sm:text-4xl font-bold text-white">
                                    Welcome, {customer.name}
                                </h1>
                                <p className="text-zinc-400 mt-1">{customer.email}</p>
                            </div>
                        </div>
                        <Button
                            onClick={() => navigate('/schedule')}
                            className="w-full sm:w-auto bg-white text-black hover:bg-gray-100 font-semibold py-6 px-8 rounded-full shadow-lg transition-all duration-300"
                        >
                            Book New Service <ArrowRight className="ml-2 h-5 w-5" />
                        </Button>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Stats */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
                    <Card className="bg-blue-700 text-white border-0 shadow-xl hover:-translate-y-1 transition-all">
                        <CardHeader>
                            <CardTitle>Total Bookings</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-4xl font-bold">{stats.totalBookings}</div>
                            <p className="text-xs opacity-80 mt-1">All time</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-emerald-700 text-white border-0 shadow-xl hover:-translate-y-1 transition-all">
                        <CardHeader>
                            <CardTitle>Active Bookings</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-4xl font-bold">{stats.activeBookings}</div>
                            <p className="text-xs opacity-80 mt-1">In progress</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-purple-700 text-white border-0 shadow-xl hover:-translate-y-1 transition-all">
                        <CardHeader>
                            <CardTitle>Total Spent</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold">
                                <CurrencyDisplay amount={stats.totalSpent} decimals={0} />
                            </div>
                            <p className="text-xs opacity-80 mt-1">Lifetime value</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-amber-600 text-white border-0 shadow-xl hover:-translate-y-1 transition-all">
                        <CardHeader>
                            <CardTitle>Loyalty Points</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-4xl font-bold">{Math.floor(stats.totalSpent / 100)}</div>
                            <p className="text-xs opacity-80 mt-1">Redeem for discounts</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Tabs */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-2 p-1 bg-zinc-900 border border-zinc-800 rounded-xl">
                        <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg">Overview</TabsTrigger>
                        <TabsTrigger value="appointments" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg">Appointments</TabsTrigger>
                        <TabsTrigger value="favorites" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg">Favorites</TabsTrigger>
                        <TabsTrigger value="activity" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg">Activity</TabsTrigger>
                    </TabsList>

                    {/* Overview Tab */}
                    <TabsContent value="overview" className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card className="bg-zinc-900 border-zinc-800">
                                <CardHeader>
                                    <CardTitle>Active Bookings</CardTitle>
                                    <CardDescription>Your in-progress services</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {activeBookings.map(apt => (
                                        <div key={apt._id} className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-700 hover:border-zinc-600 transition-all">
                                            <div className="flex justify-between items-center">
                                                <h3 className="font-bold text-white">{apt.device.brand} {apt.device.model}</h3>
                                                <Badge variant={getStatusBadgeVariant(apt.status)}>{apt.status}</Badge>
                                            </div>
                                            <p className="text-sm text-zinc-400">Technician: {apt.technician.name}</p>
                                            <p className="text-sm text-zinc-400">Issue: {apt.issue.description}</p>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Appointments Tab */}
                    <TabsContent value="appointments">
                        <Card className="bg-zinc-900 border-zinc-800">
                            <CardHeader>
                                <CardTitle>All Appointments</CardTitle>
                                <CardDescription>History of all your service requests</CardDescription>
                            </CardHeader>
                            <CardContent>
                                {recentBookings.map(booking => (
                                    <div key={booking._id} className="flex justify-between items-center p-4 bg-zinc-800/50 rounded-xl border border-zinc-700 mb-2">
                                        <div>
                                            <h4 className="font-bold text-white">{booking.device.brand} {booking.device.model}</h4>
                                            <p className="text-sm text-zinc-400">{booking.issue.type}</p>
                                        </div>
                                        <div className="text-right">
                                            <CurrencyDisplay amount={booking.estimatedCost} decimals={0} />
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Favorites Tab */}
                    <TabsContent value="favorites">
                        <Card className="bg-zinc-900 border-zinc-800">
                            <CardHeader>
                                <CardTitle>Favorite Technicians</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {favorites.map(tech => (
                                    <div key={tech._id} className="flex justify-between items-center p-4 bg-zinc-800/50 rounded-xl border border-zinc-700 mb-2">
                                        <div className="flex items-center gap-3">
                                            <Avatar>
                                                <AvatarImage src={tech.profileImage} />
                                                <AvatarFallback>{tech.name[0]}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <h4 className="font-bold text-white">{tech.name}</h4>
                                                <div className="flex items-center text-sm text-yellow-500">
                                                    <Star className="h-3 w-3 mr-1" /> {tech.rating} ({tech.reviewCount})
                                                </div>
                                            </div>
                                        </div>
                                        <Button className="bg-white text-black">Book Again</Button>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Activity Tab */}
                    <TabsContent value="activity">
                        <Card className="bg-zinc-900 border-zinc-800">
                            <CardHeader>
                                <CardTitle>Account Activity</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {recentBookings.map((action, i) => (
                                    <div key={i} className="flex gap-4 p-3 border-b border-zinc-800 last:border-0">
                                        <div className="mt-1 h-2 w-2 rounded-full bg-blue-500"></div>
                                        <div>
                                            <p className="text-sm text-white">Booking Status Update</p>
                                            <p className="text-sm text-zinc-400">
                                                Your booking for {action.device.brand} {action.device.model} is now {action.status}
                                            </p>
                                            <p className="text-xs text-zinc-500 mt-1">
                                                {formatDistanceToNow(new Date(action.updatedAt), { addSuffix: true })}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}

export default CustomerDashboard;
