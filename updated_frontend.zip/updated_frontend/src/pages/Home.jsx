import React from 'react';

const Home = () => {
  // Cache-busting timestamp to force reload of landing page with updated footer
  const cacheBuster = Date.now();

  return (
    <div className="w-full h-screen">
      <iframe
        src={`/landing/www.techcare.com/index.html?v=${cacheBuster}`}
        className="w-full h-full"
        frameBorder="0"
        title="TechCare Landing Page"
      />
    </div>
  );
};

export default Home;