import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent } from "../components/ui/dialog";
import {
  Search,
  Star,
  MapPin,
  SearchX,
  ArrowUpRight,
  List
} from 'lucide-react';
import SEO from '../components/SEO';
import { Loader2 } from 'lucide-react';

/* ---------------- MOCK DATA (NO DATABASE) ---------------- */

const MOCK_TECHNICIANS = [
  {
    id: 1,
    name: "Kasun Perera",
    rating: 4.8,
    experience: 6,
    specialization: ["Motherboard Repair", "RAM Upgrade"],
    brands: ["dell", "hp", "lenovo"],
    priceRange: { min: 50, max: 200 },
    location: { address: "Colombo, Sri Lanka" },
    image: "https://images.unsplash.com/photo-1603575448360-153f093fd0b2"
  },
  {
    id: 2,
    name: "Nimal Fernando",
    rating: 4.5,
    experience: 8,
    specialization: ["Data Recovery", "SSD Upgrade"],
    brands: ["apple", "lenovo"],
    priceRange: { min: 80, max: 300 },
    location: { address: "Kandy, Sri Lanka" },
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d"
  },
  {
    id: 3,
    name: "TechFix Solutions",
    rating: 4.2,
    experience: 5,
    specialization: ["Virus Removal", "OS Installation"],
    brands: ["hp", "dell"],
    priceRange: { min: 40, max: 150 },
    location: { address: "Galle, Sri Lanka" },
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83defb"
  }
];

const CURRENCY_INFO = {
  LKR: { symbol: 'Rs.', rate: 330, name: 'Sri Lankan Rupees' },
  USD: { symbol: '$', rate: 1, name: 'US Dollars' },
};

const PCRepair = () => {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [technicians, setTechnicians] = useState([]);
  const [filteredTechnicians, setFilteredTechnicians] = useState([]);
  const [currency, setCurrency] = useState('LKR');

  const [searchTerm, setSearchTerm] = useState('');
  const [brand, setBrand] = useState('any');
  const [issue, setIssue] = useState('all');
  const [minimumRating, setMinimumRating] = useState('0');

  const [visibleCount, setVisibleCount] = useState(6);
  const [selectedTechnician, setSelectedTechnician] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  /* ---------------- LOAD MOCK DATA ---------------- */

  useEffect(() => {
    setTimeout(() => {
      setTechnicians(MOCK_TECHNICIANS);
      setFilteredTechnicians(MOCK_TECHNICIANS);
      setLoading(false);
    }, 600);
  }, []);

  /* ---------------- FILTER LOGIC ---------------- */

  useEffect(() => {
    let filtered = [...technicians];

    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      filtered = filtered.filter(t =>
        t.name.toLowerCase().includes(s) ||
        t.specialization.some(spec => spec.toLowerCase().includes(s))
      );
    }

    if (brand !== 'any') {
      filtered = filtered.filter(t => t.brands.includes(brand));
    }

    if (issue !== 'all') {
      filtered = filtered.filter(t => t.specialization.includes(issue));
    }

    if (parseFloat(minimumRating) > 0) {
      filtered = filtered.filter(t => t.rating >= parseFloat(minimumRating));
    }

    setFilteredTechnicians(filtered);
  }, [searchTerm, brand, issue, minimumRating, technicians]);

  /* ---------------- HELPERS ---------------- */

  const convertPrice = (usd) => {
    const info = CURRENCY_INFO[currency];
    return `${info.symbol}${Math.round(usd * info.rate)}`;
  };

  /* ---------------- UI ---------------- */

  return (
    <div className="bg-black text-white min-h-screen">
      <SEO title="PC Repair Services" description="Find PC & Laptop repair technicians" />

      <div className="max-w-7xl mx-auto px-6 py-20">

        {/* HEADER */}
        <h1 className="text-6xl font-bold italic mb-6">
          Expert PC Repair
        </h1>
        <p className="text-gray-400 mb-16 max-w-xl">
          Browse trusted PC & laptop technicians. No backend required.
        </p>

        {/* SEARCH */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          <input
            className="md:col-span-4 bg-black border border-white/10 px-6 py-5 uppercase tracking-widest text-sm"
            placeholder="Search technicians or services"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />

          <Select value={brand} onValueChange={setBrand}>
            <SelectTrigger className="bg-black border-white/10 h-14">
              <SelectValue placeholder="Brand" />
            </SelectTrigger>
            <SelectContent className="bg-black text-white">
              <SelectItem value="any">All Brands</SelectItem>
              <SelectItem value="dell">Dell</SelectItem>
              <SelectItem value="hp">HP</SelectItem>
              <SelectItem value="lenovo">Lenovo</SelectItem>
              <SelectItem value="apple">Apple</SelectItem>
            </SelectContent>
          </Select>

          <Select value={issue} onValueChange={setIssue}>
            <SelectTrigger className="bg-black border-white/10 h-14">
              <SelectValue placeholder="Issue" />
            </SelectTrigger>
            <SelectContent className="bg-black text-white">
              <SelectItem value="all">All Issues</SelectItem>
              <SelectItem value="Motherboard Repair">Motherboard</SelectItem>
              <SelectItem value="Data Recovery">Data Recovery</SelectItem>
              <SelectItem value="RAM Upgrade">RAM Upgrade</SelectItem>
            </SelectContent>
          </Select>

          <Select value={minimumRating} onValueChange={setMinimumRating}>
            <SelectTrigger className="bg-black border-white/10 h-14">
              <SelectValue placeholder="Rating" />
            </SelectTrigger>
            <SelectContent className="bg-black text-white">
              <SelectItem value="0">All Ratings</SelectItem>
              <SelectItem value="4">4+ Stars</SelectItem>
              <SelectItem value="4.5">4.5+ Stars</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* RESULTS */}
        {loading ? (
          <div className="flex justify-center py-32">
            <Loader2 className="animate-spin h-10 w-10" />
          </div>
        ) : filteredTechnicians.length === 0 ? (
          <div className="text-center py-32">
            <SearchX className="mx-auto h-12 w-12 opacity-30 mb-6" />
            <p>No technicians found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {filteredTechnicians.slice(0, visibleCount).map(t => (
              <div key={t.id} className="border border-white/10 p-6">
                <img src={t.image} className="h-48 w-full object-cover mb-6" />
                <h3 className="text-2xl font-bold italic">{t.name}</h3>
                <p className="text-sm opacity-60">{t.location.address}</p>
                <p className="mt-3 flex items-center gap-2">
                  <Star className="h-4 w-4 fill-white" /> {t.rating}
                </p>
                <p className="mt-4 font-bold">
                  {convertPrice(t.priceRange.min)} - {convertPrice(t.priceRange.max)}
                </p>
                <button
                  onClick={() => { setSelectedTechnician(t); setShowDetailModal(true); }}
                  className="mt-6 w-full bg-white text-black py-3 uppercase text-xs font-bold"
                >
                  View Details
                </button>
              </div>
            ))}
          </div>
        )}

        {/* LOAD MORE */}
        {visibleCount < filteredTechnicians.length && (
          <div className="text-center mt-16">
            <button
              onClick={() => setVisibleCount(v => v + 6)}
              className="bg-white text-black px-12 py-4 uppercase text-xs font-bold"
            >
              Load More
            </button>
          </div>
        )}
      </div>

      {/* MODAL */}
      <Dialog open={showDetailModal} onOpenChange={setShowDetailModal}>
        <DialogContent className="bg-black text-white border-white/10 max-w-xl">
          {selectedTechnician && (
            <>
              <h2 className="text-3xl font-bold italic">{selectedTechnician.name}</h2>
              <p className="opacity-60">{selectedTechnician.location.address}</p>
              <p className="mt-4">
                {selectedTechnician.specialization.join(', ')}
              </p>
              <button
                onClick={() => navigate('/schedule')}
                className="mt-6 bg-white text-black w-full py-3 uppercase text-xs font-bold"
              >
                Schedule Now
              </button>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PCRepair;
