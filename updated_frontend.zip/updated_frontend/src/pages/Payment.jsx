import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import CurrencyDisplay from '../components/CurrencyDisplay';
import SEO from '../components/SEO';

/* ---------------- MOCK DATA ---------------- */
const MOCK_BOOKING = {
    id: 'BK001',
    serviceType: 'Mobile Repair',
    device: { brand: 'iPhone', model: '13 Pro' },
    technician: { name: 'John Smith', rating: 4.8 },
    amount: 15000,
    serviceFee: 1500,
    total: 16500,
};

const MOCK_PAYMENT_HISTORY = [
    {
        id: 'PAY001',
        created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        amount: 16500,
        status: 'completed',
        card: 'Visa •••• 4242'
    }
];

/* ---------------- PAYMENT SUCCESS MODAL ---------------- */
const PaymentSuccessModal = ({ booking }) => {
    const navigate = useNavigate();

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-8 text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-4xl">✅</span>
                </div>
                <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
                <p className="text-gray-600 mb-6">
                    You paid <CurrencyDisplay amount={booking.total} decimals={0} />
                </p>

                <div className="bg-gray-100 rounded-lg p-4 text-left mb-6">
                    <p><b>Service:</b> {booking.serviceType}</p>
                    <p><b>Device:</b> {booking.device.brand} {booking.device.model}</p>
                    <p><b>Booking ID:</b> #{booking.id}</p>
                </div>

                <button
                    onClick={() => navigate('/customer-dashboard')}
                    className="w-full bg-primary text-white font-semibold py-3 rounded-lg"
                >
                    Go to Dashboard
                </button>
            </div>
        </div>
    );
};

/* ---------------- MAIN COMPONENT ---------------- */
const Payment = () => {
    const location = useLocation();
    const [booking, setBooking] = useState(null);
    const [activeTab, setActiveTab] = useState('pay');
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [history] = useState(MOCK_PAYMENT_HISTORY);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Use passed booking OR mock booking
        setBooking(location.state?.booking || MOCK_BOOKING);
        setLoading(false);
    }, [location]);

    const handlePayNow = () => {
        // Simulate payment delay
        setTimeout(() => {
            setPaymentSuccess(true);
        }, 1000);
    };

    if (loading || !booking) {
        return (
            <div className="text-center py-20">
                <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
                Loading payment...
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8 max-w-5xl">
            <SEO title="Payment" description="Mock payment page" />

            {paymentSuccess && <PaymentSuccessModal booking={booking} />}

            <h1 className="text-3xl font-bold mb-6">Payment Center</h1>

            {/* Tabs */}
            <div className="flex space-x-6 border-b mb-6">
                <button
                    onClick={() => setActiveTab('pay')}
                    className={`pb-2 ${activeTab === 'pay' && 'border-b-2 border-primary font-bold'}`}
                >
                    Make Payment
                </button>
                <button
                    onClick={() => setActiveTab('history')}
                    className={`pb-2 ${activeTab === 'history' && 'border-b-2 border-primary font-bold'}`}
                >
                    Payment History
                </button>
            </div>

            {/* PAY TAB */}
            {activeTab === 'pay' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Summary */}
                    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                        <h2 className="font-bold text-xl mb-4">Order Summary</h2>
                        <p><b>Service:</b> {booking.serviceType}</p>
                        <p><b>Technician:</b> {booking.technician.name} ⭐ {booking.technician.rating}</p>

                        <div className="mt-4 space-y-2">
                            <div className="flex justify-between">
                                <span>Service</span>
                                <CurrencyDisplay amount={booking.amount} decimals={0} />
                            </div>
                            <div className="flex justify-between">
                                <span>Platform Fee</span>
                                <CurrencyDisplay amount={booking.serviceFee} decimals={0} />
                            </div>
                            <div className="flex justify-between font-bold border-t pt-2">
                                <span>Total</span>
                                <CurrencyDisplay amount={booking.total} decimals={0} />
                            </div>
                        </div>
                    </div>

                    {/* Payment */}
                    <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                        <h2 className="font-bold text-xl mb-4">Payment Details</h2>

                        <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-6 text-center mb-6">
                            <p className="mb-2">💳 Demo Card</p>
                            <p className="text-sm text-gray-500">
                                This is a mock payment (no real transaction)
                            </p>
                        </div>

                        <button
                            onClick={handlePayNow}
                            className="w-full bg-primary hover:bg-primary-dark text-white font-semibold py-4 rounded-lg"
                        >
                            Pay <CurrencyDisplay amount={booking.total} decimals={0} />
                        </button>
                    </div>
                </div>
            )}

            {/* HISTORY TAB */}
            {activeTab === 'history' && (
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                    <h2 className="font-bold text-xl mb-4">Transaction History</h2>

                    {history.length === 0 ? (
                        <p className="text-gray-500">No payment history</p>
                    ) : (
                        history.map((p) => (
                            <div
                                key={p.id}
                                className="border rounded-lg p-4 mb-3 flex justify-between"
                            >
                                <div>
                                    <p className="font-semibold">#{p.id}</p>
                                    <p className="text-sm text-gray-500">
                                        {p.created_at.toLocaleDateString()}
                                    </p>
                                    <p className="text-sm">{p.card}</p>
                                </div>
                                <div className="text-right">
                                    <CurrencyDisplay amount={p.amount} decimals={0} />
                                    <p className="text-green-600 text-sm">{p.status}</p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
};

export default Payment;
