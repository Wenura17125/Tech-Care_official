import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Tabs, TabsContent, TabsList, TabsTrigger
} from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import {
  User, Settings, Shield, Bell, LogOut,
  Star, Users, Wrench, DollarSign
} from 'lucide-react';

/* ---------------- MOCK AUTH ---------------- */
const mockUser = {
  name: 'Demo User',
  email: 'demo@email.com',
  role: 'customer', // change to: 'technician' | 'admin'
};

/* ---------------- MOCK DATA ---------------- */
const mockDashboard = {
  customer: {
    completedBookings: 6,
    activeBookings: 1,
    totalBookings: 7,
    totalSpent: 45000,
  },
  technician: {
    completedJobs: 32,
    activeJobs: 3,
    rating: 4.6,
    earnings: 180000,
  },
  admin: {
    totalUsers: 124,
    totalTechnicians: 18,
    revenue: 980000,
  }
};

export default function Profile() {
  const navigate = useNavigate();
  const [user] = useState(mockUser);
  const [profileForm, setProfileForm] = useState({
    name: user.name,
    email: user.email,
    phone: '',
    address: '',
    bio: ''
  });

  const handleLogout = () => {
    navigate('/');
  };

  /* ---------------- CUSTOMER VIEW ---------------- */
  const CustomerProfile = () => {
    const d = mockDashboard.customer;
    return (
      <TabsContent value="overview">
        <Card>
          <CardHeader>
            <CardTitle>Customer Overview</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-4 gap-4">
            <Stat label="Completed Repairs" value={d.completedBookings} />
            <Stat label="Active Orders" value={d.activeBookings} />
            <Stat label="Total Orders" value={d.totalBookings} />
            <Stat label="Total Spent (Rs)" value={d.totalSpent} />
          </CardContent>
        </Card>
      </TabsContent>
    );
  };

  /* ---------------- TECHNICIAN VIEW ---------------- */
  const TechnicianProfile = () => {
    const d = mockDashboard.technician;
    return (
      <TabsContent value="overview">
        <Card>
          <CardHeader>
            <CardTitle>Technician Dashboard</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-4 gap-4">
            <Stat label="Completed Jobs" value={d.completedJobs} />
            <Stat label="Active Jobs" value={d.activeJobs} />
            <Stat label="Rating" value={d.rating} />
            <Stat label="Earnings (Rs)" value={d.earnings} />
          </CardContent>
        </Card>
      </TabsContent>
    );
  };

  /* ---------------- ADMIN VIEW ---------------- */
  const AdminProfile = () => {
    const d = mockDashboard.admin;
    return (
      <TabsContent value="overview">
        <Card>
          <CardHeader>
            <CardTitle>Admin Overview</CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-3 gap-4">
            <Stat label="Total Users" value={d.totalUsers} />
            <Stat label="Technicians" value={d.totalTechnicians} />
            <Stat label="Revenue (Rs)" value={d.revenue} />
          </CardContent>
        </Card>
      </TabsContent>
    );
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* HEADER */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback>{user.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold">{user.name}</h1>
              <Badge className="capitalize">{user.role}</Badge>
            </div>
          </div>

          <Button variant="destructive" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </Button>
        </div>

        {/* TABS */}
        <Tabs defaultValue="overview">
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="overview"><User className="h-4 w-4 mr-1" />Overview</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="h-4 w-4 mr-1" />Settings</TabsTrigger>
            <TabsTrigger value="security"><Shield className="h-4 w-4 mr-1" />Security</TabsTrigger>
            <TabsTrigger value="notifications"><Bell className="h-4 w-4 mr-1" />Notifications</TabsTrigger>
          </TabsList>

          {user.role === 'customer' && <CustomerProfile />}
          {user.role === 'technician' && <TechnicianProfile />}
          {user.role === 'admin' && <AdminProfile />}

          {/* SETTINGS */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Edit Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input value={profileForm.name}
                  onChange={e => setProfileForm({ ...profileForm, name: e.target.value })} />
                <Input value={profileForm.email} />
                <Input placeholder="Phone" />
                <Input placeholder="Address" />
                <Button>Save Changes</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Security</CardTitle>
              </CardHeader>
              <CardContent>
                <Input placeholder="New Password" type="password" />
                <Button className="mt-3">Update Password</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Notification settings (mock)</p>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  );
}

/* ---------------- SMALL STAT COMPONENT ---------------- */
const Stat = ({ label, value }) => (
  <div className="p-6 border rounded-xl text-center">
    <div className="text-2xl font-bold">{value}</div>
    <div className="text-sm text-muted-foreground">{label}</div>
  </div>
);
