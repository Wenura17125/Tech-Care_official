import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Calendar } from '../components/ui/calendar';
import { Badge } from '../components/ui/badge';
import { format } from 'date-fns';
import {
  Smartphone, Laptop, Monitor, Battery, Droplets, Wrench, User,
  Calendar as CalendarIcon, Clock, CheckCircle2, CreditCard,
  ArrowRight, Sparkles, Shield, Star, Zap
} from 'lucide-react';
import SEO from '../components/SEO';

/* ---------------- MOCK DATA ---------------- */

const mockTechnicians = [
  { id: 't1', name: 'Kamal Perera', rating: 4.9, specialization: ['Mobile'] },
  { id: 't2', name: 'Nuwan Silva', rating: 4.8, specialization: ['Laptop'] },
  { id: 't3', name: 'Ravi Fernando', rating: 5.0, specialization: ['General'] }
];

const serviceDetails = {
  battery: { label: 'Battery Replacement', price: 5000 },
  screen: { label: 'Screen Repair', price: 12000 },
  'water-damage': { label: 'Water Damage', price: 8500 },
  general: { label: 'General Repair', price: 4000 }
};

const timeSlots = [
  '09:00 AM', '10:00 AM', '11:00 AM',
  '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM'
];

export default function Schedule() {
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [deviceType, setDeviceType] = useState('smartphone');
  const [deviceBrand, setDeviceBrand] = useState('');
  const [deviceModel, setDeviceModel] = useState('');
  const [repairService, setRepairService] = useState('battery');
  const [issueDescription, setIssueDescription] = useState('');
  const [technician, setTechnician] = useState('pending');
  const [date, setDate] = useState(new Date());
  const [timeSlot, setTimeSlot] = useState('09:00 AM');
  const [loading, setLoading] = useState(false);

  const serviceAmount = serviceDetails[repairService].price;
  const platformFee = 500;
  const totalAmount = serviceAmount + platformFee;

  /* ---------------- SUBMIT (MOCK) ---------------- */
  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    const selectedTech =
      technician === 'pending'
        ? { name: 'Auto Assigned Technician', rating: 5.0 }
        : mockTechnicians.find(t => t.id === technician);

    const mockBooking = {
      id: Date.now(),
      deviceType,
      deviceBrand,
      deviceModel,
      service: serviceDetails[repairService].label,
      issueDescription,
      technician: selectedTech,
      date,
      timeSlot,
      amount: serviceAmount,
      serviceFee: platformFee,
      total: totalAmount
    };

    setTimeout(() => {
      navigate('/payment', { state: { booking: mockBooking } });
    }, 800);
  };

  return (
    <div className="bg-black text-white min-h-screen">
      <SEO title="Schedule Repair - TechCare" />

      {/* HERO */}
      <section className="pt-16 pb-10 text-center">
        <Badge className="mb-6 bg-white/10 text-white">
          <Sparkles className="w-4 h-4 mr-2" /> Book Your Repair
        </Badge>
        <h1 className="text-5xl font-bold mb-4">Schedule Your Service</h1>
        <p className="text-zinc-400">Fast • Secure • Certified Technicians</p>

        <div className="flex justify-center gap-4 mt-6">
          {[Shield, Star, Zap, CheckCircle2].map((Icon, i) => (
            <div key={i} className="flex items-center gap-2 bg-zinc-900 px-4 py-2 rounded-full border border-zinc-800">
              <Icon className="w-4 h-4" />
              <span className="text-sm">Trusted</span>
            </div>
          ))}
        </div>
      </section>

      {/* FORM */}
      <div className="container mx-auto px-4 pb-24 max-w-4xl">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-2xl">
              {step === 1 && 'Device & Service'}
              {step === 2 && 'Date & Time'}
              {step === 3 && 'Confirm Booking'}
            </CardTitle>
            <CardDescription className="text-zinc-400">
              Step {step} of 3
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">

              {/* STEP 1 */}
              {step === 1 && (
                <>
                  <Label className="text-lg font-bold">Device Type</Label>
                  <RadioGroup value={deviceType} onValueChange={setDeviceType} className="grid grid-cols-3 gap-4">
                    {[
                      { v: 'smartphone', i: Smartphone },
                      { v: 'laptop', i: Laptop },
                      { v: 'pc', i: Monitor }
                    ].map(({ v, i: Icon }) => (
                      <Label key={v} className="border border-zinc-700 p-6 rounded-xl text-center cursor-pointer">
                        <RadioGroupItem value={v} className="sr-only" />
                        <Icon className="mx-auto mb-2" />
                        {v}
                      </Label>
                    ))}
                  </RadioGroup>

                  <div className="grid grid-cols-2 gap-4">
                    <input
                      className="bg-zinc-800 border border-zinc-700 p-3 rounded"
                      placeholder="Brand"
                      value={deviceBrand}
                      onChange={e => setDeviceBrand(e.target.value)}
                    />
                    <input
                      className="bg-zinc-800 border border-zinc-700 p-3 rounded"
                      placeholder="Model"
                      value={deviceModel}
                      onChange={e => setDeviceModel(e.target.value)}
                    />
                  </div>

                  <Select value={repairService} onValueChange={setRepairService}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800">
                      {Object.entries(serviceDetails).map(([k, v]) => (
                        <SelectItem key={k} value={k}>
                          {v.label} - LKR {v.price}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <textarea
                    className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded"
                    placeholder="Describe issue (optional)"
                    value={issueDescription}
                    onChange={e => setIssueDescription(e.target.value)}
                  />

                  <Select value={technician} onValueChange={setTechnician}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-800">
                      <SelectItem value="pending">Auto assign</SelectItem>
                      {mockTechnicians.map(t => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.name} ★ {t.rating}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button onClick={() => setStep(2)} className="w-full">
                    Continue <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              )}

              {/* STEP 2 */}
              {step === 2 && (
                <>
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={d => d < new Date()}
                    className="bg-zinc-800 rounded border border-zinc-700"
                  />

                  <div className="grid grid-cols-2 gap-3">
                    {timeSlots.map(slot => (
                      <Button
                        key={slot}
                        type="button"
                        variant={timeSlot === slot ? 'default' : 'outline'}
                        onClick={() => setTimeSlot(slot)}
                      >
                        {slot}
                      </Button>
                    ))}
                  </div>

                  <div className="flex gap-4">
                    <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
                    <Button onClick={() => setStep(3)}>Continue</Button>
                  </div>
                </>
              )}

              {/* STEP 3 */}
              {step === 3 && (
                <>
                  <div className="bg-zinc-800 p-6 rounded-xl space-y-3">
                    <p>Service: {serviceDetails[repairService].label}</p>
                    <p>Date: {format(date, 'PPP')}</p>
                    <p>Time: {timeSlot}</p>
                    <p>Total: LKR {totalAmount}</p>
                  </div>

                  <div className="flex gap-4">
                    <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
                    <Button type="submit" disabled={loading}>
                      {loading ? 'Processing...' : 'Proceed to Payment'}
                      <CreditCard className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}

            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
