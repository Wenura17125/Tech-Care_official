import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import {
  Star,
  MapPin,
  Phone,
  Globe,
  Clock,
  Search,
  Filter,
  Smartphone,
  Laptop,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Users,
  Zap
} from 'lucide-react';
import SEO from '../components/SEO';

/* ================= MOCK DATA ================= */

const MOCK_SHOPS = [
  {
    id: 1,
    rank: 1,
    business_name: 'TechFix Colombo',
    business_type: 'Mobile & Laptop Repair',
    district: 'Colombo',
    address: 'No 45, Galle Road, Colombo',
    rating: 5.0,
    reviews_count: 120,
    phone: '0771234567',
    website: 'https://techfix.lk',
    hours: 'Open 9 AM – 8 PM'
  },
  {
    id: 2,
    rank: 2,
    business_name: 'Kandy Mobile Care',
    business_type: 'Mobile Repair',
    district: 'Kandy',
    address: 'Peradeniya Road, Kandy',
    rating: 4.9,
    reviews_count: 85,
    phone: '0719876543',
    website: '',
    hours: 'Open 9 AM – 6 PM'
  },
  {
    id: 3,
    rank: 3,
    business_name: 'Galle Computer Solutions',
    business_type: 'Computer & Laptop Repair',
    district: 'Galle',
    address: 'Main Street, Galle',
    rating: 4.8,
    reviews_count: 60,
    phone: '0765558888',
    website: '',
    hours: 'Closed'
  }
];

/* ================= COMPONENT ================= */

const Technicians = () => {
  const navigate = useNavigate();
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const shopsPerPage = 12;

  const districts = [
    'all', 'Colombo', 'Kandy', 'Galle', 'Matara', 'Gampaha', 'Negombo'
  ];

  const serviceTypes = [
    { value: 'all', label: 'All Services' },
    { value: 'mobile', label: 'Mobile Repair' },
    { value: 'computer', label: 'Computer/Laptop Repair' }
  ];

  useEffect(() => {
    // Simulate API loading
    setTimeout(() => {
      setShops(MOCK_SHOPS);
      setLoading(false);
    }, 500);
  }, []);

  const filteredShops = shops.filter(shop => {
    const matchesSearch =
      shop.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shop.address.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDistrict =
      selectedDistrict === 'all' || shop.district === selectedDistrict;

    const matchesType =
      selectedType === 'all' ||
      (selectedType === 'mobile' && shop.business_type.toLowerCase().includes('mobile')) ||
      (selectedType === 'computer' && shop.business_type.toLowerCase().includes('computer'));

    return matchesSearch && matchesDistrict && matchesType;
  });

  const totalPages = Math.ceil(filteredShops.length / shopsPerPage);
  const paginatedShops = filteredShops.slice(
    (currentPage - 1) * shopsPerPage,
    currentPage * shopsPerPage
  );

  const getServiceIcon = (type) =>
    type.toLowerCase().includes('computer')
      ? <Laptop className="h-4 w-4 text-white" />
      : <Smartphone className="h-4 w-4 text-white" />;

  const stats = [
    { value: '100+', label: 'Verified Shops', icon: Users },
    { value: '12', label: 'Districts', icon: MapPin },
    { value: '5.0', label: 'Avg Rating', icon: Star },
    { value: '24/7', label: 'Support', icon: Zap }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <SEO title="Find Repair Technicians" />

      {/* HERO */}
      <section className="pt-16 pb-16 text-center">
        <Badge className="mb-4 bg-white/10 text-white">
          <Sparkles className="w-4 h-4 mr-2" /> Verified Technicians
        </Badge>
        <h1 className="text-5xl font-bold mb-4">Find Repair Technicians</h1>
        <p className="text-zinc-400">Mobile & computer repair shops in Sri Lanka</p>
      </section>

      {/* SEARCH */}
      <section className="pb-8">
        <div className="container mx-auto px-4">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="p-6 grid md:grid-cols-4 gap-4">
              <Input
                placeholder="Search shop..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />

              <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700">
                  <SelectValue placeholder="District" />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800">
                  {districts.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="bg-zinc-800 border-zinc-700">
                  <SelectValue placeholder="Service" />
                </SelectTrigger>
                <SelectContent className="bg-zinc-800">
                  {serviceTypes.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* GRID */}
      <section className="pb-24">
        <div className="container mx-auto px-4 grid md:grid-cols-3 gap-6">
          {loading ? (
            <p>Loading...</p>
          ) : (
            paginatedShops.map(shop => (
              <Card key={shop.id} className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle>{shop.business_name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex gap-2 items-center">
                    {getServiceIcon(shop.business_type)}
                    <span>{shop.business_type}</span>
                  </div>
                  <div className="flex gap-2 text-sm">
                    <MapPin className="h-4 w-4" />
                    {shop.address}
                  </div>
                  <div className="flex gap-1 items-center">
                    <Star className="h-4 w-4 fill-white" />
                    {shop.rating} ({shop.reviews_count})
                  </div>
                  <Button
                    className="w-full bg-white text-black"
                    onClick={() => navigate('/schedule', { state: { shop } })}
                  >
                    Book
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </section>
    </div>
  );
};

export default Technicians;
