import { useEffect } from 'react';
import SEO from '../components/SEO';

const Terms = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark">
      <SEO
        title="Terms of Service - TechCare"
        description="Read our Terms of Service to understand the rules and regulations for using the TechCare platform."
        keywords="terms of service, terms and conditions, user agreement, legal"
      />

      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-text-light dark:text-text-dark mb-8">
          Terms of Service
        </h1>

        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Last updated: {new Date().toLocaleDateString()}
        </p>

        <section className="space-y-8 text-gray-700 dark:text-gray-300 leading-relaxed">
          <div>
            <h2 className="text-2xl font-semibold mb-2">1. Acceptance of Terms</h2>
            <p>
              By accessing and using TechCare, you agree to be bound by these Terms.
              If you do not agree, please do not use the service.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">2. Use License</h2>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>No modification or copying of materials</li>
              <li>No commercial use</li>
              <li>No reverse engineering</li>
              <li>No redistribution</li>
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">3. User Accounts</h2>
            <p>
              You are responsible for maintaining the confidentiality of your account
              and password.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">4. Payments & Fees</h2>
            <p>
              Payments are agreed between customers and technicians.
              TechCare may charge a service commission.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">5. Liability</h2>
            <p>
              TechCare is a platform only and is not responsible for repair outcomes.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">6. Governing Law</h2>
            <p>
              These terms are governed by the laws of Sri Lanka.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-2">7. Contact</h2>
            <ul className="space-y-1">
              <li>📧 legal@techcare.com</li>
              <li>📞 +94 11 234 5678</li>
              <li>📍 Colombo, Sri Lanka</li>
            </ul>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Terms;
