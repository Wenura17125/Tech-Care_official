/**
 * Mock Realtime Service (Database-Free)
 * -----------------------------------
 * Local in-memory event system
 * Replaces Supabase realtime for offline / frontend-only use
 */

class RealtimeService {
  constructor() {
    this.listeners = new Map();
  }

  // internal helper
  _subscribe(key, callback) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, []);
    }

    this.listeners.get(key).push(callback);

    // return unsubscribe function
    return () => {
      const list = this.listeners.get(key) || [];
      this.listeners.set(
        key,
        list.filter(cb => cb !== callback)
      );
    };
  }

  // emit events manually (for mock updates)
  emit(key, payload) {
    const callbacks = this.listeners.get(key) || [];
    callbacks.forEach(cb => {
      try {
        cb(payload);
      } catch (e) {
        console.error('Mock realtime error:', e);
      }
    });
  }

  /* ===== Subscriptions (API-compatible) ===== */

  subscribeToTechnicians(callback) {
    return this._subscribe('technicians', callback);
  }

  subscribeToBookings(callback, userId = null) {
    const key = userId ? `bookings-${userId}` : 'bookings-all';
    return this._subscribe(key, callback);
  }

  subscribeToReviews(callback) {
    return this._subscribe('reviews', callback);
  }

  subscribeToServices(callback) {
    return this._subscribe('services', callback);
  }

  subscribeToGigs(callback) {
    return this._subscribe('gigs', callback);
  }

  subscribeToNotifications(userId, callback) {
    return this._subscribe(`notifications-${userId}`, callback);
  }

  subscribeToBids(callback) {
    return this._subscribe('bids', callback);
  }

  subscribeToMessages(bookingId, callback) {
    return this._subscribe(`messages-${bookingId}`, callback);
  }

  /* ===== Cleanup ===== */

  unsubscribeAll() {
    this.listeners.clear();
  }
}

const realtimeService = new RealtimeService();
export default realtimeService;
